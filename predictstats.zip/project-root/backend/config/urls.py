from django.contrib import admin
from django.urls import path, include
from rest_framework import routers
from drf_yasg.views import get_schema_view
from drf_yasg import openapi
from rest_framework import permissions

# API router configuration
router = routers.DefaultRouter()

schema_view = get_schema_view(
    openapi.Info(
        title="PredictStats API",
        default_version='v1',
        description="Sports Prediction Analytics API",
        contact=openapi.Contact(email="support@predictstats.com"),
    ),
    public=True,
    permission_classes=(permissions.AllowAny,),
)

urlpatterns = [
    # Admin Interface
    path('admin/', admin.site.urls),
    
    # Authentication Endpoints
    path('api/auth/', include('users.urls')),
    
    # Sports Data Endpoints
    path('api/matches/', include('matches.urls')),
    
    # Subscription Management
    path('api/subscriptions/', include('subscriptions.urls')),
    
    # Admin Panel API
    path('api/control/', include('adminpanel.urls')),
    
    # API Documentation
    path('swagger/', schema_view.with_ui('swagger', cache_timeout=0), 
         name='schema-swagger-ui'),
    path('redoc/', schema_view.with_ui('redoc', cache_timeout=0), 
         name='schema-redoc'),
    
    # Health Check
    path('health/', include('health_check.urls')),
]