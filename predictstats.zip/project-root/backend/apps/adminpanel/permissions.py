from rest_framework.permissions import BasePermission

class IsSuperAdmin(BasePermission):
    """
    Grants full access to super admins
    - Create/update/delete all entities
    - Manage user roles
    - Access audit logs
    """
    def has_permission(self, request, view):
        return request.user.is_authenticated and request.user.role == 'SUPER_ADMIN'

class IsModerator(BasePermission):
    """
    Grants moderation privileges:
    - Approve/reject predictions
    - Manage basic user accounts
    - View system metrics
    """
    def has_permission(self, request, view):
        return request.user.is_authenticated and request.user.role in ['MODERATOR', 'SUPER_ADMIN']

class IsAnalyst(BasePermission):
    """
    Grants read-only analytical access:
    - View all predictions
    - Export datasets
    - Generate reports
    """
    def has_permission(self, request, view):
        return request.user.is_authenticated and request.user.role in ['ANALYST', 'MODERATOR', 'SUPER_ADMIN']

class IsOwnerOrAdmin(BasePermission):
    """
    Grants access to own resources or admin override:
    - User-specific configurations
    - Personal audit logs
    """
    def has_object_permission(self, request, view, obj):
        return obj.user == request.user or request.user.role in ['MODERATOR', 'SUPER_ADMIN']