from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter()
router.register(r'api-scripts', views.APIScriptViewSet, basename='apisscripts')

urlpatterns = [
    # Dashboard Analytics
    path('dashboard-stats/', views.AdminDashboardView.as_view(), name='admin-dashboard'),
    
    # Prediction Moderation
    path('prediction-moderation/', views.PredictionModerationView.as_view(), name='prediction-moderation'),
    
    # User Management
    path('user-management/', views.UserManagementView.as_view(), name='user-management'),
    
    # System Monitoring
    path('system-health/', views.SystemHealthView.as_view(), name='system-health'),
    
    # API Script Engine
    path('', include(router.urls)),
    
    # Ad Management
    path('ads/', views.AdManagementView.as_view(), name='ad-management'),
    
    # Security Center
    path('security/', views.SecurityCenterView.as_view(), name='security-center'),
]

# Optional namespace for reverse URL lookups
app_name = 'adminpanel'