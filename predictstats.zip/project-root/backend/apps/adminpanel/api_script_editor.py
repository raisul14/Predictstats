import subprocess
import logging
from django.conf import settings
from django.db import models
from django.contrib import admin
from django.utils import timezone

logger = logging.getLogger(__name__)

class APIScript(models.Model):
    """Store and manage executable API scripts"""
    name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True)
    code = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.name} (v{self.updated_at.timestamp()})"

def execute_script(script_content: str, timeout: int = 30) -> dict:
    """Safely execute Python scripts in isolated environment"""
    try:
        result = subprocess.run(
            [settings.PYTHON_PATH, '-c', script_content],
            capture_output=True,
            text=True,
            timeout=timeout,
            env={'PYTHONPATH': settings.BASE_DIR}
        )
        return {
            'success': result.returncode == 0,
            'output': result.stdout,
            'error': result.stderr,
            'execution_time': timezone.now().isoformat()
        }
    except subprocess.TimeoutExpired:
        logger.error("Script execution timed out")
        return {'error': 'Execution timed out after 30 seconds'}
    except Exception as e:
        logger.error(f"Script execution failed: {str(e)}")
        return {'error': str(e)}

def save_script(name: str, code: str, description: str = "") -> APIScript:
    """Create/update API scripts with validation"""
    try:
        script, created = APIScript.objects.update_or_create(
            name=name,
            defaults={
                'code': code,
                'description': description,
                'is_active': True
            }
        )
        logger.info(f"{'Created' if created else 'Updated'} script: {name}")
        return script
    except Exception as e:
        logger.error(f"Script save failed: {str(e)}")
        raise ValueError(f"Script save error: {str(e)}")

class APIScriptAdmin(admin.ModelAdmin):
    list_display = ('name', 'is_active', 'created_at', 'updated_at')
    search_fields = ('name', 'description')
    list_filter = ('is_active',)
    readonly_fields = ('created_at', 'updated_at')
    actions = ['execute_selected_scripts']

    def execute_selected_scripts(self, request, queryset):
        for script in queryset:
            result = execute_script(script.code)
            self.message_user(
                request,
                f"Executed {script.name}: {result.get('output', 'No output')}"
            )

# Example Usage
if __name__ == "__main__":
    sample_script = """
import requests
response = requests.get('https://api.example.com/data')
print(response.json())
    """
    
    try:
        script = save_script("DataFetcher", sample_script)
        print(execute_script(script.code))
    except Exception as e:
        print(f"Error: {str(e)}")