from rest_framework import viewsets, status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.decorators import action
from django.contrib.auth import get_user_model
from .models import APIScript
from .serializers import APIScriptSerializer, UserSerializer, PredictionModerationSerializer
from .permissions import IsSuperAdmin, IsModerator, IsAnalyst
from .dashboard_stats import (
    get_database_status, get_active_users,
    get_storage_usage, get_recent_errors,
    get_prediction_accuracy, get_system_health
)
from .api_script_editor import execute_script

User = get_user_model()

class AdminDashboardView(APIView):
    permission_classes = [IsSuperAdmin | IsModerator]

    def get(self, request):
        stats = {
            "database_status": get_database_status(),
            "active_users": get_active_users(),
            "storage_usage": get_storage_usage(),
            "recent_errors": get_recent_errors(),
            "prediction_accuracy": get_prediction_accuracy()
        }
        return Response(stats)

class PredictionModerationView(viewsets.ViewSet):
    permission_classes = [IsModerator | IsSuperAdmin]
    
    def list(self, request):
        # Get pending predictions (implementation specific)
        pending = []  # Replace with actual query
        serializer = PredictionModerationSerializer(pending, many=True)
        return Response(serializer.data)

    def partial_update(self, request, pk=None):
        # Handle prediction approval/rejection
        # Implementation depends on prediction model
        return Response({"status": "Prediction updated"}, status=status.HTTP_200_OK)

class APIScriptViewSet(viewsets.ModelViewSet):
    queryset = APIScript.objects.all()
    serializer_class = APIScriptSerializer
    permission_classes = [IsSuperAdmin]

    @action(detail=True, methods=['post'])
    def execute(self, request, pk=None):
        script = self.get_object()
        result = execute_script(script.code)
        return Response(result)

class UserManagementView(viewsets.ViewSet):
    serializer_class = UserSerializer
    permission_classes = [IsModerator | IsSuperAdmin]

    def list(self, request):
        users = User.objects.all()
        serializer = self.serializer_class(users, many=True)
        return Response(serializer.data)

    def retrieve(self, request, pk=None):
        user = User.objects.get(pk=pk)
        serializer = self.serializer_class(user)
        return Response(serializer.data)

    def partial_update(self, request, pk=None):
        user = User.objects.get(pk=pk)
        serializer = self.serializer_class(user, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)

class SystemHealthView(APIView):
    permission_classes = [IsSuperAdmin]

    def get(self, request):
        health_data = get_system_health()
        return Response(health_data)

class AdManagementView(viewsets.ViewSet):
    permission_classes = [IsSuperAdmin]
    # Implementation depends on ad platform integration

class SecurityCenterView(viewsets.ViewSet):
    permission_classes = [IsSuperAdmin]
    # Implementation for security monitoring features