import logging
import psutil
from django.db import connection
from django.utils import timezone
from django.contrib.auth import get_user_model
from django.conf import settings

logger = logging.getLogger(__name__)
User = get_user_model()

def get_database_status() -> str:
    """Check database connection status"""
    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
            return "connected"
    except Exception as e:
        logger.error(f"Database connection failed: {str(e)}")
        return "disconnected"

def get_active_users(minutes=15) -> int:
    """Count users active in last X minutes"""
    try:
        threshold = timezone.now() - timezone.timedelta(minutes=minutes)
        return User.objects.filter(last_login__gte=threshold).count()
    except Exception as e:
        logger.error(f"Active users query failed: {str(e)}")
        return 0

def get_storage_usage() -> str:
    """Get disk usage percentage for root partition"""
    try:
        usage = psutil.disk_usage(settings.STORAGE_MONITOR_PATH)
        return f"{usage.percent}%"
    except Exception as e:
        logger.error(f"Storage check failed: {str(e)}")
        return "N/A"

def get_recent_errors(limit=10) -> list:
    """Retrieve recent system errors from logs"""
    try:
        if 'error_logs' in connection.introspection.table_names():
            with connection.cursor() as cursor:
                cursor.execute(
                    "SELECT timestamp, message FROM error_logs "
                    "ORDER BY timestamp DESC LIMIT %s",
                    [limit]
                )
                return [
                    {"timestamp": row[0], "message": row[1]}
                    for row in cursor.fetchall()
                ]
        return []
    except Exception as e:
        logger.error(f"Error log retrieval failed: {str(e)}")
        return []

def get_prediction_accuracy(days=7) -> float:
    """Calculate model accuracy over recent predictions"""
    try:
        from matches.models import PredictionAudit  # Avoid circular import
        recent = PredictionAudit.objects.filter(
            timestamp__gte=timezone.now()-timezone.timedelta(days=days)
        )
        correct = recent.filter(outcome_correct=True).count()
        total = recent.count()
        return round(correct/total, 2) if total > 0 else 0.0
    except Exception as e:
        logger.error(f"Accuracy calculation failed: {str(e)}")
        return 0.0

def get_system_health() -> dict:
    """Comprehensive health check of key components"""
    return {
        "database": get_database_status(),
        "cache": _check_cache_connection(),
        "workers": _check_celery_workers(),
        "api_latency": _measure_api_response()
    }

def _check_cache_connection() -> bool:
    """Verify Redis cache connectivity"""
    try:
        from django_redis import get_redis_connection
        conn = get_redis_connection("default")
        return conn.ping()
    except Exception as e:
        logger.error(f"Cache connection failed: {str(e)}")
        return False

def _check_celery_workers() -> int:
    """Count active Celery workers"""
    try:
        from celery import current_app
        inspector = current_app.control.inspect()
        return len(inspector.ping() or [])
    except Exception as e:
        logger.error(f"Worker check failed: {str(e)}")
        return 0

def _measure_api_response() -> float:
    """Basic API endpoint response time measurement"""
    try:
        from django.test import Client
        client = Client()
        start = timezone.now()
        client.get('/api/health/')
        return (timezone.now() - start).total_seconds()
    except Exception as e:
        logger.error(f"Latency check failed: {str(e)}")
        return 0.0