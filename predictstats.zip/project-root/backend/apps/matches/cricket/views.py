from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import CricketMatch, Player, CricketMatchStats
from .serializers import (
    CricketMatchSerializer, 
    PlayerSerializer,
    PredictionSerializer
)
from .predictions import CricketPredictionEngine
from .over_summaries import OverAnalyzer

class CricketMatchViewSet(viewsets.ReadOnlyModelViewSet):
    """
    API endpoint for cricket match data with prediction capabilities
    """
    queryset = CricketMatch.objects.prefetch_related('stats').all()
    serializer_class = CricketMatchSerializer

    @action(detail=True, methods=['get'])
    def prediction(self, request, pk=None):
        """Get match-specific predictions"""
        match = self.get_object()
        engine = CricketPredictionEngine()
        
        try:
            prediction = engine.predict_match(match.id)
            serializer = PredictionSerializer({
                'match_id': match.id,
                **prediction
            })
            return Response(serializer.data)
            
        except Exception as e:
            return Response(
                {"error": str(e)}, 
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    @action(detail=True, methods=['get'])
    def over_summary(self, request, pk=None):
        """Get detailed over-by-over analysis"""
        match = self.get_object()
        analyzer = OverAnalyzer(match.stats.innings_data)
        
        try:
            over_num = int(request.query_params.get('over', match.current_over))
            summary = analyzer.generate_over_summary(over_num)
            return Response(summary)
            
        except ValueError:
            return Response(
                {"error": "Invalid over number"}, 
                status=status.HTTP_400_BAD_REQUEST
            )

class CricketPredictionView(viewsets.ViewSet):
    """
    Batch prediction endpoint for upcoming matches
    """
    def list(self, request):
        matches = CricketMatch.objects.filter(status='scheduled')
        engine = CricketPredictionEngine()
        
        try:
            predictions = engine.batch_predict(matches)
            serializer = PredictionSerializer(predictions, many=True)
            return Response(serializer.data)
            
        except Exception as e:
            return Response(
                {"error": str(e)}, 
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

class PlayerViewSet(viewsets.ReadOnlyModelViewSet):
    """
    API endpoint for player statistics and performance data
    """
    queryset = Player.objects.filter(is_active=True)
    serializer_class = PlayerSerializer
    lookup_field = 'player_id'

    @action(detail=True, methods=['get'])
    def head_to_head(self, request, player_id=None):
        """Get player's historical performance against specific teams"""
        player = self.get_object()
        vs_team = request.query_params.get('team')
        
        if not vs_team:
            return Response(
                {"error": "Team parameter required"}, 
                status=status.HTTP_400_BAD_REQUEST
            )
            
        stats = player.get_h2h_stats(vs_team)
        return Response(stats)