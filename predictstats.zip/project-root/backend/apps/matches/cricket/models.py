from django.db import models
from django.contrib.auth import get_user_model

User = get_user_model()

class CricketTeam(models.Model):
    FORMAT_CHOICES = [
        ('T20', 'Twenty20'),
        ('ODI', 'One Day International'),
        ('TEST', 'Test Match'),
    ]
    
    name = models.CharField(max_length=100, unique=True)
    country = models.CharField(max_length=50)
    logo = models.URLField(max_length=300, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    format_specialization = models.CharField(
        max_length=4, 
        choices=FORMAT_CHOICES,
        default='T20'
    )

    def __str__(self):
        return f"{self.name} ({self.country})"

class CricketMatch(models.Model):
    STATUS_CHOICES = [
        ('SCHEDULED', 'Scheduled'),
        ('ONGOING', 'Ongoing'),
        ('COMPLETED', 'Completed'),
        ('ABANDONED', 'Abandoned'),
    ]
    
    team1 = models.ForeignKey(
        CricketTeam,
        on_delete=models.CASCADE,
        related_name='home_matches'
    )
    team2 = models.ForeignKey(
        CricketTeam,
        on_delete=models.CASCADE,
        related_name='away_matches'
    )
    match_date = models.DateTimeField()
    venue = models.CharField(max_length=100)
    format = models.CharField(max_length=4, choices=FORMAT_CHOICES)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='SCHEDULED')
    result = models.JSONField(null=True, blank=True)
    weather_data = models.JSONField(null=True, blank=True)
    toss_details = models.JSONField(null=True, blank=True)

    class Meta:
        ordering = ['-match_date']
        indexes = [
            models.Index(fields=['match_date']),
            models.Index(fields=['team1', 'team2']),
        ]

    def __str__(self):
        return f"{self.team1} vs {self.team2} - {self.get_format_display()}"

class Player(models.Model):
    ROLE_CHOICES = [
        ('BAT', 'Batsman'),
        ('BOWL', 'Bowler'),
        ('AR', 'All-Rounder'),
        ('WK', 'Wicket-Keeper'),
    ]
    
    player_id = models.CharField(max_length=20, unique=True)
    name = models.CharField(max_length=100)
    team = models.ForeignKey(
        CricketTeam,
        on_delete=models.CASCADE,
        related_name='players'
    )
    role = models.CharField(max_length=4, choices=ROLE_CHOICES)
    is_active = models.BooleanField(default=True)
    career_stats = models.JSONField(default=dict)
    recent_performance = models.JSONField(default=list)

    class Meta:
        ordering = ['name']
        unique_together = ['name', 'team']

    def __str__(self):
        return f"{self.name} ({self.team})"

class CricketMatchStats(models.Model):
    match = models.OneToOneField(
        CricketMatch,
        on_delete=models.CASCADE,
        related_name='stats'
    )
    innings_data = models.JSONField()
    player_performance = models.JSONField()
    partnership_analysis = models.JSONField()
    powerplay_stats = models.JSONField()
    created_at = models.DateTimeField(auto_now_add=True)
    last_updated = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Stats for {self.match}"

class PlayerMatchRating(models.Model):
    player = models.ForeignKey(Player, on_delete=models.CASCADE, related_name='ratings')
    match = models.ForeignKey(CricketMatch, on_delete=models.CASCADE)
    rating = models.FloatField()
    rating_components = models.JSONField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ['player', 'match']
        indexes = [
            models.Index(fields=['player', 'rating']),
        ]

    def __str__(self):
        return f"{self.player} - {self.rating}"