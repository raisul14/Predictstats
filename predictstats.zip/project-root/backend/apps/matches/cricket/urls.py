from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter()
router.register(r'', views.CricketMatchViewSet, basename='cricket')

urlpatterns = [
    path('', include(router.urls)),
    path('predictions/', views.CricketPredictionView.as_view(), name='cricket-predictions'),
    path('<int:pk>/over-summary/', views.CricketMatchViewSet.as_view({'get': 'over_summary'}), name='over-summary'),
    path('players/<str:player_id>/stats/', views.PlayerViewSet.as_view({'get': 'head_to_head'}), name='player-h2h')
]