import logging
import pandas as pd
from datetime import datetime
from typing import Dict, List, Optional
from ..utils.transformation import exponential_smoothing
from .models import CricketTeam, CricketMatch, Player

logger = logging.getLogger(__name__)

class CricketDataFormatter:
    """Formats raw cricket data into structured formats for storage/predictions"""
    
    @staticmethod
    def format_match_report(raw_data: Dict) -> Dict:
        """
        Convert scraped match data into database-compatible format.
        
        Args:
            raw_data: Raw data from ESPNCricinfo scraper
            
        Returns:
            Dict structured for CricketMatch model
        """
        try:
            formatted = {
                'team1': CricketDataFormatter._get_team_id(raw_data['teams'][0]),
                'team2': CricketDataFormatter._get_team_id(raw_data['teams'][1]),
                'match_date': datetime.strptime(raw_data['date'], '%Y-%m-%d'),
                'venue': raw_data.get('ground', 'Unknown'),
                'format': raw_data['match_type'],
                'result': {
                    'winner': raw_data['result']['winner'],
                    'margin': raw_data['result']['margin'],
                    'method': raw_data['result'].get('method')
                },
                'stats': {
                    'innings': raw_data['innings'],
                    'top_performers': raw_data['performances']
                }
            }
            return formatted
            
        except KeyError as e:
            logger.error(f"Missing required field in match data: {str(e)}")
            return {}
        except Exception as e:
            logger.error(f"Match formatting failed: {str(e)}")
            return {}

    @staticmethod
    def format_player_performance(raw_data: List[Dict]) -> List[Dict]:
        """
        Process raw player data into standardized performance format.
        
        Args:
            raw_data: List of player performances from scraper
            
        Returns:
            List of formatted player performances
        """
        formatted = []
        for player in raw_data:
            try:
                formatted.append({
                    'player_id': player['id'],
                    'name': player['name'],
                    'role': player['role'],
                    'batting': {
                        'runs': int(player['batting']['runs']),
                        'balls': int(player['batting']['balls']),
                        'fours': int(player['batting']['4s']),
                        'sixes': int(player['batting']['6s'])
                    },
                    'bowling': {
                        'overs': float(player['bowling']['overs']),
                        'maidens': int(player['bowling']['maidens']),
                        'runs': int(player['bowling']['runs']),
                        'wickets': int(player['bowling']['wickets'])
                    } if player['bowling'] else None,
                    'fielding': {
                        'catches': int(player['fielding']['catches']),
                        'run_outs': int(player['fielding']['run_outs'])
                    }
                })
            except (KeyError, ValueError) as e:
                logger.warning(f"Skipping invalid player data: {str(e)}")
        return formatted

    @staticmethod
    def create_prediction_features(match_data: Dict) -> pd.DataFrame:
        """
        Generate ML-ready features from formatted match data.
        
        Args:
            match_data: Output from format_match_report()
            
        Returns:
            DataFrame with engineered features
        """
        try:
            features = {
                'venue_avg': CricketDataFormatter._get_venue_avg(match_data['venue']),
                'team1_strength': CricketDataFormatter._team_strength(match_data['team1']),
                'team2_strength': CricketDataFormatter._team_strength(match_data['team2']),
                'player_form': CricketDataFormatter._key_player_form(
                    match_data['stats']['top_performers']
                ),
                'h2h_advantage': CricketDataFormatter._h2h_advantage(
                    match_data['team1'], match_data['team2']
                ),
                'over': match_data.get('current_over', 0)
            }
            
            # Add cyclic encoding for over progression
            return encode_cyclic_features(pd.DataFrame([features]), 'over', 50)
            
        except KeyError as e:
            logger.error(f"Feature creation failed: {str(e)}")
            return pd.DataFrame()

    @staticmethod
    def format_predictions(prediction: Dict, match_id: int) -> Dict:
        """
        Convert model output to API response format.
        
        Args:
            prediction: Raw model output
            match_id: Related match ID
            
        Returns:
            Dict matching PredictionSerializer
        """
        return {
            'match_id': match_id,
            'winner_prob': prediction.get('winner_probability', {}),
            'top_batsman': prediction.get('top_batsman', 'Unknown'),
            'score_range': prediction.get('score_range', [])
        }

    # Helper methods
    @staticmethod
    def _get_team_id(team_name: str) -> int:
        try:
            return CricketTeam.objects.get(name=team_name).id
        except CricketTeam.DoesNotExist:
            logger.error(f"Unknown team: {team_name}")
            return -1

    @staticmethod
    def _get_venue_avg(venue: str) -> float:
        avg = CricketMatch.objects.filter(venue=venue).aggregate(
            avg_runs=Avg('stats__innings__runs')
        )
        return avg['avg_runs'] or 0.0

    @staticmethod
    def _team_strength(team_id: int) -> float:
        team = CricketTeam.objects.get(pk=team_id)
        return (team.win_percentage * 0.7 + 
                team.recent_form * 0.3)

    @staticmethod
    def _key_player_form(performers: List) -> float:
        forms = [p['recent_form'] for p in performers if 'recent_form' in p]
        return exponential_smoothing(forms)[-1] if forms else 0.0

    @staticmethod
    def _h2h_advantage(team1_id: int, team2_id: int) -> float:
        matches = CricketMatch.objects.filter(
            team1=team1_id, team2=team2_id
        ).count()
        if matches == 0: return 0.5
        wins = CricketMatch.objects.filter(
            team1=team1_id, team2=team2_id,
            result__winner=team1_id
        ).count()
        return wins / matches

# Example Usage
if __name__ == "__main__":
    sample_data = {
        "teams": ["India", "Australia"],
        "date": "2024-03-15",
        "ground": "Wankhede Stadium",
        "match_type": "ODI",
        "result": {
            "winner": "India",
            "margin": "6 wickets",
            "method": "DLS"
        },
        "innings": [...],
        "performances": [...]
    }
    
    formatter = CricketDataFormatter()
    formatted_match = formatter.format_match_report(sample_data)
    features = formatter.create_prediction_features(formatted_match)
    print(features)