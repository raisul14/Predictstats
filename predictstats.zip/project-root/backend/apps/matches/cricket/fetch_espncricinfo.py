import requests
from bs4 import BeautifulSoup
import logging
from urllib.parse import urljoin
from typing import List, Dict, Optional

logger = logging.getLogger(__name__)

class CricinfoFetcher:
    BASE_URL = "https://www.espncricinfo.com"
    HEADERS = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    }

    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update(self.HEADERS)

    def fetch_live_matches(self) -> List[Dict]:
        """Fetch list of ongoing and upcoming cricket matches"""
        try:
            response = self.session.get(f"{self.BASE_URL}/live-cricket-scores", timeout=10)
            response.raise_for_status()
            soup = BeautifulSoup(response.content, 'html.parser')
            
            matches = []
            for card in soup.select('.ds-p-4.ds-border-b.ds-border-line'):
                try:
                    teams = [elem.get_text(strip=True) 
                            for elem in card.select('.ci-team-score')]
                    status = card.select_one('.ds-text-tight-xs').get_text(strip=True)
                    link = card.find('a', class_='ds-no-tap-higlight')['href']
                    
                    matches.append({
                        'teams': teams,
                        'status': status,
                        'link': urljoin(self.BASE_URL, link),
                        'timestamp': datetime.utcnow().isoformat()
                    })
                except Exception as e:
                    logger.error(f"Error parsing match card: {str(e)}")
                    continue
                
            return matches
            
        except Exception as e:
            logger.error(f"Failed to fetch live matches: {str(e)}")
            return []

    def fetch_match_details(self, match_url: str) -> Dict:
        """Get detailed match information including scorecard and commentary"""
        try:
            response = self.session.get(match_url, timeout=15)
            response.raise_for_status()
            soup = BeautifulSoup(response.content, 'html.parser')

            return {
                'scorecard': self._parse_scorecard(soup),
                'commentary': self._parse_commentary(soup),
                'players': self._parse_players(soup),
                'match_info': self._parse_match_info(soup)
            }
        except Exception as e:
            logger.error(f"Failed to fetch match details: {str(e)}")
            return {}

    def _parse_scorecard(self, soup: BeautifulSoup) -> Dict:
        """Extract batting and bowling statistics"""
        scorecard = {'batting': [], 'bowling': []}
        
        # Batting Table
        for row in soup.select('.ds-w-full.ds-table.ds-table-md.ds-table-auto.ci-scorecard-table tr'):
            cells = [cell.get_text(strip=True) for cell in row.select('td')]
            if len(cells) >= 5 and 'batsmen' not in row.get('class', []):
                scorecard['batting'].append({
                    'player': cells[0],
                    'runs': cells[1],
                    'balls': cells[2],
                    'fours': cells[3],
                    'sixes': cells[4],
                    'sr': cells[5] if len(cells) > 5 else None
                })
        
        # Bowling Table
        for row in soup.select('.ds-w-full.ds-table.ds-table-md.ds-table-auto.ci-scorecard-table tr'):
            cells = [cell.get_text(strip=True) for cell in row.select('td')]
            if len(cells) >= 5 and 'bowler' not in row.get('class', []):
                scorecard['bowling'].append({
                    'player': cells[0],
                    'overs': cells[1],
                    'maidens': cells[2],
                    'runs': cells[3],
                    'wickets': cells[4],
                    'economy': cells[5] if len(cells) > 5 else None
                })
                
        return scorecard

    def _parse_commentary(self, soup: BeautifulSoup) -> List[Dict]:
        """Extract ball-by-ball commentary"""
        commentary = []
        for item in soup.select('.ds-p-4.ds-border-b.ds-border-line'):
            over = item.select_one('.ds-mb-1').get_text(strip=True)
            text = item.select_one('.ds-ml-4').get_text(strip=True)
            commentary.append({
                'over': over,
                'text': text,
                'timestamp': datetime.utcnow().isoformat()
            })
        return commentary

    def _parse_players(self, soup: BeautifulSoup) -> Dict:
        """Extract player lists and roles"""
        players = {'team1': [], 'team2': []}
        
        for i, team in enumerate(soup.select('.ds-flex.ds-flex-col.ds-mt-2.ds-mb-4')):
            for player in team.select('.ds-inline-flex.ds-items-center.ds-leading-none'):
                players[f'team{i+1}'].append({
                    'name': player.select_one('span').get_text(strip=True),
                    'role': player.select_one('.ds-text-tight-s').get_text(strip=True) 
                            if player.select_one('.ds-text-tight-s') else None
                })
                
        return players

    def _parse_match_info(self, soup: BeautifulSoup) -> Dict:
        """Extract match metadata"""
        info = {}
        for item in soup.select('.ds-text-tight-s.ds-font-regular.ds-text-typo-mid3'):
            key = item.select_one('span').get_text(strip=True).replace(':', '')
            value = item.contents[-1].strip()
            info[key.lower()] = value
        return info