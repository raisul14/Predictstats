import numpy as np
from collections import defaultdict
import logging
from typing import Dict, List, Generator

logger = logging.getLogger(__name__)

class OverAnalyzer:
    """Analyzes cricket match data to generate over-by-over insights"""
    
    def __init__(self, innings_data: Dict):
        """
        Initialize with ball-by-ball innings data
        
        Args:
            innings_data: {
                'ball_events': [
                    { 'over': int, 'ball': int, 'runs_total': int, ... }
                ],
                'current_over': int
            }
        """
        self.ball_events = innings_data.get('ball_events', [])
        self.current_over = innings_data.get('current_over', 0)
        self.over_cache = {}
        
    def generate_over_summary(self, over_number: int) -> Dict:
        """Generate detailed analysis for a specific over"""
        if over_number in self.over_cache:
            return self.over_cache[over_number]

        over_events = [e for e in self.ball_events if e['over'] == over_number]
        if not over_events:
            return {'error': f'No data for over {over_number}'}

        summary = {
            'over': over_number,
            'runs': 0,
            'wickets': 0,
            'boundaries': {'4s': 0, '6s': 0},
            'bowlers': defaultdict(lambda: {'runs': 0, 'balls': 0}),
            'timeline': [],
            'key_moments': []
        }

        for ball in sorted(over_events, key=lambda x: x['ball']):
            summary['runs'] += ball['runs_total']
            
            if ball.get('wicket', False):
                summary['wickets'] += 1
                summary['key_moments'].append(
                    f"Wicket: {ball['batsman']} ({ball.get('dismissal_type', 'bowled')})"
                )
                
            boundary = ball.get('runs_boundary', 0)
            if boundary == 4:
                summary['boundaries']['4s'] += 1
                summary['key_moments'].append("Boundary FOUR")
            elif boundary == 6:
                summary['boundaries']['6s'] += 1
                summary['key_moments'].append("SIX!")

            bowler = ball['bowler']
            summary['bowlers'][bowler]['runs'] += ball['runs_total']
            summary['bowlers'][bowler]['balls'] += 1

            summary['timeline'].append({
                'ball': f"{over_number}.{ball['ball']}",
                'batsman': ball['batsman'],
                'runs': ball['runs_total'],
                'description': ball.get('commentary', '')
            })

        # Calculate bowler economies
        for bowler, stats in summary['bowlers'].items():
            stats['economy'] = round(
                (stats['runs'] / stats['balls']) * 6, 1
            ) if stats['balls'] > 0 else 0.0

        self.over_cache[over_number] = summary
        return summary

    def get_live_over_updates(self) -> Generator[Dict, None, None]:
        """Real-time over progression generator"""
        processed_overs = set()
        while True:
            current_over = self.current_over
            for over in range(1, current_over + 1):
                if over not in processed_overs:
                    yield self.generate_over_summary(over)
                    processed_overs.add(over)

    def compare_overs(self, over1: int, over2: int) -> Dict:
        """Comparative analysis between two overs"""
        s1 = self.generate_over_summary(over1)
        s2 = self.generate_over_summary(over2)
        
        return {
            'runs_diff': s1['runs'] - s2['runs'],
            'wicket_diff': s1['wickets'] - s2['wickets'],
            'boundary_comparison': {
                '4s': s1['boundaries']['4s'] - s2['boundaries']['4s'],
                '6s': s1['boundaries']['6s'] - s2['boundaries']['6s']
            },
            'economy_comparison': {
                'over1': self._avg_economy(s1),
                'over2': self._avg_economy(s2)
            }
        }

    def generate_over_highlights(self, over_number: int) -> Dict:
        """Natural language summary of key over events"""
        summary = self.generate_over_summary(over_number)
        highlights = []
        
        if summary['wickets'] > 0:
            highlights.append(f"{summary['wickets']} wicket(s)")
            
        boundaries = summary['boundaries']['4s'] + summary['boundaries']['6s']
        if boundaries > 0:
            highlights.append(f"{boundaries} boundaries")
            
        avg_economy = self._avg_economy(summary)
        if avg_economy < 4.0:
            highlights.append(f"Tight bowling (ER: {avg_economy})")
        elif avg_economy > 10.0:
            highlights.append(f"Expensive over (ER: {avg_economy})")

        return {
            'over': over_number,
            'summary': ", ".join(highlights) if highlights else "Steady over",
            'total_runs': summary['runs'],
            'bowlers': [
                f"{bowler}: {stats['runs']}/{stats['economy']}" 
                for bowler, stats in summary['bowlers'].items()
            ]
        }

    def _avg_economy(self, summary: Dict) -> float:
        """Calculate average economy rate for an over"""
        if not summary['bowlers']:
            return 0.0
        return round(sum(b['economy'] for b in summary['bowlers'].values()) / len(summary['bowlers']), 1)

# Example Usage
if __name__ == "__main__":
    sample_data = {
        'ball_events': [
            {'over': 15, 'ball': 1, 'runs_total': 4, 'runs_boundary': 4, 
             'wicket': False, 'batsman': 'Kohli', 'bowler': 'Starc',
             'commentary': 'Crunched through covers!'},
            {'over': 15, 'ball': 2, 'runs_total': 1, 'runs_boundary': 0,
             'wicket': False, 'batsman': 'Rahul', 'bowler': 'Starc',
             'commentary': 'Worked to midwicket'},
            {'over': 15, 'ball': 3, 'runs_total': 0, 'runs_boundary': 0,
             'wicket': True, 'batsman': 'Kohli', 'bowler': 'Starc',
             'commentary': 'LBW!', 'dismissal_type': 'lbw'}
        ],
        'current_over': 15
    }
    
    analyzer = OverAnalyzer(sample_data)
    print("Over 15 Summary:", analyzer.generate_over_summary(15))
    print("Highlights:", analyzer.generate_over_highlights(15))