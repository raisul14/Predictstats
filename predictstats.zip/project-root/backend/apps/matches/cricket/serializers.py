from rest_framework import serializers
from .models import CricketTeam, CricketMatch, Player, CricketMatchStats, PlayerMatchRating

class CricketTeamSerializer(serializers.ModelSerializer):
    class Meta:
        model = CricketTeam
        fields = ['id', 'name', 'country', 'logo', 'format_specialization', 'created_at']
        read_only_fields = ['created_at']

class PlayerSerializer(serializers.ModelSerializer):
    team = CricketTeamSerializer(read_only=True)
    role_display = serializers.CharField(source='get_role_display', read_only=True)

    class Meta:
        model = Player
        fields = [
            'player_id', 'name', 'team', 'role', 'role_display',
            'is_active', 'career_stats', 'recent_performance'
        ]
        extra_kwargs = {
            'role': {'write_only': True}
        }

class CricketMatchSerializer(serializers.ModelSerializer):
    team1 = CricketTeamSerializer(read_only=True)
    team2 = CricketTeamSerializer(read_only=True)
    format_display = serializers.CharField(source='get_format_display', read_only=True)
    status_display = serializers.CharField(source='get_status_display', read_only=True)

    class Meta:
        model = CricketMatch
        fields = [
            'id', 'team1', 'team2', 'match_date', 'venue', 'format', 'format_display',
            'status', 'status_display', 'result', 'weather_data', 'toss_details'
        ]
        extra_kwargs = {
            'format': {'write_only': True},
            'status': {'write_only': True}
        }

class CricketMatchStatsSerializer(serializers.ModelSerializer):
    match_id = serializers.PrimaryKeyRelatedField(
        source='match.id', read_only=True
    )

    class Meta:
        model = CricketMatchStats
        fields = [
            'match_id', 'innings_data', 'player_performance',
            'partnership_analysis', 'powerplay_stats', 'created_at', 'last_updated'
        ]

class PredictionSerializer(serializers.Serializer):
    match_id = serializers.IntegerField()
    winner_probability = serializers.DictField(
        child=serializers.FloatField()
    )
    top_batsman = serializers.CharField()
    score_range = serializers.ListField(
        child=serializers.FloatField()
    )

class PlayerMatchRatingSerializer(serializers.ModelSerializer):
    player = serializers.StringRelatedField()
    match = serializers.StringRelatedField()

    class Meta:
        model = PlayerMatchRating
        fields = ['player', 'match', 'rating', 'rating_components', 'created_at']
        validators = [
            serializers.UniqueTogetherValidator(
                queryset=PlayerMatchRating.objects.all(),
                fields=('player', 'match'),
                message='Player already rated for this match'
            )
        ]

class OverSummarySerializer(serializers.Serializer):
    over = serializers.IntegerField()
    runs = serializers.IntegerField()
    wickets = serializers.IntegerField()
    boundaries = serializers.DictField()
    bowlers = serializers.DictField()
    timeline = serializers.ListField()
    key_moments = serializers.ListField()