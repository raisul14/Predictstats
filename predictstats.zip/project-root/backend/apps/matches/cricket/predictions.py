import pandas as pd
import joblib
import logging
from django.db.models import F
from .models import CricketMatch, Player, CricketMatchStats
from ..utils.transformation import exponential_smoothing, encode_cyclic_features

logger = logging.getLogger(__name__)

class CricketPredictionEngine:
    """Main prediction engine for cricket match outcomes"""
    
    def __init__(self):
        self.models = {
            'match_winner': joblib.load('models/cricket_winner_model.pkl'),
            'top_batsman': joblib.load('models/top_batsman_model.pkl'),
            'score_range': joblib.load('models/score_prediction_model.pkl')
        }
        self.feature_columns = [
            'venue_avg', 'team1_strength', 'team2_strength',
            'player_form', 'h2h_advantage', 'over_sin', 'over_cos'
        ]

    def preprocess_data(self, match_id: int) -> pd.DataFrame:
        """Prepare match data for model input"""
        try:
            match = CricketMatch.objects.select_related('stats').get(pk=match_id)
            stats = match.stats.innings_data
            
            # Feature Engineering
            features = {
                'venue_avg': self._get_venue_avg(match.venue),
                'team1_strength': self._calculate_team_strength(match.team1),
                'team2_strength': self._calculate_team_strength(match.team2),
                'player_form': self._get_key_player_form(match),
                'h2h_advantage': self._calculate_h2h(match.team1, match.team2),
                'over': match.current_over
            }
            
            # Cyclic encoding for over number
            features = encode_cyclic_features(
                pd.DataFrame([features]), 
                'over', 
                50
            ).to_dict('records')[0]

            return pd.DataFrame([features])[self.feature_columns]
            
        except Exception as e:
            logger.error(f"Preprocessing failed: {str(e)}")
            raise

    def predict_match(self, match_id: int) -> dict:
        """Generate predictions for a single match"""
        try:
            input_data = self.preprocess_data(match_id)
            
            return {
                'winner_probability': self.models['match_winner'].predict_proba(input_data)[0],
                'top_batsman': self.models['top_batsman'].predict(input_data)[0],
                'score_range': self.models['score_range'].predict(input_data)[0]
            }
        except Exception as e:
            logger.error(f"Prediction failed for match {match_id}: {str(e)}")
            return {'error': str(e)}

    def batch_predict(self, matches) -> list:
        """Generate predictions for multiple matches"""
        return [self.predict_match(m.id) for m in matches]

    # Helper methods
    def _get_venue_avg(self, venue: str) -> float:
        """Get average score for venue from historical data"""
        return CricketMatchStats.objects.filter(
            match__venue=venue
        ).aggregate(avg_runs=F('innings_data__avg_score'))['avg_runs'] or 0

    def _calculate_team_strength(self, team) -> float:
        """Calculate composite team strength score"""
        return (team.win_percentage * 0.6 + 
                team.recent_form * 0.3 + 
                team.ranking * 0.1)

    def _get_key_player_form(self, match) -> float:
        """Calculate exponential smoothed form of top 3 batsmen"""
        players = Player.objects.filter(
            team__in=[match.team1, match.team2],
            role='BAT'
        ).order_by('-career_stats__batting_avg')[:3]
        
        form_scores = [p.recent_performance.get('form', 0) for p in players]
        return exponential_smoothing(form_scores)[-1]

    def _calculate_h2h(self, team1, team2) -> float:
        """Calculate head-to-head advantage"""
        matches = CricketMatch.objects.filter(
            team1=team1, team2=team2
        ).count()
        
        if matches == 0:
            return 0.5  # Neutral
        
        wins = CricketMatch.objects.filter(
            team1=team1, team2=team2, result__winner=team1
        ).count()
        
        return wins / matches

# Example Usage
if __name__ == "__main__":
    engine = CricketPredictionEngine()
    sample_match = CricketMatch.objects.first()
    
    print("Single Match Prediction:")
    print(engine.predict_match(sample_match.id))
    
    print("\nBatch Predictions:")
    matches = CricketMatch.objects.filter(status='SCHEDULED')[:5]
    print(engine.batch_predict(matches))