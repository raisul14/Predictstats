from rest_framework import viewsets, status
from rest_framework.response import Response
from rest_framework.decorators import action
from django.utils import timezone
from .models import FootballMatch, MatchStats
from .serializers import (
    FootballMatchSerializer,
    PredictionSerializer,
    LiveMatchSerializer,
    MatchStatsSerializer
)
from .predictions import FootballPredictionEngine

class FootballMatchViewSet(viewsets.ReadOnlyModelViewSet):
    """
    API endpoint for football matches with prediction capabilities
    """
    queryset = FootballMatch.objects.select_related(
        'home_team', 'away_team'
    ).prefetch_related('stats').all()
    serializer_class = FootballMatchSerializer

    @action(detail=True, methods=['get'])
    def prediction(self, request, pk=None):
        """Get match-specific predictions"""
        match = self.get_object()
        engine = FootballPredictionEngine()
        
        try:
            prediction = engine.predict_match(match.id)
            serializer = PredictionSerializer({
                'match_id': match.id,
                **prediction
            })
            return Response(serializer.data)
        except Exception as e:
            return Response(
                {"error": str(e)}, 
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

class FootballPredictionView(viewsets.ViewSet):
    """
    Batch prediction endpoint for scheduled matches
    """
    def list(self, request):
        matches = FootballMatch.objects.filter(status='SCHEDULED')
        engine = FootballPredictionEngine()
        
        try:
            predictions = engine.batch_predict(matches)
            serializer = PredictionSerializer(predictions, many=True)
            return Response(serializer.data)
        except Exception as e:
            return Response(
                {"error": str(e)}, 
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

class LiveMatchesView(viewsets.ViewSet):
    """
    Real-time match tracking endpoint
    """
    def list(self, request):
        live_matches = FootballMatch.objects.filter(status='ONGOING')
        serializer = LiveMatchSerializer(live_matches, many=True)
        return Response(serializer.data)

class MatchStatsView(viewsets.ViewSet):
    """
    Detailed statistics endpoint for individual matches
    """
    def retrieve(self, request, pk=None):
        try:
            stats = MatchStats.objects.get(match_id=pk)
            serializer = MatchStatsSerializer(stats)
            return Response(serializer.data)
        except MatchStats.DoesNotExist:
            return Response(
                {"error": "Stats not found"},
                status=status.HTTP_404_NOT_FOUND
            )