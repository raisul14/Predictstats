import requests
from bs4 import BeautifulSoup
import logging
from urllib.parse import urljoin

logger = logging.getLogger(__name__)

class FBrefFetcher:
    """
    Web scraper for football match data from FBref.com
    Handles live matches, lineups, and advanced stats
    """
    
    BASE_URL = "https://fbref.com"
    HEADERS = {
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36'
    }

    def fetch_live_matches(self):
        """Get list of ongoing and upcoming matches"""
        try:
            response = requests.get(
                urljoin(self.BASE_URL, "/en/matches/"), 
                headers=self.HEADERS
            )
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            matches = []
            
            for match_row in soup.select('table.matches tbody tr'):
                try:
                    teams = [a.text for a in match_row.select('td[data-stat="squad"] a')]
                    score = match_row.select_one('td[data-stat="score"]').text
                    status = match_row.select_one('td[data-stat="status"]').text
                    match_link = match_row.select_one('td[data-stat="match_report"] a')['href']
                    
                    matches.append({
                        'teams': teams,
                        'score': score,
                        'status': status,
                        'report_url': urljoin(self.BASE_URL, match_link)
                    })
                    
                except Exception as e:
                    logger.error(f"Error parsing match row: {str(e)}")
                    continue
                    
            return matches
            
        except Exception as e:
            logger.error(f"Failed to fetch live matches: {str(e)}")
            return []

    def parse_match_report(self, report_url):
        """Extract detailed match data from report page"""
        try:
            response = requests.get(report_url, headers=self.HEADERS)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            return {
                'lineups': self._parse_lineups(soup),
                'stats': self._parse_advanced_stats(soup),
                'events': self._parse_match_events(soup)
            }
            
        except Exception as e:
            logger.error(f"Failed to parse match report: {str(e)}")
            return {}

    def _parse_lineups(self, soup):
        """Extract starting XI and substitutes"""
        lineups = {'home': [], 'away': []}
        
        for side in ['home', 'away']:
            table = soup.find('table', id=f'lineups_{side}')
            if not table:
                continue
                
            for row in table.select('tbody tr'):
                player = {
                    'name': row.select_one('th[data-stat="player"] a').text,
                    'position': row.select_one('td[data-stat="position"]').text,
                    'minutes': row.select_one('td[data-stat="minutes"]').text,
                    'rating': row.select_one('td[data-stat="fotmob_rating"]').text
                }
                lineups[side].append(player)
                
        return lineups

    def _parse_advanced_stats(self, soup):
        """Extract advanced metrics: xG, possession, passing etc."""
        stats = {}
        
        # xG Table
        xg_table = soup.find('table', id='shots_all')
        if xg_table:
            stats['expected_goals'] = {
                'home': xg_table.select('tr.away td[data-stat="xg"]')[-1].text,
                'away': xg_table.select('tr.home td[data-stat="xg"]')[-1].text
            }
        
        # Possession
        possession = soup.find('div', {'data-stat': 'possession'})
        if possession:
            stats['possession'] = {
                'home': possession.find('div', class_='home').text,
                'away': possession.find('div', class_='away').text
            }
            
        # Passing Network
        passing_table = soup.find('table', id='passing_all')
        if passing_table:
            stats['passing'] = {
                'home': self._parse_passing_stats(passing_table, 'home'),
                'away': self._parse_passing_stats(passing_table, 'away')
            }
            
        return stats

    def _parse_passing_stats(self, table, side):
        """Helper for parsing passing network data"""
        return {
            'total_passes': table.select(f'tr.{side} td[data-stat="passes"]')[0].text,
            'accuracy': table.select(f'tr.{side} td[data-stat="passes_pct"]')[0].text,
            'key_passes': table.select(f'tr.{side} td[data-stat="assisted_shots"]')[0].text
        }

    def _parse_match_events(self, soup):
        """Parse timeline of key match events"""
        events = []
        timeline = soup.find('div', id='events_wrap')
        
        for event in timeline.select('div.event'):
            events.append({
                'minute': event.select_one('div.minute').text,
                'type': event['class'][1].split('-')[-1],  # goal, card, sub
                'team': event.select_one('div.team').text,
                'player': event.select_one('div.player a').text if event.select_one('div.player a') else None,
                'description': event.select_one('div.description').text
            })
            
        return events

# Example Usage
if __name__ == "__main__":
    fetcher = FBrefFetcher()
    
    print("Live Matches:")
    for match in fetcher.fetch_live_matches()[:3]:
        print(f"{match['teams']} - {match['status']}")
    
    sample_match = 'https://fbref.com/en/matches/123456/TeamA-TeamB'
    print("\nMatch Report Analysis:")
    print(fetcher.parse_match_report(sample_match))