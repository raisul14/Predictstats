import logging
import pandas as pd
from typing import Dict, List, Union
from datetime import datetime
from .models import FootballMatch, FootballTeam

logger = logging.getLogger(__name__)

class FootballDataFormatter:
    """Formats raw football data into structured formats for storage and predictions"""
    
    @staticmethod
    def format_match_report(raw_data: Dict) -> Dict:
        """
        Convert scraped match report into database-compatible format
        
        Args:
            raw_data: Raw data from FBrefFetcher
            
        Returns:
            Dict formatted for FootballMatch model
        """
        try:
            base_data = {
                'home_team': FootballDataFormatter._get_team_id(raw_data['teams'][0]),
                'away_team': FootballDataFormatter._get_team_id(raw_data['teams'][1]),
                'match_date': datetime.strptime(raw_data.get('date', ''), '%Y-%m-%d'),
                'venue': raw_data.get('venue', 'Unknown'),
                'status': 'COMPLETED' if raw_data['score'] else 'SCHEDULED'
            }
            
            stats_data = {
                'score': raw_data['score'],
                'xg': {
                    'home': float(raw_data['stats']['expected_goals']['home']),
                    'away': float(raw_data['stats']['expected_goals']['away'])
                },
                'possession': {
                    'home': float(raw_data['stats']['possession']['home'].strip('%')),
                    'away': float(raw_data['stats']['possession']['away'].strip('%'))
                },
                'passing': raw_data['stats']['passing'],
                'shots': {
                    'total': raw_data['stats'].get('total_shots', {}),
                    'on_target': raw_data['stats'].get('shots_on_target', {})
                }
            }
            
            return {**base_data, **stats_data}
            
        except (KeyError, ValueError) as e:
            logger.error(f"Match formatting failed: {str(e)}")
            return {}

    @staticmethod
    def format_player_performance(raw_data: List[Dict]) -> List[Dict]:
        """
        Process player lineup data into standardized format
        
        Args:
            raw_data: Raw lineup data from parser
            
        Returns:
            List of player performance dictionaries
        """
        formatted = []
        for player in raw_data:
            try:
                formatted.append({
                    'player_id': player.get('id'),
                    'name': player['name'],
                    'position': player['position'],
                    'minutes': int(player['minutes']),
                    'rating': float(player['rating']),
                    'stats': {
                        'passes': player.get('passes', 0),
                        'tackles': player.get('tackles', 0),
                        'shots': player.get('shots', 0)
                    }
                })
            except KeyError as e:
                logger.warning(f"Skipping player - missing key: {str(e)}")
                continue
                
        return formatted

    @staticmethod
    def create_prediction_features(match_data: Dict) -> pd.DataFrame:
        """
        Create ML-ready features from formatted match data
        
        Args:
            match_data: Formatted match data from format_match_report()
            
        Returns:
            DataFrame with features for model prediction
        """
        try:
            features = {
                'home_xg': match_data['xg']['home'],
                'away_xg': match_data['xg']['away'],
                'possession_diff': (
                    match_data['possession']['home'] - 
                    match_data['possession']['away']
                ),
                'home_form': FootballDataFormatter._get_team_form(
                    match_data['home_team']
                ),
                'away_away_form': FootballDataFormatter._get_away_form(
                    match_data['away_team']
                ),
                'h2h_advantage': FootballDataFormatter._get_h2h(
                    match_data['home_team'], match_data['away_team']
                )
            }
            
            return pd.DataFrame([features])
            
        except KeyError as e:
            logger.error(f"Feature creation failed: {str(e)}")
            return pd.DataFrame()

    @staticmethod
    def format_predictions(prediction: Dict, match_id: int) -> Dict:
        """
        Convert model output to API-friendly format
        
        Args:
            prediction: Raw model output
            match_id: Related match ID
            
        Returns:
            Dict formatted for PredictionSerializer
        """
        return {
            'match_id': match_id,
            'home_win': prediction.get('home_win', 0),
            'draw': prediction.get('draw', 0),
            'away_win': prediction.get('away_win', 0),
            'goals_expectancy': prediction.get('goals', 0)
        }

    # Helper methods
    @staticmethod
    def _get_team_id(team_name: str) -> int:
        """Get database ID for team from name"""
        try:
            return FootballTeam.objects.get(name=team_name).id
        except FootballTeam.DoesNotExist:
            logger.error(f"Unknown team: {team_name}")
            return -1

    @staticmethod
    def _get_team_form(team_id: int, matches: int = 5) -> float:
        """Calculate recent form (avg points)"""
        # Implementation would query recent matches
        return 0.0  # Placeholder

    @staticmethod
    def _get_away_form(team_id: int) -> float:
        """Calculate away-specific form"""
        # Implementation would query away matches
        return 0.0  # Placeholder

    @staticmethod
    def _get_h2h(home_id: int, away_id: int) -> float:
        """Calculate head-to-head advantage"""
        # Implementation would query historical matches
        return 0.5  # Neutral placeholder

# Example Usage
if __name__ == "__main__":
    sample_data = {
        'teams': ['Liverpool', 'Manchester City'],
        'date': '2024-03-15',
        'venue': 'Anfield',
        'score': '2-1',
        'stats': {
            'expected_goals': {'home': '1.8', 'away': '1.2'},
            'possession': {'home': '58%', 'away': '42%'},
            'passing': {
                'home': {'total_passes': 620, 'accuracy': 89},
                'away': {'total_passes': 530, 'accuracy': 85}
            }
        }
    }
    
    formatter = FootballDataFormatter()
    formatted_match = formatter.format_match_report(sample_data)
    print("Formatted Match Data:", formatted_match)
    
    features = formatter.create_prediction_features(formatted_match)
    print("\nML Features:", features)