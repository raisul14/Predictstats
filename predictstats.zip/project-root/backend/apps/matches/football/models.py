from django.db import models
from django.contrib.auth import get_user_model

User = get_user_model()

class FootballTeam(models.Model):
    """Represents a football team with performance metrics"""
    name = models.CharField(max_length=100, unique=True)
    country = models.CharField(max_length=50)
    logo = models.URLField(max_length=300, blank=True)
    win_percentage = models.FloatField(default=0.0)
    away_performance = models.FloatField(default=0.0)
    created_at = models.DateTimeField(auto_now_add=True)
    last_updated = models.DateTimeField(auto_now=True)

    class Meta:
        indexes = [
            models.Index(fields=['win_percentage']),
            models.Index(fields=['away_performance'])
        ]

    def __str__(self):
        return f"{self.name} ({self.country})"

class FootballMatch(models.Model):
    """Represents a football match with associated metadata"""
    STATUS_CHOICES = [
        ('SCHEDULED', 'Scheduled'),
        ('ONGOING', 'Ongoing'),
        ('COMPLETED', 'Completed'),
        ('POSTPONED', 'Postponed'),
    ]
    
    home_team = models.ForeignKey(
        FootballTeam,
        on_delete=models.CASCADE,
        related_name='home_matches'
    )
    away_team = models.ForeignKey(
        FootballTeam,
        on_delete=models.CASCADE,
        related_name='away_matches'
    )
    match_date = models.DateTimeField()
    venue = models.CharField(max_length=100)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='SCHEDULED')
    result = models.JSONField(null=True, blank=True)
    weather_conditions = models.JSONField(null=True, blank=True)
    referee = models.CharField(max_length=100, blank=True)

    class Meta:
        ordering = ['-match_date']
        indexes = [
            models.Index(fields=['match_date']),
            models.Index(fields=['home_team', 'away_team'])
        ]

    def __str__(self):
        return f"{self.home_team} vs {self.away_team} - {self.match_date.date()}"

class Player(models.Model):
    """Represents a football player and their attributes"""
    POSITION_CHOICES = [
        ('GK', 'Goalkeeper'),
        ('DEF', 'Defender'),
        ('MID', 'Midfielder'),
        ('FWD', 'Forward'),
    ]
    
    player_id = models.CharField(max_length=20, unique=True)
    name = models.CharField(max_length=100)
    team = models.ForeignKey(
        FootballTeam,
        on_delete=models.CASCADE,
        related_name='players'
    )
    position = models.CharField(max_length=3, choices=POSITION_CHOICES)
    is_active = models.BooleanField(default=True)
    performance_metrics = models.JSONField(default=dict)

    class Meta:
        unique_together = ['name', 'team']
        indexes = [
            models.Index(fields=['position']),
            models.Index(fields=['is_active'])
        ]

    def __str__(self):
        return f"{self.name} ({self.get_position_display()})"

class MatchStats(models.Model):
    """Detailed statistics for a football match"""
    match = models.OneToOneField(
        FootballMatch,
        on_delete=models.CASCADE,
        related_name='stats'
    )
    expected_goals = models.JSONField()
    possession = models.JSONField()
    shots = models.JSONField()
    passing = models.JSONField()
    defensive_actions = models.JSONField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Stats for {self.match}"

class PlayerPerformance(models.Model):
    """Individual player performance in a specific match"""
    player = models.ForeignKey(Player, on_delete=models.CASCADE)
    match = models.ForeignKey(FootballMatch, on_delete=models.CASCADE)
    minutes_played = models.PositiveSmallIntegerField()
    goals = models.PositiveSmallIntegerField()
    assists = models.PositiveSmallIntegerField()
    passes = models.JSONField()
    defensive_actions = models.JSONField()
    rating = models.FloatField()

    class Meta:
        unique_together = ['player', 'match']
        indexes = [
            models.Index(fields=['rating']),
            models.Index(fields=['goals', 'assists'])
        ]

    def __str__(self):
        return f"{self.player} performance vs {self.match.away_team}"