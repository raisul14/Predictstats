import pandas as pd
import joblib
import logging
from django.db.models import F, Q
from .models import FootballMatch, FootballTeam, MatchStats
from ..utils.transformation import calculate_momentum, encode_cyclic_features

logger = logging.getLogger(__name__)

class FootballPredictionEngine:
    """Main prediction engine for football match outcomes"""
    
    def __init__(self):
        self.models = {
            '1x2': joblib.load('models/football_1x2_model.pkl'),
            'over_under': joblib.load('models/over_under_model.pkl'),
            'correct_score': joblib.load('models/correct_score_model.pkl')
        }
        self.feature_columns = [
            'home_xg', 'away_xg', 'possession_diff', 
            'home_form', 'away_away_form', 'h2h_advantage',
            'days_rest', 'ref_strictness'
        ]

    def preprocess_features(self, match: FootballMatch) -> pd.DataFrame:
        """Transform raw match data into ML-ready features"""
        try:
            features = {
                'home_xg': self._get_team_xg(match.home_team),
                'away_xg': self._get_away_xg(match.away_team),
                'possession_diff': self._get_possession_diff(match),
                'home_form': self._calculate_form(match.home_team),
                'away_away_form': self._calculate_away_form(match.away_team),
                'h2h_advantage': self._get_h2h_advantage(match.home_team, match.away_team),
                'days_rest': self._get_days_rest(match),
                'ref_strictness': self._get_referee_strictness(match.referee)
            }
            
            return pd.DataFrame([features])[self.feature_columns]
            
        except Exception as e:
            logger.error(f"Feature preprocessing failed: {str(e)}")
            raise

    def predict_match(self, match_id: int) -> dict:
        """Generate predictions for a single match"""
        try:
            match = FootballMatch.objects.get(pk=match_id)
            features = self.preprocess_features(match)
            
            return {
                '1x2': self.models['1x2'].predict_proba(features)[0],
                'over_under': self.models['over_under'].predict(features)[0],
                'correct_score': self.models['correct_score'].predict_proba(features)[0]
            }
        except Exception as e:
            logger.error(f"Prediction failed for match {match_id}: {str(e)}")
            return {'error': str(e)}

    def batch_predict(self, matches) -> list:
        """Generate predictions for multiple matches"""
        return [self.predict_match(m.id) for m in matches]

    # Feature calculation methods
    def _get_team_xg(self, team: FootballTeam) -> float:
        """Get average xG for team's home matches"""
        return MatchStats.objects.filter(match__home_team=team).aggregate(
            avg_xg=F('expected_goals__home')
        )['avg_xg'] or 0.0

    def _get_away_xg(self, team: FootballTeam) -> float:
        """Get average xG for team's away matches"""
        return MatchStats.objects.filter(match__away_team=team).aggregate(
            avg_xg=F('expected_goals__away')
        )['avg_xg'] or 0.0

    def _get_possession_diff(self, match: FootballMatch) -> float:
        """Calculate possession difference from historical average"""
        home_avg = MatchStats.objects.filter(match__home_team=match.home_team).aggregate(
            avg_poss=F('possession__home')
        )['avg_poss'] or 50.0
        
        away_avg = MatchStats.objects.filter(match__away_team=match.away_team).aggregate(
            avg_poss=F('possession__away')
        )['avg_poss'] or 50.0
        
        return home_avg - away_avg

    def _calculate_form(self, team: FootballTeam, matches=5) -> float:
        """Calculate weighted average form"""
        recent = FootballMatch.objects.filter(
            Q(home_team=team) | Q(away_team=team),
            status='COMPLETED'
        ).order_by('-match_date')[:matches]
        
        points = [m.result.get('points', 0) for m in recent if m.result]
        return calculate_momentum(pd.Series(points)).iloc[-1]

    def _calculate_away_form(self, team: FootballTeam) -> float:
        """Calculate away-specific form"""
        away_matches = FootballMatch.objects.filter(
            away_team=team,
            status='COMPLETED'
        ).order_by('-match_date')[:5]
        
        return sum(m.result.get('points', 0) for m in away_matches) / len(away_matches) if away_matches else 0.0

    def _get_h2h_advantage(self, home: FootballTeam, away: FootballTeam) -> float:
        """Calculate head-to-head advantage"""
        total = FootballMatch.objects.filter(home_team=home, away_team=away).count()
        if total == 0:
            return 0.5
        wins = FootballMatch.objects.filter(
            home_team=home, 
            away_team=away,
            result__winner=home
        ).count()
        return wins / total

    def _get_days_rest(self, match: FootballMatch) -> int:
        """Days since last match for both teams"""
        last_home = FootballMatch.objects.filter(
            Q(home_team=match.home_team) | Q(away_team=match.home_team),
            match_date__lt=match.match_date
        ).order_by('-match_date').first()
        
        last_away = FootballMatch.objects.filter(
            Q(home_team=match.away_team) | Q(away_team=match.away_team),
            match_date__lt=match.match_date
        ).order_by('-match_date').first()
        
        return min(
            (match.match_date - last_home.match_date).days if last_home else 14,
            (match.match_date - last_away.match_date).days if last_away else 14
        )

    def _get_referee_strictness(self, ref_name: str) -> float:
        """Calculate referee strictness index"""
        matches = FootballMatch.objects.filter(referee=ref_name).exclude(result=None)
        if not matches:
            return 0.5
            
        avg_cards = sum(m.result.get('total_cards', 0) for m in matches) / len(matches)
        return avg_cards / 10.0  # Normalize to 0-1 scale

# Example Usage
if __name__ == "__main__":
    engine = FootballPredictionEngine()
    sample_match = FootballMatch.objects.first()
    
    print("Single Match Prediction:")
    print(engine.predict_match(sample_match.id))
    
    print("\nBatch Predictions:")
    matches = FootballMatch.objects.filter(status='SCHEDULED')[:5]
    print(engine.batch_predict(matches))