from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter()
router.register(r'', views.FootballMatchViewSet, basename='football')

urlpatterns = [
    path('', include(router.urls)),
    path('predictions/', views.FootballPredictionView.as_view(), name='football-predictions'),
    path('live/', views.LiveMatchesView.as_view(), name='live-football'),
    path('stats/<int:match_id>/', views.MatchStatsView.as_view(), name='match-stats')
]