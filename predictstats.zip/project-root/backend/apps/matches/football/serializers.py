from rest_framework import serializers
from .models import FootballTeam, FootballMatch, Player, MatchStats, PlayerPerformance

class FootballTeamSerializer(serializers.ModelSerializer):
    class Meta:
        model = FootballTeam
        fields = [
            'id', 'name', 'country', 'logo', 
            'win_percentage', 'away_performance', 
            'created_at', 'last_updated'
        ]
        read_only_fields = ['created_at', 'last_updated']

class FootballMatchSerializer(serializers.ModelSerializer):
    home_team = FootballTeamSerializer(read_only=True)
    away_team = FootballTeamSerializer(read_only=True)
    status_display = serializers.CharField(
        source='get_status_display', 
        read_only=True
    )

    class Meta:
        model = FootballMatch
        fields = [
            'id', 'home_team', 'away_team', 'match_date',
            'venue', 'status', 'status_display', 'result',
            'weather_conditions', 'referee'
        ]
        extra_kwargs = {
            'status': {'write_only': True},
            'result': {'read_only': True}
        }

class PlayerSerializer(serializers.ModelSerializer):
    team = FootballTeamSerializer(read_only=True)
    position_display = serializers.CharField(
        source='get_position_display', 
        read_only=True
    )

    class Meta:
        model = Player
        fields = [
            'player_id', 'name', 'team', 'position',
            'position_display', 'is_active', 'performance_metrics'
        ]
        extra_kwargs = {
            'position': {'write_only': True}
        }

class MatchStatsSerializer(serializers.ModelSerializer):
    match_id = serializers.PrimaryKeyRelatedField(
        source='match.id',
        read_only=True
    )

    class Meta:
        model = MatchStats
        fields = [
            'match_id', 'expected_goals', 'possession',
            'shots', 'passing', 'defensive_actions',
            'created_at'
        ]

class PlayerPerformanceSerializer(serializers.ModelSerializer):
    player = serializers.StringRelatedField()
    match = serializers.StringRelatedField()

    class Meta:
        model = PlayerPerformance
        fields = [
            'player', 'match', 'minutes_played',
            'goals', 'assists', 'passes',
            'defensive_actions', 'rating'
        ]
        validators = [
            serializers.UniqueTogetherValidator(
                queryset=PlayerPerformance.objects.all(),
                fields=('player', 'match'),
                message='Player already has performance data for this match'
            )
        ]

class PredictionSerializer(serializers.Serializer):
    match_id = serializers.IntegerField()
    home_win = serializers.FloatField(min_value=0, max_value=1)
    draw = serializers.FloatField(min_value=0, max_value=1)
    away_win = serializers.FloatField(min_value=0, max_value=1)
    goals_expectancy = serializers.FloatField(min_value=0)
    likely_scorelines = serializers.DictField(
        child=serializers.FloatField()
    )

    def validate(self, data):
        """Ensure probability sum doesn't exceed 1"""
        total_prob = data['home_win'] + data['draw'] + data['away_win']
        if not 0.99 <= total_prob <= 1.01:
            raise serializers.ValidationError(
                "Total probability must sum to 1"
            )
        return data

class LiveMatchSerializer(serializers.ModelSerializer):
    home_team = serializers.StringRelatedField()
    away_team = serializers.StringRelatedField()
    time_elapsed = serializers.SerializerMethodField()

    class Meta:
        model = FootballMatch
        fields = [
            'id', 'home_team', 'away_team',
            'status', 'time_elapsed', 'result'
        ]

    def get_time_elapsed(self, obj):
        if obj.status == 'ONGOING':
            return (obj.match_date - timezone.now()).total_seconds() // 60
        return None