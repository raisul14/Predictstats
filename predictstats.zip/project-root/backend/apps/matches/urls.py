from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .football.views import FootballMatchViewSet, FootballPredictionView
from .cricket.views import CricketMatchViewSet, CricketPredictionView

router = DefaultRouter()
router.register(r'football', FootballMatchViewSet, basename='football-matches')
router.register(r'cricket', CricketMatchViewSet, basename='cricket-matches')

urlpatterns = [
    path('', include(router.urls)),
    
    # Football predictions
    path('football/predictions/',
         FootballPredictionView.as_view({'get': 'list'}),
         name='football-predictions'),
    
    # Cricket predictions 
    path('cricket/predictions/',
         CricketPredictionView.as_view({'get': 'list'}),
         name='cricket-predictions'),
    
    # Live match endpoints
    path('football/live/', include('matches.football.urls')),
    path('cricket/live/', include('matches.cricket.urls')),
]