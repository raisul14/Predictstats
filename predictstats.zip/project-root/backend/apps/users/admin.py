from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User

class CustomUserAdmin(UserAdmin):
    model = User
    list_display = (
        'username', 
        'email', 
        'is_active',
        'is_staff', 
        'date_joined', 
        'last_login',
        'subscription_status'
    )
    list_filter = ('is_staff', 'is_active', 'date_joined')
    search_fields = ('username', 'email', 'first_name', 'last_name')
    ordering = ('-date_joined',)
    
    fieldsets = (
        (None, {'fields': ('username', 'password')}),
        ('Personal Info', {
            'fields': (
                'first_name', 
                'last_name', 
                'email', 
                'phone'
            )
        }),
        ('Permissions', {
            'fields': (
                'is_active',
                'is_staff', 
                'is_superuser',
                'groups', 
                'user_permissions'
            )
        }),
        ('Subscription', {
            'fields': (
                'subscription_tier', 
                'subscription_expiry',
                'payment_method'
            )
        }),
        ('Important Dates', {
            'fields': (
                'last_login', 
                'date_joined'
            )
        }),
    )
    
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': (
                'username', 
                'email', 
                'password1', 
                'password2',
                'is_staff', 
                'is_active'
            )
        }),
    )
    
    def subscription_status(self, obj):
        if obj.subscription_expiry:
            return "Active" if obj.subscription_expiry > timezone.now() else "Expired"
        return "Inactive"
    subscription_status.short_description = 'Subscription Status'

admin.site.register(User, CustomUserAdmin)