from django.test import TestCase
from django.contrib.auth import get_user_model
from rest_framework.test import APITestCase, APIClient
from rest_framework import status
from .models import Team, UserActivity
from .serializers import UserRegistrationSerializer

User = get_user_model()

class UserModelTests(TestCase):
    def setUp(self):
        self.user_data = {
            'username': 'testuser',
            'email': 'test@predictstats.com',
            'password': 'Testpass123'
        }

    def test_create_user(self):
        user = User.objects.create_user(**self.user_data)
        self.assertEqual(user.email, self.user_data['email'])
        self.assertTrue(user.check_password(self.user_data['password']))
        self.assertFalse(user.is_superuser)
        self.assertTrue(user.is_active)

    def test_create_superuser(self):
        admin = User.objects.create_superuser(
            email='admin@predictstats.com',
            username='admin',
            password='Adminpass123'
        )
        self.assertTrue(admin.is_staff)
        self.assertTrue(admin.is_superuser)

class RegistrationSerializerTests(TestCase):
    def test_valid_registration(self):
        data = {
            'username': 'newuser',
            'email': 'new@predictstats.com',
            'password': 'Newpass123',
            'password2': 'Newpass123'
        }
        serializer = UserRegistrationSerializer(data=data)
        self.assertTrue(serializer.is_valid())

    def test_password_mismatch(self):
        data = {
            'username': 'newuser',
            'email': 'new@predictstats.com',
            'password': 'Newpass123',
            'password2': 'Wrongpass'
        }
        serializer = UserRegistrationSerializer(data=data)
        self.assertFalse(serializer.is_valid())
        self.assertIn('password', serializer.errors)

class UserViewTests(APITestCase):
    def setUp(self):
        self.client = APIClient()
        self.user = User.objects.create_user(
            username='viewuser',
            email='view@predictstats.com',
            password='Testpass123'
        )

    def test_registration_view(self):
        url = '/api/users/register/'
        data = {
            'username': 'registertest',
            'email': 'register@predictstats.com',
            'password': 'Testpass123',
            'password2': 'Testpass123'
        }
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

    def test_profile_access(self):
        self.client.force_authenticate(user=self.user)
        response = self.client.get('/api/users/me/')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['email'], self.user.email)

class TeamTests(APITestCase):
    def setUp(self):
        self.admin = User.objects.create_superuser(
            username='teamadmin',
            email='teamadmin@predictstats.com',
            password='Adminpass123'
        )
        self.user1 = User.objects.create_user(
            username='member1',
            email='member1@predictstats.com',
            password='Testpass123'
        )

    def test_team_creation(self):
        self.client.force_authenticate(user=self.admin)
        data = {'name': 'Test Team', 'members': [self.user1.id]}
        response = self.client.post('/api/teams/', data)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(response.data['name'], 'Test Team')

class PermissionTests(APITestCase):
    def setUp(self):
        self.user1 = User.objects.create_user(
            username='permuser1',
            email='perm1@predictstats.com',
            password='Testpass123'
        )
        self.user2 = User.objects.create_user(
            username='permuser2',
            email='perm2@predictstats.com',
            password='Testpass123'
        )

    def test_self_edit_permission(self):
        self.client.force_authenticate(user=self.user1)
        url = f'/api/users/{self.user1.id}/'
        data = {'first_name': 'Updated'}
        response = self.client.patch(url, data)
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_other_user_edit_permission(self):
        self.client.force_authenticate(user=self.user1)
        url = f'/api/users/{self.user2.id}/'
        response = self.client.patch(url, {})
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)

class ActivityLoggingTests(TestCase):
    def test_activity_creation(self):
        user = User.objects.create_user(
            username='activityuser',
            email='activity@predictstats.com',
            password='Testpass123'
        )
        activity = UserActivity.objects.create(
            user=user,
            action_type='login',
            ip_address='127.0.0.1'
        )
        self.assertEqual(activity.user, user)
        self.assertEqual(activity.action_type, 'login')

class SecurityTests(APITestCase):
    def test_jwt_auth(self):
        user = User.objects.create_user(
            username='authuser',
            email='auth@predictstats.com',
            password='Testpass123'
        )
        data = {'username': 'authuser', 'password': 'Testpass123'}
        response = self.client.post('/api/auth/login/', data)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('access', response.data)

    def test_password_strength(self):
        data = {
            'username': 'weakpass',
            'email': 'weak@predictstats.com',
            'password': '123',
            'password2': '123'
        }
        serializer = UserRegistrationSerializer(data=data)
        self.assertFalse(serializer.is_valid())
        self.assertIn('password', serializer.errors)