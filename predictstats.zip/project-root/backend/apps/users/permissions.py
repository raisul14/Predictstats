from rest_framework.permissions import BasePermission
from django.contrib.auth.models import Group

class IsSuperAdmin(BasePermission):
    """
    Grants access only to super admin users
    """
    message = "Super administrator access required"

    def has_permission(self, request, view):
        return bool(request.user and request.user.is_superuser)

class IsModerator(BasePermission):
    """
    Allows access to users with moderator privileges
    """
    message = "Moderator permissions required"

    def has_permission(self, request, view):
        return bool(
            request.user and
            Group.objects.get(name='Moderator') in request.user.groups.all()
        )

class IsAnalyst(BasePermission):
    """
    Restricts access to read-only analyst users
    """
    message = "Analyst access permissions required"

    def has_permission(self, request, view):
        return bool(
            request.user and
            Group.objects.get(name='Analyst') in request.user.groups.all() and
            request.method in ('GET', 'HEAD', 'OPTIONS')
        )

class IsTeamMember(BasePermission):
    """
    Validates user belongs to any team
    """
    message = "Team membership required"

    def has_permission(self, request, view):
        return bool(request.user and request.user.team)

class IsTeamOwner(BasePermission):
    """
    Grants access to team administrators/owners
    """
    message = "Team ownership required"

    def has_permission(self, request, view):
        return bool(
            request.user and 
            request.user.team and
            request.user.team.owner == request.user
        )

class IsSelfOrAdmin(BasePermission):
    """
    Allows users to modify their own profile or admins
    """
    message = "You can only modify your own profile"

    def has_object_permission(self, request, view, obj):
        return bool(obj == request.user or request.user.is_staff)

class ColumnAccessPermission(BasePermission):
    """
    Enforces column-level data access controls
    """
    def has_permission(self, request, view):
        allowed_columns = getattr(view, 'allowed_columns', [])
        return all(
            field in allowed_columns
            for field in request.data.keys()
        )

class TimeBoundAccess(BasePermission):
    """
    Restricts access during specified time windows
    """
    def has_permission(self, request, view):
        access_window = getattr(view, 'access_window', None)
        if not access_window:
            return True
        return access_window.is_active()

class IPRestrictedAccess(BasePermission):
    """
    Limits access to specific IP ranges
    """
    allowed_ips = ['192.168.1.0/24', '10.0.0.0/8']
    
    def has_permission(self, request, view):
        client_ip = request.META.get('REMOTE_ADDR')
        return any(
            ipaddress.ip_address(client_ip) in ipaddress.ip_network(net)
            for net in self.allowed_ips
        ) 