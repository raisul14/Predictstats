from django.contrib.auth.models import AbstractUser
from django.db import models
from django.utils import timezone

class User(AbstractUser):
    # Authentication fields
    email = models.EmailField(unique=True)
    phone = models.CharField(max_length=20, blank=True, null=True)
    
    # Subscription integration
    subscription = models.OneToOneField(
        'subscriptions.Subscription',
        on_delete=models.SET_NULL,
        blank=True,
        null=True,
        related_name='user_profile'
    )
    
    # Team features
    team = models.ForeignKey(
        'users.Team',
        on_delete=models.SET_NULL,
        blank=True,
        null=True,
        related_name='members'
    )
    
    # Security settings
    tfa_enabled = models.BooleanField(default=False)
    last_password_reset = models.DateTimeField(auto_now_add=True)
    
    # Tracking
    last_activity = models.DateTimeField(auto_now=True)
    data_consent = models.DateTimeField(null=True, blank=True)

    class Meta:
        indexes = [
            models.Index(fields=['email']),
            models.Index(fields=['subscription']),
            models.Index(fields=['last_login']),
        ]

    @property
    def subscription_tier(self):
        return self.subscription.plan.tier if self.subscription else 'free'

    @property
    def subscription_expiry(self):
        return self.subscription.expires_on if self.subscription else None

    @property
    def is_subscribed(self):
        return bool(
            self.subscription and 
            self.subscription.expires_on > timezone.now()
        )

class Team(models.Model):
    name = models.CharField(max_length=100, unique=True)
    owner = models.ForeignKey(
        User, 
        on_delete=models.CASCADE,
        related_name='owned_teams'
    )
    created_at = models.DateTimeField(auto_now_add=True)
    subscription = models.OneToOneField(
        'subscriptions.Subscription',
        on_delete=models.SET_NULL,
        blank=True,
        null=True
    )

    def __str__(self):
        return f"{self.name} Team"

class UserActivity(models.Model):
    ACTION_CHOICES = [
        ('login', 'User Login'),
        ('prediction', 'Made Prediction'),
        ('subscription', 'Subscription Change'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE)
    action_type = models.CharField(max_length=20, choices=ACTION_CHOICES)
    timestamp = models.DateTimeField(auto_now_add=True)
    ip_address = models.GenericIPAddressField()
    user_agent = models.TextField(blank=True)

    class Meta:
        ordering = ['-timestamp']
        verbose_name_plural = 'User Activities'