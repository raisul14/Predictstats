from rest_framework import serializers
from django.contrib.auth import authenticate
from django.contrib.auth.password_validation import validate_password
from .models import User, Team, UserActivity

class UserRegistrationSerializer(serializers.ModelSerializer):
    password = serializers.CharField(
        write_only=True,
        required=True,
        validators=[validate_password]
    )
    password2 = serializers.CharField(write_only=True, required=True)

    class Meta:
        model = User
        fields = [
            'username',
            'email',
            'password',
            'password2',
            'first_name',
            'last_name',
            'phone'
        ]
        extra_kwargs = {
            'email': {'required': True},
            'username': {'required': True}
        }

    def validate(self, attrs):
        if attrs['password'] != attrs['password2']:
            raise serializers.ValidationError({"password": "Passwords must match"})
        if User.objects.filter(email=attrs['email']).exists():
            raise serializers.ValidationError({"email": "Email already registered"})
        return attrs

    def create(self, validated_data):
        user = User.objects.create_user(
            username=validated_data['username'],
            email=validated_data['email'],
            password=validated_data['password'],
            first_name=validated_data.get('first_name', ''),
            last_name=validated_data.get('last_name', ''),
            phone=validated_data.get('phone', None)
        )
        return user

class UserLoginSerializer(serializers.Serializer):
    username = serializers.CharField()
    password = serializers.CharField(write_only=True)
    tfa_code = serializers.CharField(required=False, allow_blank=True)

    def validate(self, data):
        user = authenticate(
            username=data.get('username'),
            password=data.get('password')
        )
        
        if not user:
            raise serializers.ValidationError("Invalid credentials")
        
        if user.tfa_enabled and not data.get('tfa_code'):
            raise serializers.ValidationError("2FA code required")
        
        return {'user': user}

class UserProfileSerializer(serializers.ModelSerializer):
    subscription_status = serializers.SerializerMethodField()
    team = serializers.SlugRelatedField(
        slug_field='name',
        queryset=Team.objects.all(),
        required=False
    )

    class Meta:
        model = User
        fields = [
            'id',
            'username',
            'email',
            'first_name',
            'last_name',
            'phone',
            'subscription_status',
            'team',
            'last_login',
            'date_joined'
        ]
        read_only_fields = ['id', 'subscription_status', 'last_login', 'date_joined']

    def get_subscription_status(self, obj):
        return {
            'tier': obj.subscription_tier,
            'expires': obj.subscription_expiry,
            'active': obj.is_subscribed
        }

class TeamSerializer(serializers.ModelSerializer):
    members = serializers.PrimaryKeyRelatedField(
        many=True,
        queryset=User.objects.all(),
        required=False
    )
    owner = serializers.HiddenField(default=serializers.CurrentUserDefault())

    class Meta:
        model = Team
        fields = ['id', 'name', 'owner', 'members', 'created_at']
        read_only_fields = ['id', 'created_at']

    def validate_members(self, value):
        if len(value) > 10:
            raise serializers.ValidationError("Teams limited to 10 members")
        return value

class PasswordChangeSerializer(serializers.Serializer):
    old_password = serializers.CharField(required=True)
    new_password = serializers.CharField(
        required=True,
        validators=[validate_password]
    )

class UserActivitySerializer(serializers.ModelSerializer):
    user = serializers.StringRelatedField()

    class Meta:
        model = UserActivity
        fields = ['user', 'action_type', 'timestamp', 'ip_address']
        read_only_fields = fields