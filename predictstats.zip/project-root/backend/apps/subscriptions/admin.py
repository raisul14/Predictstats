from django.contrib import admin
from .models import SubscriptionPlan, UserSubscription

@admin.register(SubscriptionPlan)
class SubscriptionPlanAdmin(admin.ModelAdmin):
    list_display = (
        'name', 'price', 'prediction_limit', 
        'analytics_access', 'refresh_interval', 
        'api_access', 'active'
    )
    list_filter = ('active', 'analytics_access', 'api_access')
    search_fields = ('name', 'description')
    ordering = ('price',)
    fieldsets = (
        (None, {'fields': ('name', 'description', 'active')}),
        ('Features', {'fields': (
            'prediction_limit', 
            'analytics_access', 
            'refresh_interval',
            'api_access'
        )}),
        ('Pricing', {'fields': ('price',)})
    )

@admin.register(UserSubscription)
class UserSubscriptionAdmin(admin.ModelAdmin):
    list_display = (
        'user', 'plan', 'start_date', 
        'end_date', 'is_active', 'stripe_subscription_id'
    )
    list_filter = ('plan', 'is_active')
    search_fields = (
        'user__email', 
        'plan__name', 
        'stripe_subscription_id'
    )
    raw_id_fields = ('user',)
    readonly_fields = ('start_date',)
    date_hierarchy = 'end_date'

    def is_active(self, obj):
        return obj.is_active
    is_active.boolean = True
    is_active.short_description = 'Active'