from rest_framework import status, generics
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.viewsets import ModelViewSet
from django.utils import timezone
from .models import Subscription, Plan, PaymentMethod
from .serializers import (
    PlanSerializer,
    SubscriptionSerializer,
    SubscriptionUpgradeSerializer,
    PaymentMethodSerializer,
    TrialActivationSerializer,
    SubscriptionCancelSerializer
)
from .permissions import (
    CanModifySubscription, 
    HasPremiumTier,
    IsSubscribed,
    TeamPlanAccess
)
from .payments import create_payment_intent, stripe_webhook, confirm_subscription

class PlanViewSet(ModelViewSet):
    queryset = Plan.objects.all()
    serializer_class = PlanSerializer
    permission_classes = [CanModifySubscription]

    def get_queryset(self):
        if self.request.user.is_staff:
            return super().get_queryset()
        return Plan.objects.filter(is_active=True)

class ActivePlanList(generics.ListAPIView):
    serializer_class = PlanSerializer
    queryset = Plan.objects.filter(is_active=True)

class SubscriptionDetail(generics.RetrieveUpdateAPIView):
    serializer_class = SubscriptionSerializer
    permission_classes = [CanModifySubscription]

    def get_object(self):
        return self.request.user.subscription

class TrialActivation(generics.CreateAPIView):
    serializer_class = TrialActivationSerializer
    permission_classes = [~IsSubscribed]

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        
        # Trial activation logic
        subscription = Subscription.start_trial(user=request.user)
        return Response(
            SubscriptionSerializer(subscription).data,
            status=status.HTTP_201_CREATED
        )

class SubscriptionUpgrade(APIView):
    permission_classes = [IsSubscribed, CanModifySubscription]

    def post(self, request):
        serializer = SubscriptionUpgradeSerializer(
            data=request.data,
            context={'request': request}
        )
        serializer.is_valid(raise_exception=True)
        
        # Upgrade logic
        new_plan = Plan.objects.get(id=serializer.validated_data['plan_id'])
        request.user.subscription.upgrade(new_plan)
        return Response(
            {'status': 'upgraded', 'new_plan': new_plan.name},
            status=status.HTTP_200_OK
        )

class SubscriptionCancel(APIView):
    permission_classes = [CanModifySubscription]

    def post(self, request):
        serializer = SubscriptionCancelSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        
        # Cancellation logic
        request.user.subscription.cancel()
        return Response(
            {'status': 'cancelled', 'expires': request.user.subscription.expires_on},
            status=status.HTTP_200_OK
        )

class PaymentMethodList(generics.ListCreateAPIView):
    serializer_class = PaymentMethodSerializer
    permission_classes = [IsSubscribed]

    def get_queryset(self):
        return PaymentMethod.objects.filter(user=self.request.user)

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)

class PaymentMethodDetail(generics.RetrieveDestroyAPIView):
    serializer_class = PaymentMethodSerializer
    permission_classes = [CanModifySubscription]

    def get_queryset(self):
        return PaymentMethod.objects.filter(user=self.request.user)