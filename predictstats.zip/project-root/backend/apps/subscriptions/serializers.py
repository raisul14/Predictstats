from rest_framework import serializers
from django.utils import timezone
from .models import Subscription, Plan
from apps.users.models import User

class PlanSerializer(serializers.ModelSerializer):
    class Meta:
        model = Plan
        fields = [
            'id', 
            'name', 
            'price', 
            'duration_days',
            'features',
            'tier_level',
            'is_active'
        ]
        read_only_fields = ['id', 'tier_level']

class SubscriptionSerializer(serializers.ModelSerializer):
    plan = PlanSerializer(read_only=True)
    days_remaining = serializers.SerializerMethodField()
    
    class Meta:
        model = Subscription
        fields = [
            'id',
            'user',
            'plan',
            'start_date',
            'expires_on',
            'status',
            'payment_method',
            'days_remaining',
            'auto_renew'
        ]
        read_only_fields = [
            'id', 
            'user', 
            'start_date', 
            'expires_on',
            'days_remaining'
        ]

    def get_days_remaining(self, obj):
        return (obj.expires_on - timezone.now()).days if obj.expires_on else 0

class SubscriptionUpgradeSerializer(serializers.Serializer):
    plan_id = serializers.IntegerField()
    prorated_amount = serializers.DecimalField(
        max_digits=8, 
        decimal_places=2,
        read_only=True
    )

    def validate_plan_id(self, value):
        if not Plan.objects.filter(id=value, is_active=True).exists():
            raise serializers.ValidationError("Invalid plan selection")
        return value

    def validate(self, data):
        user = self.context['request'].user
        current_plan = user.subscription.plan
        new_plan = Plan.objects.get(id=data['plan_id'])
        
        if new_plan.tier_level <= current_plan.tier_level:
            raise serializers.ValidationError(
                "Must select higher tier for upgrade"
            )
            
        return data

class PaymentMethodSerializer(serializers.Serializer):
    payment_token = serializers.CharField(
        max_length=200, 
        write_only=True,
        required=True
    )
    save_method = serializers.BooleanField(default=True)

class TrialActivationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Subscription
        fields = ['start_date', 'expires_on']
        read_only_fields = ['start_date', 'expires_on']

    def validate(self, attrs):
        user = self.instance.user
        if user.subscription_set.filter(status__in=['active', 'trialing']).exists():
            raise serializers.ValidationError(
                "Trial already used for this account"
            )
        return attrs

class SubscriptionCancelSerializer(serializers.Serializer):
    confirmation = serializers.CharField(
        required=True,
        help_text="Type 'CONFIRM CANCEL' to proceed"
    )

    def validate_confirmation(self, value):
        if value.strip().lower() != 'confirm cancel':
            raise serializers.ValidationError(
                "Invalid cancellation confirmation"
            )
        return value