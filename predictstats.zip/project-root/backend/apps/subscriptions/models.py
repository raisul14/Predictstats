from django.db import models
from django.contrib.auth import get_user_model

User = get_user_model()

class SubscriptionPlan(models.Model):
    """Represents different subscription tiers with feature sets"""
    name = models.CharField(max_length=20, unique=True)
    description = models.TextField(blank=True)
    price = models.DecimalField(
        max_digits=6, 
        decimal_places=2,
        help_text="Monthly price in USD"
    )
    prediction_limit = models.PositiveIntegerField(
        null=True,
        blank=True,
        help_text="Null = unlimited predictions"
    )
    analytics_access = models.BooleanField(default=False)
    refresh_interval = models.PositiveSmallIntegerField(
        default=60,
        help_text="Data refresh interval in minutes"
    )
    api_access = models.BooleanField(
        default=False,
        help_text="Access to prediction APIs"
    )
    active = models.BooleanField(
        default=True,
        help_text="Displayed in public pricing"
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['price']
        verbose_name = "Subscription Plan"
        verbose_name_plural = "Subscription Plans"

    def __str__(self):
        return f"{self.name} (${self.price}/mo)"

class UserSubscription(models.Model):
    """Tracks user subscription status and entitlements"""
    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        related_name='subscription'
    )
    plan = models.ForeignKey(
        SubscriptionPlan,
        on_delete=models.PROTECT,
        related_name='subscribers'
    )
    start_date = models.DateTimeField(auto_now_add=True)
    end_date = models.DateTimeField()
    is_active = models.BooleanField(default=True)
    stripe_subscription_id = models.CharField(
        max_length=255,
        blank=True,
        help_text="Stripe subscription ID for billing management"
    )

    class Meta:
        verbose_name = "User Subscription"
        verbose_name_plural = "User Subscriptions"
        indexes = [
            models.Index(fields=['end_date']),
            models.Index(fields=['is_active'])
        ]

    def __str__(self):
        return f"{self.user.email} - {self.plan.name}"

    @property
    def days_remaining(self):
        """Calculate days until subscription expiration"""
        from django.utils import timezone
        return (self.end_date - timezone.now()).days