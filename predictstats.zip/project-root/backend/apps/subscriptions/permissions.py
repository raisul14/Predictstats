from rest_framework.permissions import BasePermission
from django.utils import timezone

class IsSubscribed(BasePermission):
    """
    Allows access only to users with active subscriptions
    """
    message = "Active subscription required - Upgrade your account"

    def has_permission(self, request, view):
        return bool(
            request.user and 
            request.user.subscription and
            request.user.subscription.is_active and
            request.user.subscription.expires_on > timezone.now()
        )

class HasPremiumTier(BasePermission):
    """
    Grants access to premium-tier subscription features
    """
    message = "Premium subscription required to access this feature"

    def has_permission(self, request, view):
        return bool(
            request.user and
            request.user.subscription and
            request.user.subscription.tier == 'premium'
        )

class IsSubscriptionOwner(BasePermission):
    """
    Allows access only to the owner of a subscription
    """
    def has_object_permission(self, request, view, obj):
        return obj.user == request.user

class CanModifySubscription(BasePermission):
    """
    Combines admin access with subscription ownership rules
    """
    def has_permission(self, request, view):
        # Admins can modify any subscription
        if request.user.role in ['admin', 'super_admin']:
            return True
            
        # Users can only modify their own
        return view.action in ['retrieve', 'update', 'partial_update']

    def has_object_permission(self, request, view, obj):
        return obj.user == request.user or request.user.is_staff

class TeamPlanAccess(BasePermission):
    """
    Validates team-based subscription access
    """
    message = "Your team subscription has expired or is inactive"

    def has_permission(self, request, view):
        if not request.user.team:
            return False
            
        subscription = request.user.team.subscription
        return bool(
            subscription and
            subscription.is_active and
            subscription.expires_on > timezone.now()
        )