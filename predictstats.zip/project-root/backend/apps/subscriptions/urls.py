from django.urls import path
from rest_framework.routers import DefaultRouter
from . import views
from .permissions import IsSubscribed, HasPremiumTier, CanModifySubscription

router = DefaultRouter()
router.register(r'plans', views.PlanViewSet, basename='plan')

urlpatterns = [
    # Plan management
    path('plans/active/', views.ActivePlanList.as_view(), name='active-plans'),
    
    # Subscription lifecycle
    path('subscription/', views.SubscriptionDetail.as_view(), 
         name='subscription-detail'),
    path('subscription/start-trial/', views.TrialActivation.as_view(),
         name='start-trial'),
    
    # Payment processing
    path('payment/intent/', views.create_payment_intent, 
         name='create-payment-intent'),
    path('payment/webhook/', views.stripe_webhook, 
         name='stripe-webhook'),
    path('payment/confirm/', views.confirm_subscription, 
         name='confirm-subscription'),
    
    # Subscription modifications
    path('subscription/upgrade/', views.SubscriptionUpgrade.as_view(),
         name='upgrade-subscription'),
    path('subscription/cancel/', views.SubscriptionCancel.as_view(),
         name='cancel-subscription'),
    
    # Payment method management
    path('payment/methods/', views.PaymentMethodList.as_view(),
         name='payment-methods'),
    path('payment/methods/<str:pm_id>/', views.PaymentMethodDetail.as_view(),
         name='payment-method-detail'),
]

urlpatterns += router.urls