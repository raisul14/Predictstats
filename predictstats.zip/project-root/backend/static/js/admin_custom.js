// Admin Panel Interactive Features
document.addEventListener('DOMContentLoaded', function() {
    // Theme Toggle Backup
    const themeStorageKey = 'predictstats_admin_theme';
    const themeToggle = document.getElementById('theme-toggle');
    
    if(themeToggle) {
        themeToggle.addEventListener('click', () => {
            document.body.classList.toggle('light-mode');
            localStorage.setItem(themeStorageKey, 
                document.body.classList.contains('light-mode') ? 'light' : 'dark');
        });
    }

    // Real-Time Updates
    function refreshPredictions() {
        fetch('/admin/predictions/refresh/')
            .then(response => response.json())
            .then(data => {
                document.getElementById('predictions-container').innerHTML = data.html;
                initializeConfidenceMeters();
            })
            .catch(error => console.error('Refresh error:', error));
    }

    // Confidence Meter Animation
    function initializeConfidenceMeters() {
        document.querySelectorAll('.confidence-meter').forEach(meter => {
            const fill = meter.querySelector('.confidence-fill');
            const width = meter.dataset.confidence + '%';
            fill.style.width = width;
        });
    }

    // Security Enhancements
    let inactivityTimer;
    function resetInactivityTimer() {
        clearTimeout(inactivityTimer);
        inactivityTimer = setTimeout(() => {
            window.location.href = '/admin/logout/';
        }, 1800000); // 30 minutes
    }

    document.addEventListener('mousemove', resetInactivityTimer);
    document.addEventListener('keypress', resetInactivityTimer);
    resetInactivityTimer();

    // Dynamic Filtering
    document.querySelectorAll('.search-input').forEach(input => {
        input.addEventListener('input', function(e) {
            const searchTerm = e.target.value.toLowerCase();
            document.querySelectorAll('#result_list tr').forEach(row => {
                row.style.display = row.textContent.toLowerCase().includes(searchTerm) 
                    ? '' 
                    : 'none';
            });
        });
    });

    // UI Enhancements
    document.querySelectorAll('.prediction-card').forEach(card => {
        card.addEventListener('click', function() {
            this.querySelector('.prediction-details').classList.toggle('expanded');
        });
    });

    // Initialize on load
    initializeConfidenceMeters();
    
    // Notification System
    const notificationClose = document.querySelector('.notification-close');
    if(notificationClose) {
        notificationClose.addEventListener('click', function() {
            this.parentElement.style.display = 'none';
        });
    }

    // Password Strength Checker
    const passwordFields = document.querySelectorAll('input[type="password"]');
    passwordFields.forEach(field => {
        field.addEventListener('input', function() {
            const strengthIndicator = this.nextElementSibling;
            if(strengthIndicator && strengthIndicator.classList.contains('password-strength')) {
                const strength = calculatePasswordStrength(this.value);
                strengthIndicator.style.width = strength + '%';
                strengthIndicator.style.backgroundColor = 
                    strength < 40 ? '#e74c3c' : strength < 80 ? '#f1c40f' : '#2ecc71';
            }
        });
    });

    function calculatePasswordStrength(password) {
        let strength = 0;
        if(password.length >= 8) strength += 25;
        if(/[A-Z]/.test(password)) strength += 25;
        if(/[0-9]/.test(password)) strength += 25;
        if(/[^A-Za-z0-9]/.test(password)) strength += 25;
        return Math.min(strength, 100);
    }

    // Bulk Action Confirmation
    document.querySelectorAll('.bulk-action-form').forEach(form => {
        form.addEventListener('submit', function(e) {
            if(!confirm(`Confirm ${this.dataset.action} on ${this.elements.selected.length} items?`)) {
                e.preventDefault();
            }
        });
    });
});