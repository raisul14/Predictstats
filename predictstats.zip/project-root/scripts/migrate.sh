#!/bin/bash
set -e

# Database Migration Script
# Applies Django migrations and handles schema changes

# Configuration
APP_NAME="predictstats"
LOG_FILE="migrations.log"

check_django() {
  echo "➤ Verifying Django setup"
  if ! python manage.py shell -c 'exit()' &>/dev/null; then
    echo "❌ Django not configured properly"
    exit 1
  fi
}

create_migrations() {
  echo "➤ Generating database migrations"
  python manage.py makemigrations \
    --no-input \
    --verbosity 0 || {
    echo "❌ Migration generation failed"
    exit 1
  }
}

apply_migrations() {
  echo "➤ Applying database migrations"
  python manage.py migrate \
    --no-input \
    --database default || {
    echo "❌ Migration application failed"
    exit 1
  }
}

main() {
  echo "🔄 Starting Database Migration Process"
  check_django
  {
    create_migrations
    apply_migrations
  } >> "$LOG_FILE" 2>&1
  
  echo "✅ Database migrations completed successfully"
  echo "📝 Migration details logged to: $LOG_FILE"
}

main