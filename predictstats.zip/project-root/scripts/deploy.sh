#!/bin/bash
set -e

# Deployment Script for PredictStats
# Environment: Production
# Region: Frankfurt (EU Central)
# Database: PostgreSQL
# Maintainer: DevOps Team

# Initialize deployment parameters
APP_NAME="predictstats"
ENV_FILE=".env.production"
DOCKER_COMPOSE_FILE="devops/docker-compose.yml"
BACKUP_DIR="backups/$(date +%Y%m%d_%H%M%S)"
DEPLOY_LOG="deploy.log"

# Verify critical dependencies
check_dependencies() {
  command -v docker >/dev/null 2>&1 || { 
    echo >&2 "Docker is required but not installed. Aborting."
    exit 1
  }
  
  command -v docker-compose >/dev/null 2>&1 || {
    echo >&2 "Docker Compose is required but not installed. Aborting."
    exit 1
  }
}

# Perform pre-deployment checks
preflight_check() {
  echo "➤ Performing pre-deployment checks"
  if [ ! -f "$ENV_FILE" ]; then
    echo "❌ Error: Environment file $ENV_FILE missing"
    exit 1
  fi
  echo "✓ Environment file verified"
}

# Build and start containers
build_infrastructure() {
  echo "➤ Building Docker infrastructure"
  docker-compose -f $DOCKER_COMPOSE_FILE build --no-cache >> $DEPLOY_LOG 2>&1
  
  echo "➤ Starting services"
  docker-compose -f $DOCKER_COMPOSE_FILE up -d --force-recreate >> $DEPLOY_LOG 2>&1
}

# Database migration handler
run_migrations() {
  echo "➤ Executing database migrations"
  docker-compose -f $DOCKER_COMPOSE_FILE exec backend \
    python manage.py migrate --no-input >> $DEPLOY_LOG 2>&1
}

# Static files collection
collect_static() {
  echo "➤ Collecting static files"
  docker-compose -f $DOCKER_COMPOSE_FILE exec backend \
    python manage.py collectstatic --no-input --clear >> $DEPLOY_LOG 2>&1
}

# Security configuration
configure_security() {
  echo "➤ Rotating secret key"
  NEW_SECRET_KEY=$(openssl rand -base64 64 | tr -d '\n')
  sed -i "s/SECRET_KEY=.*/SECRET_KEY='$NEW_SECRET_KEY'/" backend/config/settings.py
}

# Configure reverse proxy
configure_nginx() {
  echo "➤ Applying Nginx configuration"
  docker cp devops/nginx/predictstats.conf \
    $(docker-compose ps -q nginx):/etc/nginx/conf.d/default.conf
  docker-compose restart nginx >> $DEPLOY_LOG 2>&1
}

# Database backup procedure
backup_database() {
  echo "➤ Creating database backup"
  mkdir -p $BACKUP_DIR
  docker-compose -f $DOCKER_COMPOSE_FILE exec postgres \
    pg_dump -U predictstats_admin predictstats > "$BACKUP_DIR/dump.sql"
}

# Main deployment workflow
main() {
  echo "🚀 Starting PredictStats Deployment"
  check_dependencies
  preflight_check
  backup_database
  build_infrastructure
  configure_security
  configure_nginx
  run_migrations
  collect_static
  sleep 10  # Allow services to stabilize
  
  echo "✅ Deployment Completed Successfully"
  echo "🌐 Access URL: https://predictstats.com"
  echo "📊 System Status:"
  docker-compose -f $DOCKER_COMPOSE_FILE ps
}

# Execute main function and handle errors
main || {
  echo "❌ Critical deployment error detected"
  echo "⚠️ Check deployment logs: $DEPLOY_LOG"
  echo "🔄 Attempting rollback..."
  docker-compose -f $DOCKER_COMPOSE_FILE down >> $DEPLOY_LOG 2>&1
  exit 1
}