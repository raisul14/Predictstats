#!/bin/bash
set -e

# Database Initialization Script
# Creates database structure and loads initial data
# Requires PostgreSQL client tools

# Configuration
DB_NAME="predictstats"
DB_USER="predictstats_admin"
DB_PASS="lPMt6k3FmN0hEOEo9ZvG2yuzkxnhjpNO"
DB_HOST="localhost"
DB_PORT="5432"

# Wait for PostgreSQL to become available
echo "Checking PostgreSQL availability..."
until pg_isready -h $DB_HOST -p $DB_PORT -U postgres; do
  >&2 echo "PostgreSQL is unavailable - sleeping"
  sleep 5
done

# Create database and user
echo "Creating database and user..."
psql -h $DB_HOST -p $DB_PORT -U postgres -v ON_ERROR_STOP=1 <<-EOSQL
  CREATE USER IF NOT EXISTS $DB_USER WITH PASSWORD '$DB_PASS';
  CREATE DATABASE $DB_NAME WITH OWNER $DB_USER;
  GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;
EOSQL

# Run migrations and setup
echo "Running database migrations..."
python manage.py migrate --no-input

# Create superuser (set credentials via environment variables)
echo "Creating admin user..."
export DJANGO_SUPERUSER_USERNAME=${ADMIN_USER:-admin}
export DJANGO_SUPERUSER_EMAIL=${ADMIN_EMAIL:-admin@predictstats.com}
export DJANGO_SUPERUSER_PASSWORD=${ADMIN_PASS:-AdminPass123!}
python manage.py createsuperuser --no-input

# Load initial data
echo "Loading initial data..."
python manage.py loaddata initial_sports.json || echo "Warning: Sports data load failed"
python manage.py loaddata initial_teams.json || echo "Warning: Team data load failed"

# Collect static files
echo "Collecting static files..."
python manage.py collectstatic --no-input --clear

echo "✅ Database initialization completed successfully"