#!/bin/bash
set -e

# Sample Data Loader for PredictStats
# Populates database with demonstration data
# Requires Django management commands and existing database

# Configuration
FIXTURES_DIR="fixtures/sample_data"
LOG_FILE="data_load.log"

# Check Django availability
check_django() {
  echo "➤ Verifying Django setup"
  if ! python manage.py shell -c 'exit()' &>/dev/null; then
    echo "❌ Django not configured properly"
    exit 1
  fi
}

# Load football data
load_football_data() {
  echo "⚽ Loading Football Data"
  FIXTURES=(
    "football_teams.json"
    "football_players.json"
    "football_matches.json"
    "football_predictions.json"
  )
  
  for fixture in "${FIXTURES[@]}"; do
    if [ -f "$FIXTURES_DIR/$fixture" ]; then
      echo "• Loading $fixture..."
      python manage.py loaddata "$FIXTURES_DIR/$fixture" || echo "⚠️ Failed to load $fixture"
    else
      echo "❌ Missing fixture: $fixture"
      exit 1
    fi
  done
}

# Load cricket data
load_cricket_data() {
  echo "🏏 Loading Cricket Data"
  FIXTURES=(
    "cricket_teams.json"
    "cricket_players.json"
    "cricket_matches.json"
    "cricket_predictions.json"
  )
  
  for fixture in "${FIXTURES[@]}"; do
    if [ -f "$FIXTURES_DIR/$fixture" ]; then
      echo "• Loading $fixture..."
      python manage.py loaddata "$FIXTURES_DIR/$fixture" || echo "⚠️ Failed to load $fixture"
    else
      echo "❌ Missing fixture: $fixture"
      exit 1
    fi
  done
}

# Generate test predictions
generate_predictions() {
  echo "📊 Generating Test Predictions"
  python manage.py generate_test_predictions \
    --users 50 \
    --matches 100 \
    --sports both >> "$LOG_FILE"
}

# Main execution flow
main() {
  check_django
  {
    load_football_data
    load_cricket_data
    generate_predictions
  } >> "$LOG_FILE" 2>&1
  
  echo "✅ Sample data loaded successfully"
  echo "📝 Details logged to: $LOG_FILE"
}

# Execute main function
main