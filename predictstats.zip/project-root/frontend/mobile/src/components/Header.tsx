import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';

interface HeaderProps {
  onSportChange: (sport: 'football' | 'cricket') => void;
  onSettingsPress: () => void;
}

const Header: React.FC<HeaderProps> = ({ onSportChange, onSettingsPress }) => {
  const [selectedSport, setSelectedSport] = useState<'football' | 'cricket'>('football');

  const handleSportChange = (sport: 'football' | 'cricket') => {
    setSelectedSport(sport);
    onSportChange(sport);
  };

  return (
    <View style={styles.container}>
      {/* Left Section - Logo */}
      <Text style={styles.logoText}>PredictStats</Text>

      {/* Center Section - Sport Selector */}
      <View style={styles.sportSelector}>
        <TouchableOpacity 
          style={[
            styles.sportButton, 
            selectedSport === 'football' && styles.activeSport
          ]}
          onPress={() => handleSportChange('football')}
        >
          <MaterialCommunityIcons 
            name="soccer" 
            size={24} 
            color={selectedSport === 'football' ? '#FFF' : '#666'} 
          />
          <Text style={[
            styles.sportText,
            selectedSport === 'football' && styles.activeSportText
          ]}>
            Football
          </Text>
        </TouchableOpacity>

        <TouchableOpacity 
          style={[
            styles.sportButton, 
            selectedSport === 'cricket' && styles.activeSport
          ]}
          onPress={() => handleSportChange('cricket')}
        >
          <MaterialCommunityIcons 
            name="cricket" 
            size={24} 
            color={selectedSport === 'cricket' ? '#FFF' : '#666'} 
          />
          <Text style={[
            styles.sportText,
            selectedSport === 'cricket' && styles.activeSportText
          ]}>
            Cricket
          </Text>
        </TouchableOpacity>
      </View>

      {/* Right Section - Settings */}
      <TouchableOpacity onPress={onSettingsPress}>
        <MaterialCommunityIcons 
          name="cog" 
          size={24} 
          color="#666" 
        />
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#0a0a0a',
    borderBottomWidth: 1,
    borderBottomColor: '#1a1a1a',
  },
  logoText: {
    color: '#1a73e8',
    fontSize: 20,
    fontWeight: 'bold',
  },
  sportSelector: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 20,
  },
  sportButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 20,
  },
  activeSport: {
    backgroundColor: '#1a73e8',
  },
  sportText: {
    color: '#666',
    fontSize: 14,
    fontWeight: '500',
  },
  activeSportText: {
    color: '#FFF',
  },
});

export default Header;