import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';

interface OverSummaryProps {
  over: {
    number: number;
    runs: number;
    wickets: number;
    bowler: string;
    batsmen: string[];
    events: string[];
  };
  match: {
    teams: string[];
    currentScore: string;
    requiredRunRate?: number;
  };
  isLatest?: boolean;
}

const OverSummary: React.FC<OverSummaryProps> = ({ over, match, isLatest = false }) => {
  const renderEventIcon = (event: string) => {
    switch(event) {
      case '4':
        return <MaterialCommunityIcons name="cricket" size={14} color="#1a73e8" />;
      case '6':
        return <MaterialCommunityIcons name="cricket" size={14} color="#1a73e8" />;
      case 'W':
        return <MaterialCommunityIcons name="fire" size={14} color="#FF3B30" />;
      case '0':
        return <MaterialCommunityIcons name="circle" size={10} color="#666" />;
      default:
        return <Text style={styles.eventText}>{event}</Text>;
    }
  };

  return (
    <View style={[styles.container, isLatest && styles.latestOver]}>
      {/* Over Header */}
      <View style={styles.header}>
        <Text style={styles.overNumber}>Over {over.number}</Text>
        <View style={styles.statsRow}>
          <Text style={styles.runsWickets}>
            {over.runs}r {over.wickets}w
          </Text>
          <Text style={styles.bowlerText}>Bowler: {over.bowler}</Text>
        </View>
      </View>

      {/* Ball-by-Ball Events */}
      <View style={styles.eventsContainer}>
        {over.events.map((event, index) => (
          <View key={index} style={styles.eventItem}>
            {renderEventIcon(event)}
          </View>
        ))}
      </View>

      {/* Batsmen and Match Info */}
      <View style={styles.footer}>
        <Text style={styles.batsmenText}>
          Batting: {over.batsmen.join(' & ')}
        </Text>
        <View style={styles.scoreInfo}>
          <Text style={styles.scoreText}>{match.currentScore}</Text>
          {match.requiredRunRate && (
            <Text style={styles.rrText}>RRR: {match.requiredRunRate}</Text>
          )}
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#1a1a1a',
    borderRadius: 8,
    padding: 12,
    marginVertical: 4,
    marginHorizontal: 16,
    borderWidth: 1,
    borderColor: '#333',
  },
  latestOver: {
    borderColor: '#1a73e8',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  overNumber: {
    color: '#888',
    fontSize: 14,
    fontWeight: '500',
  },
  statsRow: {
    alignItems: 'flex-end',
  },
  runsWickets: {
    color: 'white',
    fontSize: 14,
    fontWeight: 'bold',
  },
  bowlerText: {
    color: '#666',
    fontSize: 10,
  },
  eventsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginVertical: 8,
  },
  eventItem: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#333',
    justifyContent: 'center',
    alignItems: 'center',
  },
  eventText: {
    color: 'white',
    fontSize: 12,
    fontWeight: 'bold',
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 8,
    borderTopWidth: 1,
    borderTopColor: '#333',
    paddingTop: 8,
  },
  batsmenText: {
    color: '#888',
    fontSize: 10,
    flex: 1,
  },
  scoreInfo: {
    alignItems: 'flex-end',
  },
  scoreText: {
    color: 'white',
    fontSize: 12,
    fontWeight: 'bold',
  },
  rrText: {
    color: '#1a73e8',
    fontSize: 10,
  },
});

export default OverSummary;