import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';

interface FootballCardProps {
  match: {
    homeTeam: string;
    awayTeam: string;
    time: string;
    venue: string;
    competition: string;
  };
  prediction: {
    confidence: number;
    predictedOutcome: '1' | 'X' | '2' | 'BTTS' | 'Over';
    keyFactors: string[];
    oddsValue?: string;
  };
  isLive?: boolean;
  onPress?: () => void;
}

const FootballCard: React.FC<FootballCardProps> = ({ 
  match, 
  prediction, 
  isLive = false,
  onPress 
}) => {
  const outcomeLabels = {
    '1': `${match.homeTeam} Win`,
    '2': `${match.awayTeam} Win`,
    'X': 'Draw',
    'BTTS': 'Both Teams Score',
    'Over': 'Over 2.5 Goals'
  };

  return (
    <TouchableOpacity 
      style={[styles.card, isLive && styles.liveBorder]}
      onPress={onPress}
      activeOpacity={0.8}
    >
      {/* Match Header */}
      <View style={styles.header}>
        <View style={styles.teamsContainer}>
          <Text style={styles.teamText}>{match.homeTeam}</Text>
          <Text style={styles.vsText}>vs</Text>
          <Text style={styles.teamText}>{match.awayTeam}</Text>
        </View>
        
        <View style={styles.matchInfo}>
          {isLive && (
            <View style={styles.liveIndicator}>
              <MaterialCommunityIcons name="circle" size={8} color="#FF3B30" />
              <Text style={styles.liveText}>LIVE</Text>
            </View>
          )}
          <Text style={styles.competitionText}>{match.competition}</Text>
          <Text style={styles.timeVenue}>
            {match.time} • {match.venue}
          </Text>
        </View>
      </View>

      {/* Prediction Body */}
      <View style={styles.predictionBody}>
        <View style={styles.confidenceRow}>
          <View style={styles.confidenceMeter}>
            <View 
              style={[
                styles.confidenceFill,
                { width: `${prediction.confidence}%` }
              ]}
            />
            <Text style={styles.confidenceText}>
              {prediction.confidence}% Confidence
            </Text>
          </View>
          
          <View style={styles.oddsBadge}>
            <Text style={styles.oddsText}>
              {prediction.oddsValue || 'N/A'}
            </Text>
          </View>
        </View>

        <View style={styles.predictionMain}>
          <MaterialCommunityIcons 
            name="soccer" 
            size={24} 
            color="#1a73e8" 
          />
          <Text style={styles.outcomeText}>
            {outcomeLabels[prediction.predictedOutcome]}
          </Text>
        </View>

        {/* Key Factors */}
        <View style={styles.factorsContainer}>
          {prediction.keyFactors.map((factor, index) => (
            <View key={index} style={styles.factorItem}>
              <MaterialCommunityIcons 
                name="alert-octagon" 
                size={14} 
                color="#666" 
              />
              <Text style={styles.factorText}>{factor}</Text>
            </View>
          ))}
        </View>
      </View>

      {/* Footer */}
      <View style={styles.footer}>
        <Text style={styles.disclaimer}>
          AI Prediction • Updated 5 mins ago • xG Model v2.1
        </Text>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 16,
    marginVertical: 8,
    marginHorizontal: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  liveBorder: {
    borderWidth: 1,
    borderColor: '#1a73e8',
  },
  header: {
    borderBottomWidth: 1,
    borderBottomColor: '#333',
    paddingBottom: 12,
    marginBottom: 12,
  },
  teamsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 8,
  },
  teamText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
    flexShrink: 1,
  },
  vsText: {
    color: '#888',
    fontSize: 12,
    fontWeight: 'bold',
  },
  matchInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flexWrap: 'wrap',
  },
  liveIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  liveText: {
    color: '#FF3B30',
    fontSize: 12,
    fontWeight: '500',
  },
  competitionText: {
    color: '#1a73e8',
    fontSize: 12,
    fontWeight: '500',
  },
  timeVenue: {
    color: '#888',
    fontSize: 12,
  },
  predictionBody: {
    marginBottom: 12,
  },
  confidenceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 12,
    marginBottom: 16,
  },
  confidenceMeter: {
    flex: 1,
    height: 24,
    backgroundColor: '#333',
    borderRadius: 12,
    overflow: 'hidden',
  },
  confidenceFill: {
    height: '100%',
    backgroundColor: '#1a73e8',
    borderRadius: 12,
  },
  confidenceText: {
    position: 'absolute',
    right: 8,
    top: 4,
    color: 'white',
    fontSize: 12,
    fontWeight: '500',
  },
  oddsBadge: {
    backgroundColor: '#1a73e8',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 4,
    justifyContent: 'center',
  },
  oddsText: {
    color: 'white',
    fontSize: 14,
    fontWeight: 'bold',
  },
  predictionMain: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 16,
  },
  outcomeText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
    flexShrink: 1,
  },
  factorsContainer: {
    gap: 8,
  },
  factorItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  factorText: {
    color: '#888',
    fontSize: 12,
    flexShrink: 1,
  },
  footer: {
    borderTopWidth: 1,
    borderTopColor: '#333',
    paddingTop: 12,
  },
  disclaimer: {
    color: '#666',
    fontSize: 10,
    textAlign: 'center',
  },
});

export default FootballCard;