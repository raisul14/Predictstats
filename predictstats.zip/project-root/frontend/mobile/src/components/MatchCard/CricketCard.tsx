import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';

interface CricketCardProps {
  match: {
    teams: string[];
    time: string;
    venue: string;
    format: 'T20' | 'ODI' | 'Test';
  };
  prediction: {
    confidence: number;
    predictedWinner: string;
    keyFactors: string[];
    recommendedBet?: string;
  };
  isLive?: boolean;
  onPress?: () => void;
}

const CricketCard: React.FC<CricketCardProps> = ({ 
  match, 
  prediction, 
  isLive = false,
  onPress 
}) => {
  return (
    <TouchableOpacity 
      style={[styles.card, isLive && styles.liveBorder]}
      onPress={onPress}
      activeOpacity={0.8}
    >
      {/* Match Header */}
      <View style={styles.header}>
        <Text style={styles.teamsText}>
          {match.teams[0]} vs {match.teams[1]}
        </Text>
        <View style={styles.matchInfo}>
          {isLive && (
            <View style={styles.liveIndicator}>
              <MaterialCommunityIcons name="circle" size={8} color="#FF3B30" />
              <Text style={styles.liveText}>LIVE</Text>
            </View>
          )}
          <Text style={styles.timeVenue}>
            {match.time} • {match.venue}
          </Text>
          <View style={styles.formatBadge}>
            <Text style={styles.formatText}>{match.format}</Text>
          </View>
        </View>
      </View>

      {/* Prediction Body */}
      <View style={styles.predictionBody}>
        <View style={styles.confidenceMeter}>
          <View 
            style={[
              styles.confidenceFill,
              { width: `${prediction.confidence}%` }
            ]}
          />
          <Text style={styles.confidenceText}>
            {prediction.confidence}% Confidence
          </Text>
        </View>

        <View style={styles.predictionDetails}>
          <MaterialCommunityIcons 
            name="trophy" 
            size={20} 
            color="#1a73e8" 
          />
          <Text style={styles.winnerText}>
            {prediction.predictedWinner} to Win
          </Text>
        </View>

        {/* Key Factors */}
        <View style={styles.factorsContainer}>
          {prediction.keyFactors.map((factor, index) => (
            <View key={index} style={styles.factorItem}>
              <MaterialCommunityIcons 
                name="cricket" 
                size={14} 
                color="#666" 
              />
              <Text style={styles.factorText}>{factor}</Text>
            </View>
          ))}
        </View>

        {prediction.recommendedBet && (
          <View style={styles.betRecommendation}>
            <Text style={styles.betText}>
              🔥 Value Tip: {prediction.recommendedBet}
            </Text>
          </View>
        )}
      </View>

      {/* Footer */}
      <View style={styles.footer}>
        <Text style={styles.disclaimer}>
          AI Prediction • Updated 5 mins ago
        </Text>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 16,
    marginVertical: 8,
    marginHorizontal: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  liveBorder: {
    borderWidth: 1,
    borderColor: '#1a73e8',
  },
  header: {
    borderBottomWidth: 1,
    borderBottomColor: '#333',
    paddingBottom: 12,
    marginBottom: 12,
  },
  teamsText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  matchInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  liveIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  liveText: {
    color: '#FF3B30',
    fontSize: 12,
    fontWeight: '500',
  },
  timeVenue: {
    color: '#888',
    fontSize: 12,
  },
  formatBadge: {
    backgroundColor: '#333',
    borderRadius: 4,
    paddingHorizontal: 6,
    paddingVertical: 2,
  },
  formatText: {
    color: '#888',
    fontSize: 10,
    fontWeight: 'bold',
  },
  predictionBody: {
    marginBottom: 12,
  },
  confidenceMeter: {
    height: 24,
    backgroundColor: '#333',
    borderRadius: 12,
    marginBottom: 12,
    overflow: 'hidden',
  },
  confidenceFill: {
    height: '100%',
    backgroundColor: '#1a73e8',
    borderRadius: 12,
  },
  confidenceText: {
    position: 'absolute',
    right: 8,
    top: 4,
    color: 'white',
    fontSize: 12,
    fontWeight: '500',
  },
  predictionDetails: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  winnerText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
  factorsContainer: {
    gap: 8,
    marginBottom: 12,
  },
  factorItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  factorText: {
    color: '#888',
    fontSize: 12,
  },
  betRecommendation: {
    backgroundColor: '#1a73e822',
    padding: 8,
    borderRadius: 8,
    marginTop: 8,
  },
  betText: {
    color: '#1a73e8',
    fontSize: 12,
    fontWeight: '500',
  },
  footer: {
    borderTopWidth: 1,
    borderTopColor: '#333',
    paddingTop: 12,
  },
  disclaimer: {
    color: '#666',
    fontSize: 10,
    textAlign: 'center',
  },
});

export default CricketCard;