import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { NavigationContainer } from '@react-navigation/native';
import React from 'react';
import HomeScreen from '../screens/HomeScreen';
import MatchDetailScreen from '../screens/MatchDetailScreen';
import SettingsScreen from '../screens/SettingsScreen';
import SubscriptionScreen from '../screens/SubscriptionScreen';
import LoginScreen from '../screens/LoginScreen';
import type { FootballMatch, CricketMatch } from '../types';

export type RootStackParamList = {
  Home: { sport: 'football' | 'cricket' };
  MatchDetail: { match: FootballMatch | CricketMatch; sportType: 'football' | 'cricket' };
  Settings: undefined;
  Subscription: undefined;
  Login: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();

const AppNavigator = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName="Home"
        screenOptions={{
          headerShown: false,
          animation: 'slide_from_right',
          contentStyle: { backgroundColor: '#0a0a0a' }
        }}
      >
        <Stack.Screen
          name="Home"
          component={HomeScreen}
          initialParams={{ sport: 'football' }}
        />
        <Stack.Screen
          name="MatchDetail"
          component={MatchDetailScreen}
          options={{
            animation: 'fade',
            presentation: 'modal'
          }}
        />
        <Stack.Group
          screenOptions={{
            presentation: 'containedTransparentModal',
            animation: 'fade'
          }}
        >
          <Stack.Screen name="Settings" component={SettingsScreen} />
          <Stack.Screen name="Subscription" component={SubscriptionScreen} />
          <Stack.Screen name="Login" component={LoginScreen} />
        </Stack.Group>
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default AppNavigator;