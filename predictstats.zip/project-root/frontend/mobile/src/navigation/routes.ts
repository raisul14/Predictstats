export const ROUTES = {
  HOME: 'Home',
  MATCH_DETAIL: 'MatchDetail',
  SETTINGS: 'Settings',
  SUBSCRIPTION: 'Subscription',
  LOGIN: 'Login',
} as const;

export type SportType = 'football' | 'cricket';

export type RootStackParamList = {
  [ROUTES.HOME]: { sport: SportType };
  [ROUTES.MATCH_DETAIL]: {
    match: FootballMatch | CricketMatch;
    sportType: SportType;
  };
  [ROUTES.SETTINGS]: undefined;
  [ROUTES.SUBSCRIPTION]: undefined;
  [ROUTES.LOGIN]: undefined;
};

export type FootballMatch = {
  id: string;
  homeTeam: string;
  awayTeam: string;
  time: string;
  venue: string;
  competition: string;
};

export type CricketMatch = {
  id: string;
  teams: [string, string];
  time: string;
  venue: string;
  format: 'T20' | 'ODI' | 'Test';
};

// Navigation route helper types
export type HomeRouteParams = RootStackParamList[typeof ROUTES.HOME];
export type MatchDetailRouteParams = RootStackParamList[typeof ROUTES.MATCH_DETAIL];