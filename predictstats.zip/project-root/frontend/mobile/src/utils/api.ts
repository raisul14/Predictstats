import axios from 'axios';
import { FootballMatch, CricketMatch } from '../navigation/routes';

const API_BASE_URL = 'https://api.predictstats.app/v1';

const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
    'X-Platform': 'mobile'
  }
});

// Request interceptor for auth token
api.interceptors.request.use(config => {
  const token = localStorage.getItem('authToken');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Response interceptor for error handling
api.interceptors.response.use(
  response => response,
  error => {
    if (error.response?.status === 401) {
      // Handle token expiration
    }
    return Promise.reject({
      code: error.response?.status || 500,
      message: error.response?.data?.message || 'Network Error'
    });
  }
);

const API = {
  auth: {
    login: (email: string, password: string) => 
      api.post('/auth/login', { email, password }),
    register: (userData: { email: string; password: string }) => 
      api.post('/auth/register', userData),
    refresh: () => 
      api.post('/auth/refresh')
  },

  matches: {
    getFootballMatches: (params?: { 
      league?: string; 
      date?: string 
    }) => api.get<FootballMatch[]>('/matches/football', { params }),
    
    getCricketMatches: (params?: { 
      format?: 'T20' | 'ODI' | 'Test'; 
      date?: string 
    }) => api.get<CricketMatch[]>('/matches/cricket', { params }),
    
    getLiveMatches: () => 
      api.get<(FootballMatch | CricketMatch)[]>('/matches/live')
  },

  predictions: {
    getFootballPrediction: (matchId: string) => 
      api.get(`/predictions/football/${matchId}`),
    
    getCricketPrediction: (matchId: string) => 
      api.get(`/predictions/cricket/${matchId}`),
    
    getLiveUpdates: (matchId: string) => 
      api.get(`/predictions/${matchId}/live`)
  },

  user: {
    getProfile: () => api.get('/users/me'),
    updateProfile: (data: { 
      preferences?: { 
        favoriteTeams?: string[]; 
        notificationSettings?: object 
      } 
    }) => api.patch('/users/me', data)
  },

  subscription: {
    getPlans: () => api.get('/subscriptions/plans'),
    subscribe: (planId: string) => 
      api.post('/subscriptions', { planId }),
    cancel: () => api.delete('/subscriptions')
  }
};

export type APIError = {
  code: number;
  message: string;
  details?: Record<string, string>;
};

export const parseError = (error: unknown): APIError => {
  if (axios.isAxiosError(error)) {
    return {
      code: error.response?.status || 500,
      message: error.response?.data?.message || 'API Request Failed',
      details: error.response?.data?.errors
    };
  }
  return { code: 500, message: 'Unknown error occurred' };
};

export default API;