import React from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';
import { useRoute } from '@react-navigation/native';
import { RouteProp } from '@react-navigation/core';
import { ROUTES, SportType, FootballMatch, CricketMatch } from '../navigation/routes';
import LiveMatchBadge from '../components/LiveMatchBadge';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { colors } from '../utils/constants';
import StatCard from '../components/StatCard';

const MatchDetailScreen = () => {
  const route = useRoute<RouteProp<{ params: { match: FootballMatch | CricketMatch; sportType: SportType } }>>();
  const { match, sportType } = route.params;

  const renderFootballContent = () => (
    <>
      <View style={styles.scoreContainer}>
        <Text style={styles.scoreText}>2 - 1</Text>
        <Text style={styles.timeText}>63'</Text>
      </View>
      
      <View style={styles.statsGrid}>
        <StatCard icon="soccer-field" title="Possession" value="58% - 42%" />
        <StatCard icon="target" title="Shots on Target" value="5 - 3" />
        <StatCard icon="cards" title="Cards" value="2 - 4" />
        <StatCard icon="whistle" title="Fouls" value="12 - 15" />
      </View>

      <Text style={styles.sectionTitle}>Prediction Analysis</Text>
      <View style={styles.predictionCard}>
        <Text style={styles.predictionText}>Home Win Probability: 68%</Text>
        <Text style={styles.factorText}>• xG Difference: +1.2</Text>
        <Text style={styles.factorText}>• Home Advantage</Text>
        <Text style={styles.factorText}>• Recent Form</Text>
      </View>
    </>
  );

  const renderCricketContent = () => (
    <>
      <View style={styles.scoreContainer}>
        <Text style={styles.scoreText}>IND 287/6 (45)</Text>
        <Text style={styles.timeText}>CRR: 6.38</Text>
      </View>

      <View style={styles.statsGrid}>
        <StatCard icon="cricket" title="Partnership" value="72 (54)" />
        <StatCard icon="run-fast" title="Last 5 Overs" value="45 runs" />
        <StatCard icon="weather-windy" title="Conditions" value="Dew Factor" />
        <StatCard icon="chart-line" title="Required RR" value="9.2" />
      </View>

      <Text style={styles.sectionTitle}>Batting Progress</Text>
      <View style={styles.predictionCard}>
        <Text style={styles.predictionText}>Predicted Score: 325-340</Text>
        <Text style={styles.factorText}>• Wickets in Hand: 4</Text>
        <Text style={styles.factorText}>• Death Over Strength</Text>
        <Text style={styles.factorText}>• Pitch Deterioration</Text>
      </View>
    </>
  );

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.teamText}>
          {sportType === 'football' 
            ? `${(match as FootballMatch).homeTeam} vs ${(match as FootballMatch).awayTeam}`
            : (match as CricketMatch).teams.join(' vs ')}
        </Text>
        <LiveMatchBadge isLive={true} />
      </View>

      <Text style={styles.matchInfo}>
        {sportType === 'football' 
          ? `⚽ ${(match as FootballMatch).competition}`
          : `🏏 ${(match as CricketMatch).format} • ${match.venue}`}
      </Text>

      {sportType === 'football' ? renderFootballContent() : renderCricketContent()}

      <Text style={styles.sectionTitle}>Key Players</Text>
      <View style={styles.playersContainer}>
        {[1, 2, 3].map((_, i) => (
          <View key={i} style={styles.playerCard}>
            <MaterialCommunityIcons 
              name={sportType === 'football' ? "account" : "cricket"} 
              size={40} 
              color={colors.primary} 
            />
            <Text style={styles.playerName}>Player {i+1}</Text>
            <Text style={styles.playerStat}>
              {sportType === 'football' ? '2 Shots' : 'SR: 148.6'}
            </Text>
          </View>
        ))}
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    padding: 16,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  teamText: {
    color: colors.textPrimary,
    fontSize: 24,
    fontWeight: 'bold',
    flex: 1,
  },
  matchInfo: {
    color: colors.textSecondary,
    fontSize: 14,
    marginBottom: 24,
  },
  scoreContainer: {
    alignItems: 'center',
    marginBottom: 24,
  },
  scoreText: {
    color: colors.textPrimary,
    fontSize: 32,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  timeText: {
    color: colors.primary,
    fontSize: 16,
    fontWeight: '500',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 24,
  },
  sectionTitle: {
    color: colors.textPrimary,
    fontSize: 18,
    fontWeight: '600',
    marginVertical: 16,
  },
  predictionCard: {
    backgroundColor: colors.surface,
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
  },
  predictionText: {
    color: colors.textPrimary,
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 12,
  },
  factorText: {
    color: colors.textSecondary,
    fontSize: 14,
    marginLeft: 8,
    marginVertical: 4,
  },
  playersContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 24,
  },
  playerCard: {
    backgroundColor: colors.surface,
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    width: '48%',
  },
  playerName: {
    color: colors.textPrimary,
    fontSize: 14,
    fontWeight: '500',
    marginVertical: 8,
  },
  playerStat: {
    color: colors.primary,
    fontSize: 12,
  },
});

export default MatchDetailScreen;