import React, { useState, useEffect } from 'react';
import { View, FlatList, ActivityIndicator, StyleSheet } from 'react-native';
import Header from '../components/Header';
import FootballCard from '../components/MatchCard/FootballCard';
import CricketCard from '../components/MatchCard/CricketCard';
import { ROUTES, SportType, FootballMatch, CricketMatch } from '../navigation/routes';
import { useRoute, RouteProp } from '@react-navigation/native';
import { colors } from '../utils/constants';

const HomeScreen = () => {
  const route = useRoute<RouteProp<{ params: { sport?: SportType } }>>();
  const [selectedSport, setSelectedSport] = useState<SportType>(route.params?.sport || 'football');
  const [matches, setMatches] = useState<(FootballMatch | CricketMatch)[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Mock data fetch - replace with actual API calls
  const fetchMatches = async (sport: SportType) => {
    try {
      setIsLoading(true);
      // Simulated API delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const mockData = sport === 'football' ? footballMatches : cricketMatches;
      setMatches(mockData);
      setError(null);
    } catch (err) {
      setError('Failed to load matches');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchMatches(selectedSport);
  }, [selectedSport]);

  const handleSportChange = (sport: SportType) => {
    setSelectedSport(sport);
  };

  const renderItem = ({ item }: { item: FootballMatch | CricketMatch }) => {
    if (selectedSport === 'football') {
      return <FootballCard match={item as FootballMatch} prediction={mockFootballPrediction} />;
    }
    return <CricketCard match={item as CricketMatch} prediction={mockCricketPrediction} />;
  };

  if (error) {
    return (
      <View style={styles.container}>
        <Text style={styles.errorText}>{error}</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Header 
        onSportChange={handleSportChange}
        onSettingsPress={() => console.log('Settings pressed')}
      />
      
      {isLoading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      ) : (
        <FlatList
          data={matches}
          renderItem={renderItem}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          refreshing={isLoading}
          onRefresh={() => fetchMatches(selectedSport)}
        />
      )}
    </View>
  );
};

// Mock data - replace with real API data
const footballMatches: FootballMatch[] = [
  {
    id: '1',
    homeTeam: 'Arsenal',
    awayTeam: 'Manchester United',
    time: '20:00 GMT',
    venue: 'Emirates Stadium',
    competition: 'Premier League'
  },
  // Add more matches...
];

const cricketMatches: CricketMatch[] = [
  {
    id: 'c1',
    teams: ['India', 'Australia'],
    time: '14:30 IST',
    venue: 'Wankhede Stadium',
    format: 'ODI'
  },
  // Add more matches...
];

const mockFootballPrediction = {
  confidence: 78,
  predictedOutcome: '1',
  keyFactors: ['Home advantage', 'xG differential', 'Recent form'],
  oddsValue: '1.85'
};

const mockCricketPrediction = {
  confidence: 65,
  predictedWinner: 'India',
  keyFactors: ['Pitch conditions', 'Head-to-head record', 'Toss impact'],
  recommendedBet: 'India to win'
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  listContent: {
    paddingVertical: 16,
    paddingHorizontal: 8,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  errorText: {
    color: colors.error,
    textAlign: 'center',
    marginTop: 20,
  },
});

export default HomeScreen;