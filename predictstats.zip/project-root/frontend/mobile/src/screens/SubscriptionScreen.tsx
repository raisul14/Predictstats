import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { colors } from '../utils/constants';

const SubscriptionScreen = () => {
  const [selectedPlan, setSelectedPlan] = useState<'basic' | 'premium'>('premium');
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'annual'>('annual');

  const features = {
    basic: [
      '3 Daily Predictions',
      'Basic Match Analysis',
      'Live Score Updates',
      '24h Support Response'
    ],
    premium: [
      'Unlimited Predictions',
      'Advanced Analytics',
      'Live Match Alerts',
      'VIP Support Priority',
      'Value Bet Finder',
      'Portfolio Tracking'
    ]
  };

  const pricing = {
    monthly: { basic: 9.99, premium: 29.99 },
    annual: { basic: 99.99, premium: 299.99 }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Upgrade Your Experience</Text>
      
      {/* Billing Toggle */}
      <View style={styles.billingContainer}>
        <TouchableOpacity
          style={[
            styles.billingButton,
            billingCycle === 'monthly' && styles.activeBilling
          ]}
          onPress={() => setBillingCycle('monthly')}
        >
          <Text style={styles.billingText}>Monthly</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.billingButton,
            billingCycle === 'annual' && styles.activeBilling
          ]}
          onPress={() => setBillingCycle('annual')}
        >
          <Text style={styles.billingText}>Annual (Save 20%)</Text>
        </TouchableOpacity>
      </View>

      {/* Plans Container */}
      <View style={styles.plansContainer}>
        {/* Basic Plan */}
        <TouchableOpacity 
          style={[
            styles.planCard,
            selectedPlan === 'basic' && styles.selectedPlan
          ]}
          onPress={() => setSelectedPlan('basic')}
        >
          <Text style={styles.planTitle}>Basic</Text>
          <Text style={styles.planPrice}>
            ${pricing[billingCycle].basic}
            <Text style={styles.billingPeriod}>/{billingCycle === 'monthly' ? 'mo' : 'yr'}</Text>
          </Text>
          <View style={styles.featuresList}>
            {features.basic.map((feature, index) => (
              <View key={index} style={styles.featureItem}>
                <MaterialCommunityIcons 
                  name="check-circle" 
                  size={16} 
                  color={colors.primary} 
                />
                <Text style={styles.featureText}>{feature}</Text>
              </View>
            ))}
          </View>
        </TouchableOpacity>

        {/* Premium Plan */}
        <TouchableOpacity 
          style={[
            styles.planCard,
            styles.premiumCard,
            selectedPlan === 'premium' && styles.selectedPlan
          ]}
          onPress={() => setSelectedPlan('premium')}
        >
          <View style={styles.recommendedBadge}>
            <Text style={styles.recommendedText}>Recommended</Text>
          </View>
          <Text style={styles.planTitle}>Premium</Text>
          <Text style={styles.planPrice}>
            ${pricing[billingCycle].premium}
            <Text style={styles.billingPeriod}>/{billingCycle === 'monthly' ? 'mo' : 'yr'}</Text>
          </Text>
          <View style={styles.featuresList}>
            {features.premium.map((feature, index) => (
              <View key={index} style={styles.featureItem}>
                <MaterialCommunityIcons 
                  name="check-circle" 
                  size={16} 
                  color={colors.primary} 
                />
                <Text style={styles.featureText}>{feature}</Text>
              </View>
            ))}
          </View>
        </TouchableOpacity>
      </View>

      {/* Payment Button */}
      <TouchableOpacity style={styles.subscribeButton}>
        <Text style={styles.subscribeText}>
          Subscribe to {selectedPlan.charAt(0).toUpperCase() + selectedPlan.slice(1)}
        </Text>
      </TouchableOpacity>

      {/* Security Info */}
      <View style={styles.securityContainer}>
        <MaterialCommunityIcons 
          name="lock-check" 
          size={24} 
          color={colors.primary} 
        />
        <Text style={styles.securityText}>
          256-bit SSL Secure Payment • Cancel Anytime
        </Text>
      </View>

      {/* Footer Links */}
      <View style={styles.footer}>
        <TouchableOpacity>
          <Text style={styles.linkText}>Terms of Service</Text>
        </TouchableOpacity>
        <Text style={styles.divider}>•</Text>
        <TouchableOpacity>
          <Text style={styles.linkText}>Privacy Policy</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: colors.background,
    padding: 24,
    paddingTop: 40,
  },
  title: {
    color: colors.textPrimary,
    fontSize: 28,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 32,
  },
  billingContainer: {
    flexDirection: 'row',
    backgroundColor: colors.surface,
    borderRadius: 12,
    marginBottom: 24,
  },
  billingButton: {
    flex: 1,
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
  },
  activeBilling: {
    backgroundColor: colors.primary,
  },
  billingText: {
    color: colors.textPrimary,
    fontWeight: '500',
  },
  plansContainer: {
    gap: 16,
    marginBottom: 24,
  },
  planCard: {
    backgroundColor: colors.surface,
    borderRadius: 16,
    padding: 24,
    borderWidth: 1,
    borderColor: 'transparent',
  },
  premiumCard: {
    position: 'relative',
    paddingTop: 40,
  },
  selectedPlan: {
    borderColor: colors.primary,
  },
  recommendedBadge: {
    position: 'absolute',
    top: -12,
    right: 16,
    backgroundColor: colors.primary,
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 20,
  },
  recommendedText: {
    color: 'white',
    fontSize: 12,
    fontWeight: 'bold',
  },
  planTitle: {
    color: colors.textPrimary,
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  planPrice: {
    color: colors.textPrimary,
    fontSize: 36,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  billingPeriod: {
    fontSize: 16,
    color: colors.textSecondary,
  },
  featuresList: {
    gap: 12,
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  featureText: {
    color: colors.textSecondary,
    fontSize: 16,
  },
  subscribeButton: {
    backgroundColor: colors.primary,
    borderRadius: 12,
    paddingVertical: 18,
    alignItems: 'center',
    marginBottom: 24,
  },
  subscribeText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  securityContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    justifyContent: 'center',
    marginBottom: 24,
  },
  securityText: {
    color: colors.textSecondary,
    fontSize: 12,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 16,
  },
  linkText: {
    color: colors.primary,
    fontSize: 12,
  },
  divider: {
    color: colors.textSecondary,
  },
});

export default SubscriptionScreen;