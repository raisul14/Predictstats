import UIKit
import Firebase
import React
import UserNotifications

@main
class AppDelegate: UIResponder, UIApplicationDelegate, UNUserNotificationCenterDelegate {
    
    var window: UIWindow?
    let sports = ["football", "cricket"]
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Initialize Firebase for crash reporting and analytics
        FirebaseApp.configure()
        
        // React Native setup
        initializeReactNative()
        
        // Sports prediction services
        configureSportsAnalytics()
        setupPushNotifications(application: application)
        configureLiveUpdates()
        
        return true
    }
    
    // MARK: - React Native Configuration
    
    private func initializeReactNative() {
        let jsLocation = RCTBundleURLProvider.sharedSettings().jsBundleURL(
            forBundleRoot: "index",
            fallbackExtension: nil
        )!
        
        let rootView = RCTRootView(
            bundleURL: jsLocation,
            moduleName: "PredictStats",
            initialProperties: nil,
            launchOptions: nil
        )
        
        window = UIWindow(frame: UIScreen.main.bounds)
        let rootViewController = UIViewController()
        rootViewController.view = rootView
        window?.rootViewController = rootViewController
        window?.makeKeyAndVisible()
    }
    
    // MARK: - Sports Prediction Features
    
    private func configureSportsAnalytics() {
        guard let apiKey = ProcessInfo.processInfo.environment["SPORTS_API_KEY"] else {
            fatalError("Missing Sports API Key")
        }
        
        SportsAnalytics.configure(
            sports: sports,
            apiKey: apiKey,
            endpoint: ProcessInfo.processInfo.environment["API_BASE_URL"] ?? "https://api.predictstats.com"
        )
    }
    
    private func setupPushNotifications(application: UIApplication) {
        UNUserNotificationCenter.current().delegate = self
        application.registerForRemoteNotifications()
        
        // Request permissions for live match alerts
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { granted, _ in
            guard granted else { return }
            DispatchQueue.main.async {
                application.registerForRemoteNotifications()
            }
        }
    }
    
    private func configureLiveUpdates() {
        LiveMatchService.shared.configure(
            sports: sports,
            refreshInterval: 30 // Seconds
        )
    }
    
    // MARK: - Deep Link Handling
    
    func application(_ app: UIApplication, open url: URL, options: [UIApplication.OpenURLOptionsKey : Any] = [:]) -> Bool {
        handleSportsDeepLink(url: url)
        return true
    }
    
    private func handleSportsDeepLink(url: URL) {
        guard let sport = sports.first(where: { url.path.contains($0) }) else { return }
        
        let event: [String: Any] = [
            "sport": sport,
            "url": url.absoluteString,
            "timestamp": Date().timeIntervalSince1970
        ]
        
        NotificationCenter.default.post(
            name: NSNotification.Name("SportsDeepLink"),
            object: nil,
            userInfo: event
        )
    }
    
    // MARK: - Remote Notifications
    
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        let token = deviceToken.map { String(format: "%02.2hhx", $0) }.joined()
        UserDefaults.standard.set(token, forKey: "pushToken")
        PushNotificationManager.registerToken(token)
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, 
                               willPresent notification: UNNotification,
                               withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        // Handle live match notifications
        completionHandler([.banner, .sound])
    }
}