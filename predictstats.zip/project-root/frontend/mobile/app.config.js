export default {
  expo: {
    extra: {
      // Environment Variables
      ENV: process.env.ENV || 'development',
      
      // API Configuration
      API_URL: process.env.API_URL || 'https://api.predictstats.app/v1',
      WS_URL: process.env.WS_URL || 'wss://ws.predictstats.app',
      ML_API_URL: process.env.ML_API_URL || 'https://ml.predictstats.app/v1',

      // Monitoring & Analytics
      SENTRY_DSN: process.env.SENTRY_DSN || 'https://1234567890abcdef1234567890abcdef@o123456.ingest.sentry.io/123456',
      MIXPANEL_TOKEN: process.env.MIXPANEL_TOKEN || 'mp_1234567890abcdef',

      // Third-party Services
      GOOGLE_MAPS_API_KEY: process.env.GOOGLE_MAPS_API_KEY || 'AIzaSyABCDEFGHIJKLMNOPQRSTUVWXYZ123456',
      FIREBASE_CONFIG: JSON.stringify({
        apiKey: process.env.FIREBASE_API_KEY || 'AIzaSy...',
        authDomain: 'predictstats.firebaseapp.com',
        projectId: 'predictstats',
        storageBucket: 'predictstats.appspot.com',
        messagingSenderId: '1234567890',
        appId: '1:1234567890:web:abcdef123456'
      }),

      // Security
      ENCRYPTION_KEY: process.env.ENCRYPTION_KEY || 'v3ry$3cr3tK3y!123',

      // Feature Flags
      FEATURE_LIVE_UPDATES: true,
      FEATURE_PREDICTION_EDITING: false,
      
      // OAuth
      GOOGLE_OAUTH_ID: process.env.GOOGLE_OAUTH_ID || '123-abc.apps.googleusercontent.com'
    },
    // ... rest of Expo config
  }
};