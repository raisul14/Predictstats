package com.predictstats

import android.os.Bundle
import com.facebook.react.ReactActivity
import com.facebook.react.ReactActivityDelegate
import com.facebook.react.defaults.DefaultNewArchitectureEntryPoint
import com.facebook.react.defaults.DefaultReactActivityDelegate

class MainActivity : ReactActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Custom initialization for sports prediction features
        initializeAnalytics()
        setupPushNotifications()
    }

    /**
     * Returns the name of the main component registered from JavaScript.
     * This is used to schedule rendering of the component.
     */
    override fun getMainComponentName(): String = "PredictStats"

    /**
     * Returns the instance of the {@link ReactActivityDelegate}.
     */
    override fun createReactActivityDelegate(): ReactActivityDelegate =
        DefaultReactActivityDelegate(
            this,
            mainComponentName,
            // Enable Fabric Renderer
            DefaultNewArchitectureEntryPoint.fabricEnabled
        )

    // region Sports Prediction Features
    
    private fun initializeAnalytics() {
        // Initialize sports-specific analytics SDK
        SportsAnalytics.init(applicationContext)
    }

    private fun setupPushNotifications() {
        // Configure live match updates and prediction alerts
        PushNotificationManager.configure(
            context = this,
            sports = listOf("football", "cricket"),
            enableLiveUpdates = true
        )
    }

    // endregion

    // region Deep Linking
    
    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleSportsDeepLinks(intent)
    }

    private fun handleSportsDeepLinks(intent: Intent?) {
        intent?.data?.let { uri ->
            when {
                uri.toString().contains("/football/") -> 
                    sendSportEventToJS("football", uri)
                uri.toString().contains("/cricket/") -> 
                    sendSportEventToJS("cricket", uri)
            }
        }
    }

    private fun sendSportEventToJS(sport: String, uri: Uri) {
        reactInstanceManager?.currentReactContext?.let { context ->
            val event = Arguments.createMap().apply {
                putString("sport", sport)
                putString("uri", uri.toString())
            }
            context.getJSModule(RCTDeviceEventEmitter::class.java)
                .emit("sportsDeepLink", event)
        }
    }
    
    // endregion
}