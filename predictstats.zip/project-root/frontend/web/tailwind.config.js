module.exports = {
  content: [
    "./src/**/*.{js,ts,jsx,tsx}",
    "./src/components/**/*.{js,ts,jsx,tsx}",
    "./public/index.html"
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        primary: {
          dark: '#0a0a0a',
          DEFAULT: '#1a1a1a',
          light: '#2d2d2d'
        },
        accent: {
          blue: '#1a73e8',
          gold: '#ffd700',
          red: '#e53e3e'
        },
        sport: {
          football: '#3B82F6',
          cricket: '#10B981'
        }
      },
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui'],
        heading: ['Poppins', 'Inter', 'ui-sans-serif']
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'glow': 'glow 2s ease-in-out infinite'
      },
      keyframes: {
        glow: {
          '0%, 100%': { 'box-shadow': '0 0 0 0 rgba(26, 115, 232, 0.7)' },
          '50%': { 'box-shadow': '0 0 20px 10px rgba(26, 115, 232, 0)' }
        }
      },
      boxShadow: {
        'prediction': '0 4px 24px -2px rgba(26, 115, 232, 0.15)',
        'card': '0 8px 32px rgba(0, 0, 0, 0.25)'
      }
    },
  },
  variants: {
    extend: {
      scale: ['group-hover'],
      opacity: ['disabled'],
      backgroundColor: ['checked'],
      borderColor: ['checked']
    }
  },
  plugins: [
    require('@tailwindcss/typography'),
    require('@tailwindcss/forms'),
    require('@tailwindcss/line-clamp')
  ],
  corePlugins: {
    container: false
  }
}