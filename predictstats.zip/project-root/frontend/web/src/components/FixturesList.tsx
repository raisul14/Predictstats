import { Fixture } from '../utils/types';
import { CricketCard } from './MatchCard/CricketCard';
import { FootballCard } from './MatchCard/FootballCard';
import { PulseLoader } from 'react-spinners';

interface FixturesListProps {
  fixtures: Fixture[];
  sport: 'football' | 'cricket';
  isLoading?: boolean;
}

export const FixturesList = ({ fixtures, sport, isLoading }: FixturesListProps) => {
  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-[200px]">
        <PulseLoader color="#1a73e8" size={12} margin={4} />
      </div>
    );
  }

  if (fixtures.length === 0) {
    return (
      <div className="text-center py-8 text-gray-400">
        No {sport} matches available
      </div>
    );
  }

  return (
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-1">
      {fixtures.map((fixture) => (
        sport === 'cricket' ? (
          <CricketCard 
            key={fixture.id}
            fixture={fixture}
          />
        ) : (
          <FootballCard
            key={fixture.id}
            fixture={fixture}
          />
        )
      ))}
    </div>
  );
};