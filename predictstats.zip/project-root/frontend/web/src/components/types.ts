interface HeaderProps {
  selectedSport: 'football' | 'cricket';
  onSportChange: (sport: 'football' | 'cricket') => void;
  isAuthenticated: boolean;
  darkMode: boolean;
  toggleTheme: () => void;
}