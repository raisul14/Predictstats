import { Tooltip } from './UI/Tooltip';

interface TipSectionProps {
  confidence: number;
  isValueTip: boolean;
  marketOdds: number;
  riskFactors: string[];
  isHighVolatility?: boolean;
  isDerbyMatch?: boolean;
}

export const TipSection = ({
  confidence,
  isValueTip,
  marketOdds,
  riskFactors,
  isHighVolatility,
  isDerbyMatch
}: TipSectionProps) => {
  const confidenceColor = confidence >= 75 ? 'bg-green-500' :
                         confidence >= 50 ? 'bg-yellow-500' : 'bg-red-500';

  return (
    <div className="bg-gray-800 p-4 rounded-xl border border-gray-700">
      {/* Risk Flags */}
      {(isHighVolatility || isDerbyMatch) && (
        <div className="flex gap-2 mb-4">
          {isHighVolatility && (
            <div className="flex items-center bg-red-800/30 px-3 py-1 rounded-full text-sm text-red-400">
              ⚠️ High Volatility
            </div>
          )}
          {isDerbyMatch && (
            <div className="flex items-center bg-yellow-800/30 px-3 py-1 rounded-full text-sm text-yellow-400">
              🏟️ Derby Match
            </div>
          )}
        </div>
      )}

      {/* Confidence Meter */}
      <div className="mb-4">
        <div className="flex justify-between text-sm mb-2">
          <span>AI Confidence</span>
          <span className="font-semibold">{confidence}%</span>
        </div>
        <div className="h-2 bg-gray-700 rounded-full overflow-hidden">
          <div 
            className={`h-full ${confidenceColor} transition-all duration-500`}
            style={{ width: `${confidence}%` }}
          />
        </div>
      </div>

      {/* Value Tip & Market Comparison */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="text-sm">Value Tip</span>
            {isValueTip && (
              <Tooltip content="Strong value based on AI analysis">
                <span className="bg-gradient-to-r from-yellow-400 to-yellow-600 text-xs px-2 py-1 rounded-full">
                  💎 Recommended
                </span>
              </Tooltip>
            )}
          </div>
          <div className="text-lg font-bold">
            {isValueTip ? 'Strong Value' : 'Neutral'}
          </div>
        </div>

        <div>
          <div className="text-sm mb-2">Market vs AI</div>
          <div className="flex items-center gap-2">
            <div className="flex-1 bg-gray-700 h-2 rounded-full">
              <div 
                className="h-full bg-blue-500 rounded-full"
                style={{ width: `${marketOdds}%` }}
              />
            </div>
            <span className="text-sm font-semibold">
              {Math.abs(marketOdds - confidence)}%
              <span className="text-xs ml-1">
                {marketOdds > confidence ? 'Over' : 'Under'}
              </span>
            </span>
          </div>
        </div>
      </div>

      {/* Risk Factors */}
      {riskFactors.length > 0 && (
        <div className="mt-4 pt-3 border-t border-gray-700">
          <div className="text-sm text-red-400 mb-2">Risk Factors</div>
          <div className="flex flex-wrap gap-2">
            {riskFactors.map((factor, index) => (
              <span 
                key={index}
                className="px-2 py-1 bg-red-900/20 text-red-400 rounded-full text-xs"
              >
                ⚠️ {factor}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};