import { FaFutbol, FaCricketBall } from 'react-icons/fa';
import { HiOutlineSun, HiOutlineMoon } from 'react-icons/hi';
import { Link } from 'react-router-dom';

interface HeaderProps {
  selectedSport: 'football' | 'cricket';
  onSportChange: (sport: 'football' | 'cricket') => void;
  isAuthenticated: boolean;
  darkMode: boolean;
  toggleTheme: () => void;
}

export const Header = ({
  selectedSport,
  onSportChange,
  isAuthenticated,
  darkMode,
  toggleTheme
}: HeaderProps) => {
  const sportButtonClass = (sport: string) => 
    `flex items-center px-4 py-2 rounded-lg transition-colors ${
      selectedSport === sport 
        ? 'bg-gray-800 text-sport-${sport}' 
        : 'text-gray-400 hover:bg-gray-800'
    }`;

  return (
    <header className="bg-gray-900 border-b border-gray-800 py-4 px-6">
      <div className="flex items-center justify-between max-w-7xl mx-auto">
        {/* Left Section - Logo & Sports Toggle */}
        <div className="flex items-center gap-8">
          <Link to="/" className="flex items-center gap-2">
            <img 
              src="/logo.svg" 
              alt="PredictStats Logo"
              className="h-8 w-8"
            />
            <span className="text-xl font-bold text-accent-blue">
              PredictStats
            </span>
          </Link>

          <div className="flex gap-1 bg-gray-850 p-1 rounded-xl">
            <button
              onClick={() => onSportChange('football')}
              className={sportButtonClass('football')}
            >
              <FaFutbol className="mr-2" />
              Football
            </button>
            <button
              onClick={() => onSportChange('cricket')}
              className={sportButtonClass('cricket')}
            >
              <FaCricketBall className="mr-2" />
              Cricket
            </button>
          </div>
        </div>

        {/* Right Section - Auth & Theme */}
        <div className="flex items-center gap-4">
          <button
            onClick={toggleTheme}
            className="p-2 rounded-lg hover:bg-gray-800 text-gray-400 hover:text-accent-blue"
          >
            {darkMode ? (
              <HiOutlineSun className="text-xl" />
            ) : (
              <HiOutlineMoon className="text-xl" />
            )}
          </button>

          {isAuthenticated ? (
            <div className="relative group">
              <button className="flex items-center gap-2 bg-gray-800 px-4 py-2 rounded-lg hover:bg-gray-750">
                <span className="text-sm">Welcome, User</span>
              </button>
            </div>
          ) : (
            <Link
              to="/login"
              className="bg-accent-blue px-6 py-2 rounded-lg hover:bg-accent-blue-dark transition-colors"
            >
              Login
            </Link>
          )}
        </div>
      </div>
    </header>
  );
};