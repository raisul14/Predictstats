import { FaFutbol, FaCricketBall } from 'react-icons/fa';

interface LiveScoreIndicatorProps {
  sport: 'football' | 'cricket';
  homeScore: string;
  awayScore: string;
  time: string;
  status: 'live' | 'completed' | 'upcoming';
}

export const LiveScoreIndicator = ({
  sport,
  homeScore,
  awayScore,
  time,
  status
}: LiveScoreIndicatorProps) => {
  if (status !== 'live') return null;

  const Icon = sport === 'football' ? FaFutbol : FaCricketBall;
  const sportColor = sport === 'football' ? 'text-sport-football' : 'text-sport-cricket';

  return (
    <div className="flex items-center gap-3 bg-gray-800 px-4 py-2 rounded-full border border-gray-700 shadow-lg">
      <Icon className={`text-xl ${sportColor}`} />
      
      <div className="flex items-center gap-2">
        <span className="font-bold text-lg">{homeScore}</span>
        <span className="text-gray-400 mx-1">vs</span>
        <span className="font-bold text-lg">{awayScore}</span>
      </div>

      <div className="h-4 w-px bg-gray-600" />

      <div className="flex items-center gap-2">
        <span className="text-sm text-gray-300">
          {sport === 'football' ? `${time}'` : `${time} ov`}
        </span>
        <div className="flex items-center gap-1 text-red-400">
          <div className="h-2 w-2 bg-red-400 rounded-full animate-pulse" />
          <span className="text-sm font-semibold">LIVE</span>
        </div>
      </div>
    </div>
  );
};