import { Tooltip } from '../UI/Tooltip';

interface OverSummaryProps {
  overNumber: number;
  runs: number;
  wickets: number;
  events: string[];
}

export const OverSummary = ({ 
  overNumber, 
  runs, 
  wickets, 
  events 
}: OverSummaryProps) => {
  return (
    <div className="p-3 bg-gray-800 rounded-lg shadow-sm hover:bg-gray-750 transition-colors">
      <div className="flex justify-between items-center mb-2">
        <span className="text-sm font-medium text-accent-blue">
          Over {overNumber}
        </span>
        <div className="flex gap-2">
          <span className="text-sm font-semibold text-green-400">
            {runs}r
          </span>
          <span className="text-sm font-semibold text-red-400">
            {wickets}w
          </span>
        </div>
      </div>

      <div className="grid grid-cols-6 gap-1">
        {events.map((event, index) => (
          <Tooltip key={index} content={event.toUpperCase()}>
            <div className={`w-4 h-4 rounded-full flex items-center justify-center text-xs
              ${event === 'wicket' ? 'bg-red-500' : 
                event === '4' ? 'bg-green-400' : 
                event === '6' ? 'bg-green-500' : 
                'bg-gray-700'}`}>
              {event === 'wicket' ? 'W' : event}
            </div>
          </Tooltip>
        ))}
      </div>

      {events.includes('powerplay') && (
        <div className="mt-2 text-xs text-yellow-400 flex items-center gap-1">
          <span>⚡</span>
          Powerplay Over
        </div>
      )}
    </div>
  );
};