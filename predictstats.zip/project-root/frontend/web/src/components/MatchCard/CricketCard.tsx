import { OverSummary } from './OverSummary';
import { Fixture } from '../../utils/types';
import { FaCricketBall } from 'react-icons/fa';

interface CricketCardProps {
  fixture: Fixture;
}

export const CricketCard = ({ fixture }: CricketCardProps) => {
  const isLive = fixture.status === 'live';
  const isCompleted = fixture.status === 'completed';

  return (
    <div className="bg-gray-800 rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow">
      {/* Match Header */}
      <div className="flex justify-between items-start mb-6">
        <div>
          <h3 className="text-lg font-bold text-sport-cricket">
            <FaCricketBall className="inline mr-2" />
            {fixture.league}
          </h3>
          <p className="text-sm text-gray-400 mt-1">
            {fixture.venue} • {fixture.date}
          </p>
        </div>
        {isLive && (
          <span className="px-3 py-1 bg-green-500 text-xs font-bold rounded-full">
            LIVE
          </span>
        )}
      </div>

      {/* Teams & Scores */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="text-right">
          <p className="font-semibold">{fixture.homeTeam}</p>
          <p className="text-2xl font-bold">{fixture.homeScore.runs}/{fixture.homeScore.wickets}</p>
          <p className="text-sm text-gray-400">
            ({fixture.homeScore.overs} overs)
          </p>
        </div>
        
        <div className="text-center text-gray-400 my-auto">vs</div>
        
        <div className="text-left">
          <p className="font-semibold">{fixture.awayTeam}</p>
          <p className="text-2xl font-bold">{fixture.awayScore.runs}/{fixture.awayScore.wickets}</p>
          <p className="text-sm text-gray-400">
            ({fixture.awayScore.overs} overs)
          </p>
        </div>
      </div>

      {/* Match Progress */}
      {isLive && (
        <div className="mb-6">
          <div className="flex justify-between text-sm mb-2">
            <span>{fixture.currentInnings} Innings</span>
            <span>CRR: {fixture.runRate}</span>
          </div>
          <div className="h-2 bg-gray-700 rounded-full">
            <div 
              className="h-full bg-sport-cricket rounded-full transition-all"
              style={{ width: `${(fixture.currentOver / fixture.totalOvers) * 100}%` }}
            />
          </div>
        </div>
      )}

      {/* Recent Overs */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-6">
        {fixture.recentOvers.slice(-3).map((over, index) => (
          <OverSummary key={index} {...over} />
        ))}
      </div>

      {/* Key Players */}
      <div className="border-t border-gray-700 pt-4">
        <h4 className="text-sm font-semibold text-gray-400 mb-3">Key Players</h4>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm font-medium">{fixture.topBatsman.name}</p>
            <p className="text-xs text-gray-400">
              {fixture.topBatsman.runs} ({fixture.topBatsman.balls}) 
              <span className="mx-2">•</span>
              SR: {fixture.topBatsman.strikeRate}
            </p>
          </div>
          <div>
            <p className="text-sm font-medium">{fixture.topBowler.name}</p>
            <p className="text-xs text-gray-400">
              {fixture.topBowler.wickets}/{fixture.topBowler.runs}
              <span className="mx-2">•</span>
              Econ: {fixture.topBowler.economy}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};