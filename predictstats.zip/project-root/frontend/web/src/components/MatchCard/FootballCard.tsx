import { Fixture } from '../../utils/types';
import { FaFutbol } from 'react-icons/fa';
import { Tooltip } from '../UI/Tooltip';

interface FootballCardProps {
  fixture: Fixture;
  prediction?: {
    confidence: number;
    recommendedBet: string;
    riskFactors: string[];
  };
}

export const FootballCard = ({ fixture, prediction }: FootballCardProps) => {
  const isLive = fixture.status === 'live';
  const isCompleted = fixture.status === 'completed';

  return (
    <div className="bg-gray-800 rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow">
      {/* Match Header */}
      <div className="flex justify-between items-start mb-6">
        <div>
          <h3 className="text-lg font-bold text-sport-football">
            <FaFutbol className="inline mr-2" />
            {fixture.league}
          </h3>
          <p className="text-sm text-gray-400 mt-1">
            {fixture.venue} • {fixture.date}
          </p>
        </div>
        {isLive && (
          <span className="px-3 py-1 bg-red-500 text-xs font-bold rounded-full">
            LIVE {fixture.currentMinute}' 
          </span>
        )}
      </div>

      {/* Teams & Scores */}
      <div className="grid grid-cols-3 gap-4 mb-6 items-center">
        <div className="text-right">
          <p className="font-semibold">{fixture.homeTeam}</p>
          {isCompleted && (
            <p className="text-2xl font-bold">{fixture.homeScore}</p>
          )}
        </div>
        
        <div className="text-center">
          {isLive ? (
            <div className="text-lg font-bold text-red-400">
              {fixture.homeScore} - {fixture.awayScore}
            </div>
          ) : (
            <div className="text-gray-400 text-sm">VS</div>
          )}
          {fixture.status === 'upcoming' && (
            <div className="text-xs text-gray-400 mt-1">
              {new Date(fixture.date).toLocaleTimeString([], { 
                hour: '2-digit', minute: '2-digit' 
              })}
            </div>
          )}
        </div>
        
        <div className="text-left">
          <p className="font-semibold">{fixture.awayTeam}</p>
          {isCompleted && (
            <p className="text-2xl font-bold">{fixture.awayScore}</p>
          )}
        </div>
      </div>

      {/* Match Timeline */}
      {isLive && (
        <div className="mb-6">
          <div className="flex justify-between text-sm mb-2">
            <span>First Half</span>
            <span>{fixture.currentMinute}'</span>
          </div>
          <div className="h-2 bg-gray-700 rounded-full">
            <div 
              className="h-full bg-sport-football rounded-full transition-all"
              style={{ width: `${(fixture.currentMinute / 90) * 100}%` }}
            />
          </div>
        </div>
      )}

      {/* Recent Attacks */}
      <div className="grid grid-cols-6 gap-2 mb-6">
        {fixture.recentEvents.map((event, index) => (
          <Tooltip key={index} content={event.type.toUpperCase()}>
            <div className={`w-6 h-6 rounded-full flex items-center justify-center
              ${event.type === 'goal' ? 'bg-green-500' :
                event.type === 'yellow-card' ? 'bg-yellow-400' :
                event.type === 'red-card' ? 'bg-red-500' :
                'bg-gray-700'}`}>
              {event.type === 'goal' ? '⚽' : 
               event.type === 'yellow-card' ? '🟨' : 
               event.type === 'red-card' ? '🟥' : '⚡'}
            </div>
          </Tooltip>
        ))}
      </div>

      {/* Prediction & Stats */}
      <div className="border-t border-gray-700 pt-4">
        <div className="flex justify-between items-center mb-3">
          <h4 className="text-sm font-semibold text-gray-400">
            AI Prediction
          </h4>
          <span className={`text-sm font-bold ${
            prediction?.confidence > 75 ? 'text-green-400' :
            prediction?.confidence > 50 ? 'text-yellow-400' : 'text-red-400'
          }`}>
            {prediction?.confidence}% Confidence
          </span>
        </div>
        
        <div className="flex justify-between text-xs">
          <div>
            {prediction?.riskFactors.map((risk, i) => (
              <span key={i} className="mr-2 text-red-400">⚠️ {risk}</span>
            ))}
          </div>
          <span className="text-gray-400">
            Recommended: {prediction?.recommendedBet}
          </span>
        </div>
      </div>
    </div>
  );
};