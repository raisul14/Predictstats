import { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Fixture, Prediction } from './utils/types';
import Header from './components/Header';
import FixturesList from './components/FixturesList';
import MatchDetail from './pages/MatchDetail';
import Login from './pages/Login';
import AdminPanel from './pages/AdminPanel';
import { FaFutbol, FaCricketBall } from 'react-icons/fa';

const App = () => {
  const [selectedSport, setSelectedSport] = useState<'football' | 'cricket'>('football');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [fixtures, setFixtures] = useState<Fixture[]>([]);
  const [predictions, setPredictions] = useState<Prediction[]>([]);

  // Fetch initial data
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(`/api/${selectedSport}/fixtures`);
        const data = await response.json();
        setFixtures(data);
      } catch (error) {
        console.error('Error fetching fixtures:', error);
      }
    };
    fetchData();
  }, [selectedSport]);

  return (
    <Router>
      <div className="min-h-screen bg-gray-900 text-gray-100">
        <Header 
          selectedSport={selectedSport}
          onSportChange={setSelectedSport}
          isAuthenticated={isAuthenticated}
        />
        
        <main className="container mx-auto px-4 py-8">
          <Routes>
            <Route path="/" element={
              <>
                <div className="grid gap-8 lg:grid-cols-3">
                  <div className="lg:col-span-2">
                    <FixturesList 
                      fixtures={fixtures}
                      sport={selectedSport}
                    />
                  </div>
                  
                  <div className="lg:col-span-1">
                    <div className="bg-gray-800 rounded-lg p-6 shadow-xl">
                      <h2 className="text-xl font-bold mb-4 text-accent-blue">
                        <FaFutbol className="inline mr-2" />
                        Premium Tips
                      </h2>
                      {/* Premium tips content */}
                    </div>
                  </div>
                </div>
              </>
            } />

            <Route path="/match/:matchId" element={<MatchDetail />} />
            <Route path="/login" element={<Login />} />
            <Route path="/admin" element={<AdminPanel />} />
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </main>

        {/* Prediction Confidence Meter */}
        <div className="fixed bottom-0 left-0 right-0 bg-gray-800 p-4 border-t border-gray-700">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm">Prediction Confidence</span>
              <span className="text-sm font-bold text-accent-blue">65%</span>
            </div>
            <div className="h-2 bg-gray-700 rounded-full">
              <div 
                className="h-full bg-accent-blue rounded-full transition-all duration-500"
                style={{ width: '65%' }}
              />
            </div>
          </div>
        </div>
      </div>
    </Router>
  );
};

export default App;