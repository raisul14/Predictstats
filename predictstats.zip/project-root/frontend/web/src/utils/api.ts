import { Fixture, Prediction, User } from './types';

const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:8000/api';

async function request<T>(endpoint: string, config?: RequestInit): Promise<T> {
  const token = localStorage.getItem('authToken');
  const headers = new Headers(config?.headers);
  
  headers.set('Content-Type', 'application/json');
  if (token) headers.set('Authorization', `Bearer ${token}`);

  const response = await fetch(`${API_BASE}${endpoint}`, {
    ...config,
    headers,
    credentials: 'include',
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.message || 'API request failed');
  }

  return response.json();
}

// Authentication
export const authAPI = {
  login: (email: string, password: string) => 
    request<{ token: string; user: User }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    }),

  register: (userData: {
    email: string;
    password: string;
    username: string;
    favoriteSport?: 'football' | 'cricket';
  }) => request<User>('/auth/register', {
    method: 'POST',
    body: JSON.stringify(userData),
  }),
};

// Fixtures & Predictions
export const matchesAPI = {
  getFixtures: (sport: 'football' | 'cricket') => 
    request<Fixture[]>(`/${sport}/fixtures`),

  getMatchDetails: (matchId: string) => 
    request<Fixture>(`/matches/${matchId}`),

  getPredictions: (matchId: string) => 
    request<Prediction>(`/predictions/${matchId}`),

  submitPrediction: (matchId: string, prediction: {
    outcome: 'home' | 'draw' | 'away';
    confidence: number;
  }) => request<{ success: boolean }>(`/predictions/${matchId}`, {
    method: 'POST',
    body: JSON.stringify(prediction),
  }),
};

// User & Analytics
export const userAPI = {
  getProfile: () => request<User>('/users/me'),
  
  getPredictionHistory: (params?: {
    sport?: 'football' | 'cricket';
    limit?: number;
  }) => request<Prediction[]>('/users/predictions', {
    method: 'GET',
    ...(params && { body: JSON.stringify(params) }),
  }),

  updatePreferences: (prefs: {
    favoriteTeam?: string;
    notificationSettings?: {
      matchStart: boolean;
      predictionResult: boolean;
    };
  }) => request<User>('/users/preferences', {
    method: 'PATCH',
    body: JSON.stringify(prefs),
  }),
};

// Admin Endpoints
export const adminAPI = {
  moderatePrediction: (predictionId: string, approved: boolean) =>
    request<{ success: boolean }>(`/admin/predictions/${predictionId}`, {
      method: 'PATCH',
      body: JSON.stringify({ approved }),
    }),

  getUsers: (params?: {
    page?: number;
    search?: string;
  }) => request<{ users: User[]; total: number }>('/admin/users', {
    method: 'GET',
    ...(params && { body: JSON.stringify(params) }),
  }),
};

// Utility Types
export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  pageSize: number;
}