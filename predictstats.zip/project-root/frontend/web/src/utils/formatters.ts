export const formatDate = (dateString: string | Date): string => {
  const date = new Date(dateString);
  return new Intl.DateTimeFormat('en-GB', {
    day: 'numeric',
    month: 'short',
    year: 'numeric'
  }).format(date);
};

export const formatTime = (dateString: string | Date): string => {
  const date = new Date(dateString);
  return new Intl.DateTimeFormat('en-GB', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: true
  }).format(date);
};

export const formatPercentage = (value: number): string => {
  return `${Math.round(value)}%`;
};

export const formatCurrency = (value: number, currency = 'USD'): string => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency,
    maximumFractionDigits: 0
  }).format(value);
};

export const formatScore = (
  home: number, 
  away: number, 
  sport: 'football' | 'cricket'
): string => {
  return sport === 'cricket' 
    ? `${home}/${away}` 
    : `${home} - ${away}`;
};

export const formatOvers = (overs: number): string => {
  const fullOvers = Math.floor(overs);
  const balls = Math.round((overs % 1) * 10);
  return balls > 0 ? `${fullOvers}.${balls}` : `${fullOvers}`;
};

export const formatLargeNumber = (num: number): string => {
  if (num >= 1e6) return `${(num / 1e6).toFixed(1)}M`;
  if (num >= 1e3) return `${(num / 1e3).toFixed(1)}K`;
  return num.toString();
};

export const formatOdds = (odds: number): string => {
  return odds > 0 ? `+${odds}` : odds.toString();
};

export const relativeTime = (dateString: string | Date): string => {
  const date = new Date(dateString);
  const now = new Date();
  const diffSeconds = Math.round((date.getTime() - now.getTime()) / 1000);
  
  const units = [
    { name: 'year', seconds: 31536000 },
    { name: 'month', seconds: 2592000 },
    { name: 'day', seconds: 86400 },
    { name: 'hour', seconds: 3600 },
    { name: 'minute', seconds: 60 },
  ];

  for (const unit of units) {
    const divisor = unit.seconds;
    const diff = Math.floor(diffSeconds / divisor);
    
    if (Math.abs(diff) >= 1) {
      return new Intl.RelativeTimeFormat('en', { numeric: 'auto' }).format(diff, unit.name as any);
    }
  }
  
  return 'Just now';
};

// Sport-specific formatters
export const cricketFormatters = {
  formatStrikeRate: (runs: number, balls: number): string => 
    balls > 0 ? ((runs / balls) * 100).toFixed(1) : '0.0',

  formatEconomy: (runs: number, overs: number): string => 
    overs > 0 ? (runs / overs).toFixed(1) : '0.0',
};

export const footballFormatters = {
  formatPossession: (value: number): string => 
    `${value.toFixed(1)}%`,

  formatPassAccuracy: (completed: number, attempted: number): string => 
    attempted > 0 ? `${((completed / attempted) * 100).toFixed(1)}%` : '0%',
};