export const MATCH_STATUS = {
  LIVE: 'live',
  UPCOMING: 'upcoming',
  COMPLETED: 'completed',
  ICONS: {
    live: '🔴',
    upcoming: '🟡',
    completed: '🟢'
  },
  COLORS: {
    live: '#e53e3e',
    upcoming: '#d69e2e',
    completed: '#38a169'
  }
} as const;

export const SPORTS = {
  FOOTBALL: {
    name: 'football',
    icon: '⚽',
    color: '#3B82F6'
  },
  CRICKET: {
    name: 'cricket',
    icon: '🏏',
    color: '#10B981'
  }
} as const;

export const BETTING_MARKETS = {
  FOOTBALL: {
    MATCH_WINNER: { label: 'Match Winner', values: ['home', 'draw', 'away'] },
    OVER_UNDER: { label: 'Over/Under Goals', values: ['over', 'under'] },
    BTTS: { label: 'Both Teams to Score', values: ['yes', 'no'] }
  },
  CRICKET: {
    TOP_BATSMAN: { label: 'Top Batsman', values: [] },
    MATCH_WINNER: { label: 'Match Winner', values: ['home', 'away'] },
    TOTAL_RUNS: { label: 'Total Runs', values: ['over', 'under'] }
  }
} as const;

export const API_ENDPOINTS = {
  FIXTURES: (sport: string) => `/${sport}/fixtures`,
  PREDICTIONS: {
    BASE: (sport: string) => `/${sport}/predictions`,
    SINGLE: (id: string) => `/predictions/${id}`
  },
  LIVE_DATA: (matchId: string) => `/matches/${matchId}/live`
} as const;

export const LEAGUES = {
  FOOTBALL: [
    'Premier League', 'La Liga', 'Bundesliga', 
    'Serie A', 'Ligue 1', 'Champions League'
  ],
  CRICKET: [
    'IPL', 'Big Bash', 'County Championship',
    'The Hundred', 'PSL', 'International'
  ]
} as const;

export const PAGINATION = {
  DEFAULT_PAGE_SIZE: 10,
  MAX_PAGE_SIZE: 50
} as const;

export const CURRENCY = {
  DEFAULT: 'USD',
  FORMAT_OPTIONS: {
    style: 'currency',
    minimumFractionDigits: 0,
    maximumFractionDigits: 2
  }
} as const;

export const ERROR_MESSAGES = {
  API_FAILURE: 'Failed to fetch data - please try again later',
  PREDICTION_SUBMIT: 'Could not submit prediction - validate your inputs',
  INVALID_CREDENTIALS: 'Invalid email or password combination'
} as const;

export const TIME = {
  LIVE_UPDATE_INTERVAL: 30000, // 30 seconds
  CACHE_TTL: 600000 // 10 minutes
} as const;

export const AUTH = {
  TOKEN_KEY: 'predictstats_auth_token',
  REFRESH_INTERVAL: 840000 // 14 minutes
} as const;

// For odds display formatting
export const ODDS_FORMAT = {
  DECIMAL: 'DECIMAL',
  FRACTIONAL: 'FRACTIONAL',
  AMERICAN: 'AMERICAN'
} as const;

export type SportsType = keyof typeof SPORTS;
export type MatchStatus = keyof typeof MATCH_STATUS.ICONS;