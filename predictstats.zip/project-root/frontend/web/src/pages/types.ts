interface Fixture {
  stats: {
    // Football
    possession?: number;
    shotsOnTarget?: number;
    fouls?: number;
    corners?: number;
    // Cricket
    runRate?: number;
    wickets?: number;
    boundaries?: number;
    extras?: number;
  };
  prediction: {
    confidence: number;
    isValue: boolean;
    marketOdds: number;
    riskFactors: string[];
  };
  commentary: Array<{
    minute: number;
    type: 'goal' | 'wicket' | 'card' | 'other';
    text: string;
  }>;
  liveOdds: Array<{
    market: string;
    value: string;
  }>;
  keyPlayers: PlayerPerformance[];
}