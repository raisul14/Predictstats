import { useState } from 'react';
import { BarChart, Settings, Users, Shield, Activity, AlertCircle } from 'react-feather';
import { AdminUserTable } from '../components/Admin/UserTable';
import { PredictionModeration } from '../components/Admin/PredictionModeration';
import { SystemHealthWidget } from '../components/Admin/SystemHealth';
import { BrandingControls } from '../components/Admin/BrandingControls';

const AdminPanel = () => {
  const [activeTab, setActiveTab] = useState('dashboard');

  const navigation = [
    { id: 'dashboard', icon: <BarChart size={18} />, label: 'Analytics' },
    { id: 'users', icon: <Users size={18} />, label: 'User Management' },
    { id: 'moderation', icon: <Shield size={18} />, label: 'Content Moderation' },
    { id: 'branding', icon: <Settings size={18} />, label: 'Branding' },
    { id: 'monitoring', icon: <Activity size={18} />, label: 'System Health' },
    { id: 'compliance', icon: <AlertCircle size={18} />, label: 'Compliance' }
  ];

  return (
    <div className="min-h-screen bg-gray-900">
      <div className="flex">
        {/* Sidebar Navigation */}
        <nav className="w-64 bg-gray-800 border-r border-gray-700 p-4 min-h-screen">
          <div className="mb-8">
            <h2 className="text-xl font-bold text-accent-blue px-2">Admin Console</h2>
          </div>
          <ul className="space-y-1">
            {navigation.map((item) => (
              <li key={item.id}>
                <button
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${
                    activeTab === item.id 
                      ? 'bg-gray-700 text-accent-blue' 
                      : 'text-gray-300 hover:bg-gray-700'
                  }`}
                >
                  {item.icon}
                  <span className="text-sm">{item.label}</span>
                </button>
              </li>
            ))}
          </ul>
        </nav>

        {/* Main Content Area */}
        <main className="flex-1 p-8">
          {/* Dashboard Overview */}
          {activeTab === 'dashboard' && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <SystemHealthWidget />
              <div className="bg-gray-800 p-6 rounded-xl">
                <h3 className="text-lg font-semibold mb-4">Recent Activity</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between text-sm">
                    <span>New user registration</span>
                    <span className="text-gray-400">2m ago</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span>Prediction approved</span>
                    <span className="text-gray-400">15m ago</span>
                  </div>
                </div>
              </div>
              <div className="bg-gray-800 p-6 rounded-xl">
                <h3 className="text-lg font-semibold mb-4">Quick Actions</h3>
                <div className="space-y-2">
                  <button className="w-full text-left px-4 py-2 bg-gray-700 hover:bg-gray-600 rounded-lg">
                    Generate Report
                  </button>
                  <button className="w-full text-left px-4 py-2 bg-gray-700 hover:bg-gray-600 rounded-lg">
                    Audit Logs
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* User Management */}
          {activeTab === 'users' && (
            <div className="bg-gray-800 rounded-xl p-6">
              <AdminUserTable />
            </div>
          )}

          {/* Prediction Moderation */}
          {activeTab === 'moderation' && (
            <div className="space-y-6">
              <PredictionModeration />
            </div>
          )}

          {/* Branding Controls */}
          {activeTab === 'branding' && <BrandingControls />}

          {/* System Monitoring */}
          {activeTab === 'monitoring' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-gray-800 p-6 rounded-xl">
                <h3 className="text-lg font-semibold mb-4">API Performance</h3>
                <div className="h-64 bg-gray-700 rounded-lg animate-pulse" />
              </div>
              <div className="bg-gray-800 p-6 rounded-xl">
                <h3 className="text-lg font-semibold mb-4">Database Health</h3>
                <div className="h-64 bg-gray-700 rounded-lg animate-pulse" />
              </div>
            </div>
          )}

          {/* Compliance Tools */}
          {activeTab === 'compliance' && (
            <div className="bg-gray-800 rounded-xl p-6">
              <h2 className="text-xl font-semibold mb-6">Data Compliance</h2>
              <div className="grid grid-cols-2 gap-4">
                <button className="p-4 bg-gray-700 hover:bg-gray-600 rounded-lg">
                  Export User Data
                </button>
                <button className="p-4 bg-gray-700 hover:bg-gray-600 rounded-lg">
                  GDPR Requests
                </button>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default AdminPanel;
// Wrap with permission check
<Route path="/admin" element={
  <RequireAuth role="admin">
    <AdminPanel />
  </RequireAuth>
}/>