import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { Fixture } from '../utils/types';
import { Header } from '../components/Header';
import { LiveScoreIndicator } from '../components/LiveScoreIndicator';
import { Tab } from '../components/UI/Tab';
import { TipSection } from '../components/TipSection';
import { PlayerPerformance } from '../components/MatchCard/PlayerPerformance';
import { PulseLoader } from 'react-spinners';

export const MatchDetail = () => {
  const { matchId } = useParams();
  const [matchData, setMatchData] = useState<Fixture | null>(null);
  const [activeTab, setActiveTab] = useState('stats');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchMatchDetails = async () => {
      try {
        const response = await fetch(`/api/matches/${matchId}`);
        if (!response.ok) throw new Error('Match not found');
        const data = await response.json();
        setMatchData(data);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load match');
      } finally {
        setIsLoading(false);
      }
    };

    fetchMatchDetails();
  }, [matchId]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <PulseLoader color="#1a73e8" size={20} />
      </div>
    );
  }

  if (error || !matchData) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center text-red-400">
        {error || 'Match data unavailable'}
      </div>
    );
  }

  const isFootball = matchData.sport === 'football';
  const isLive = matchData.status === 'live';

  return (
    <div className="min-h-screen bg-gray-900">
      <Header showSportToggle={false} />
      
      {/* Live Score Banner */}
      {isLive && (
        <LiveScoreIndicator
          sport={matchData.sport}
          homeScore={matchData.homeScore?.toString() || '0'}
          awayScore={matchData.awayScore?.toString() || '0'}
          time={isFootball ? `${matchData.currentMinute}'` : `${matchData.currentOver} ov`}
          status="live"
        />
      )}

      <main className="container mx-auto px-4 py-8">
        {/* Match Header */}
        <div className="bg-gray-800 rounded-xl p-6 mb-8 text-center">
          <h1 className="text-2xl font-bold mb-4">
            {matchData.homeTeam} vs {matchData.awayTeam}
          </h1>
          <div className="flex justify-center items-center gap-4 text-gray-400">
            <span>{matchData.league}</span>
            <span>•</span>
            <span>{matchData.venue}</span>
            <span>•</span>
            <span>{new Date(matchData.date).toLocaleDateString()}</span>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex gap-2 mb-8 border-b border-gray-700">
          {['stats', 'lineup', 'predictions', 'commentary'].map((tab) => (
            <Tab
              key={tab}
              label={tab.charAt(0).toUpperCase() + tab.slice(1)}
              isActive={activeTab === tab}
              onClick={() => setActiveTab(tab)}
            />
          ))}
        </div>

        {/* Tab Content */}
        <div className="grid gap-8 lg:grid-cols-3">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {activeTab === 'stats' && (
              <div className="grid grid-cols-2 gap-4 mb-8">
                {isFootball ? (
                  <>
                    <StatCard title="Possession" value={`${matchData.stats.possession}%`} />
                    <StatCard title="Shots on Target" value={matchData.stats.shotsOnTarget} />
                    <StatCard title="Fouls" value={matchData.stats.fouls} />
                    <StatCard title="Corners" value={matchData.stats.corners} />
                  </>
                ) : (
                  <>
                    <StatCard title="Run Rate" value={matchData.stats.runRate} />
                    <StatCard title="Wickets" value={matchData.stats.wickets} />
                    <StatCard title="Boundaries" value={matchData.stats.boundaries} />
                    <StatCard title="Extras" value={matchData.stats.extras} />
                  </>
                )}
              </div>
            )}

            {activeTab === 'lineup' && (
              <div className="grid grid-cols-2 gap-4">
                <TeamLineup team={matchData.homeTeam} players={matchData.homeLineup} />
                <TeamLineup team={matchData.awayTeam} players={matchData.awayLineup} />
              </div>
            )}

            {activeTab === 'predictions' && (
              <TipSection
                confidence={matchData.prediction.confidence}
                isValueTip={matchData.prediction.isValue}
                marketOdds={matchData.prediction.marketOdds}
                riskFactors={matchData.prediction.riskFactors}
              />
            )}

            {activeTab === 'commentary' && (
              <div className="space-y-4">
                {matchData.commentary.map((entry, index) => (
                  <div key={index} className="bg-gray-800 p-4 rounded-lg">
                    <div className="flex justify-between text-sm text-gray-400 mb-2">
                      <span>{entry.minute}'</span>
                      <span>{entry.type}</span>
                    </div>
                    <p className="text-gray-300">{entry.text}</p>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            <div className="bg-gray-800 p-6 rounded-xl">
              <h3 className="text-lg font-semibold mb-4">Key Players</h3>
              <div className="space-y-4">
                <PlayerPerformance
                  player={matchData.topPerformer}
                  performance={matchData.topPerformer.stats}
                />
                {matchData.keyPlayers.map((player, index) => (
                  <PlayerPerformance
                    key={index}
                    player={player}
                    performance={player.stats}
                  />
                ))}
              </div>
            </div>

            {isLive && (
              <div className="bg-gray-800 p-6 rounded-xl">
                <h3 className="text-lg font-semibold mb-4">Live Odds</h3>
                <div className="space-y-3">
                  {matchData.liveOdds.map((odd, index) => (
                    <div key={index} className="flex justify-between text-sm">
                      <span>{odd.market}</span>
                      <span className="font-semibold">{odd.value}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

// Helper Components
const StatCard = ({ title, value }: { title: string; value: string | number }) => (
  <div className="bg-gray-800 p-4 rounded-lg text-center">
    <div className="text-2xl font-bold mb-1">{value}</div>
    <div className="text-sm text-gray-400">{title}</div>
  </div>
);

const TeamLineup = ({ team, players }: { team: string; players: any[] }) => (
  <div className="bg-gray-800 p-4 rounded-lg">
    <h4 className="font-semibold mb-4">{team}</h4>
    <div className="space-y-2">
      {players.map((player, index) => (
        <div key={index} className="flex justify-between text-sm">
          <span>{player.name}</span>
          <span className="text-gray-400">{player.position}</span>
        </div>
      ))}
    </div>
  </div>
);