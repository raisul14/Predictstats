import { useState, useEffect } from 'react';
import { Fixture } from '../utils/types';
import { Header } from '../components/Header';
import { FixturesList } from '../components/FixturesList';
import { TipSection } from '../components/TipSection';

const Home = () => {
  const [selectedSport, setSelectedSport] = useState<'football' | 'cricket'>('football');
  const [fixtures, setFixtures] = useState<Fixture[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Fetch fixtures based on selected sport
  useEffect(() => {
    const fetchFixtures = async () => {
      setIsLoading(true);
      try {
        const response = await fetch(`/api/${selectedSport}/fixtures`);
        const data = await response.json();
        setFixtures(data);
      } catch (error) {
        console.error('Error fetching fixtures:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchFixtures();
  }, [selectedSport]);

  return (
    <div className="min-h-screen bg-gray-900">
      <Header 
        selectedSport={selectedSport}
        onSportChange={setSelectedSport}
        isAuthenticated={false} // Update based on auth state
      />
      
      <main className="container mx-auto px-4 py-8">
        <div className="grid gap-8 lg:grid-cols-3">
          {/* Main Fixtures List */}
          <div className="lg:col-span-2">
            <FixturesList 
              fixtures={fixtures}
              sport={selectedSport}
              isLoading={isLoading}
            />
          </div>

          {/* Premium Tips Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            <TipSection
              confidence={82}
              isValueTip={true}
              marketOdds={68}
              riskFactors={['Key player injury', 'Weather concerns']}
              isHighVolatility={selectedSport === 'football'}
            />
            
            <div className="bg-gray-800 p-6 rounded-xl border border-gray-700">
              <h2 className="text-xl font-bold mb-4 text-accent-blue">
                {selectedSport.charAt(0).toUpperCase() + selectedSport.slice(1)} Trends
              </h2>
              <div className="space-y-4">
                <div className="flex justify-between text-sm">
                  <span>Today's Matches</span>
                  <span>{fixtures.length}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Average Confidence</span>
                  <span className="text-green-400">78%</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Value Tips</span>
                  <span className="text-yellow-400">12</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Home;
interface HomeProps {
  // Inherited from App routing
}

interface Fixture {
  id: string;
  sport: 'football' | 'cricket';
  league: string;
  homeTeam: string;
  awayTeam: string;
  status: 'upcoming' | 'live' | 'completed';
  // ... other fixture properties
}