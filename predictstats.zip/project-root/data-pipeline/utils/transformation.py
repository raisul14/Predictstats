import numpy as np
import pandas as pd
import logging
from typing import Optional, List
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

logger = logging.getLogger(__name__)

def encode_cyclic_features(df: pd.DataFrame, 
                          column: str, 
                          max_val: float) -> pd.DataFrame:
    """
    Encode cyclical features using sine/cosine transformation
    
    Args:
        df: Input DataFrame
        column: Column name to encode
        max_val: Maximum value for cyclic feature (e.g., 24 for hours)
    
    Returns:
        DataFrame with added _sin and _cos columns
    """
    try:
        if column not in df.columns:
            raise ValueError(f"Column {column} not found in DataFrame")
            
        df[f"{column}_sin"] = np.sin(2 * np.pi * df[column]/max_val)
        df[f"{column}_cos"] = np.cos(2 * np.pi * df[column]/max_val)
        
    except Exception as e:
        logger.error(f"Cyclic encoding failed: {str(e)}")
        raise
    
    return df

def calculate_momentum(series: pd.Series, 
                      window: int = 5,
                      min_periods: int = 1) -> pd.Series:
    """
    Calculate rolling momentum with exponential weighting
    
    Args:
        series: Input time-series data
        window: Rolling window size
        min_periods: Minimum observations in window
    
    Returns:
        Momentum values series
    """
    try:
        return series.ewm(
            span=window,
            min_periods=min_periods
        ).mean().fillna(series.mean())
        
    except Exception as e:
        logger.error(f"Momentum calculation failed: {str(e)}")
        raise

def exponential_smoothing(values: np.ndarray,
                         alpha: float = 0.3) -> np.ndarray:
    """
    Apply exponential smoothing to time-series data
    
    Args:
        values: 1D array of values
        alpha: Smoothing factor (0 < alpha < 1)
    
    Returns:
        Smoothed array
    """
    if not 0 < alpha < 1:
        raise ValueError("Alpha must be between 0 and 1")
    
    smoothed = np.zeros_like(values)
    smoothed[0] = values[0]
    
    for i in range(1, len(values)):
        smoothed[i] = alpha * values[i] + (1 - alpha) * smoothed[i-1]
    
    return smoothed

def calculate_derived_metrics(df: pd.DataFrame,
                             sport_type: str) -> pd.DataFrame:
    """
    Calculate sport-specific derived metrics
    
    Args:
        df: Input DataFrame
        sport_type: 'cricket' or 'football'
    
    Returns:
        DataFrame with new metrics
    """
    df = df.copy()
    
    try:
        if sport_type == 'cricket':
            # Batting momentum metrics
            df['run_rate'] = df['runs'] / df['overs']
            df['boundary_frequency'] = df['boundaries'] / df['balls_faced']
            
            # Bowling pressure metrics
            df['dot_ball_pressure'] = (
                df['dots_last_5'] * df['economy_rate']
            )
            
        elif sport_type == 'football':
            # Possession effectiveness
            df['possession_quality'] = (
                df['xg'] / (df['possession'] + 1e-6)
            )
            
            # Defensive pressure
            df['pressure_index'] = (
                df['tackles'] + df['interceptions'] - df['defensive_errors']
            )
            
        else:
            raise ValueError(f"Unsupported sport type: {sport_type}")
            
    except KeyError as e:
        logger.error(f"Missing required column: {str(e)}")
        raise
    
    return df

def normalize_features(df: pd.DataFrame,
                      features: List[str],
                      scaler: Optional[StandardScaler] = None):
    """
    Normalize features using z-score scaling
    
    Args:
        df: Input DataFrame
        features: List of columns to normalize
        scaler: Pre-fit scaler for consistent transformation
    
    Returns:
        Tuple of (normalized DataFrame, fitted scaler)
    """
    df = df.copy()
    valid_features = [f for f in features if f in df.columns]
    
    if not valid_features:
        raise ValueError("No valid features found for normalization")
    
    try:
        if scaler is None:
            scaler = StandardScaler()
            df[valid_features] = scaler.fit_transform(df[valid_features])
        else:
            df[valid_features] = scaler.transform(df[valid_features])
            
    except Exception as e:
        logger.error(f"Feature normalization failed: {str(e)}")
        raise
    
    return df, scaler

def create_interaction_terms(df: pd.DataFrame,
                            base_features: List[str],
                            sport_type: str) -> pd.DataFrame:
    """
    Generate meaningful interaction terms for sports data
    
    Args:
        df: Input DataFrame
        base_features: Features to create interactions from
        sport_type: Sport context for relevant interactions
    
    Returns:
        DataFrame with interaction terms
    """
    df = df.copy()
    
    try:
        if sport_type == 'cricket':
            if 'strike_rate' in base_features and 'boundary_percent' in base_features:
                df['sr_boundary_ratio'] = df['strike_rate'] / (df['boundary_percent'] + 1e-6)
                
            if 'player_form' in base_features and 'venue_avg' in base_features:
                df['form_venue_combo'] = df['player_form'] * df['venue_avg']
                
        elif sport_type == 'football':
            if 'possession' in base_features and 'xg' in base_features:
                df['xg_per_possession'] = df['xg'] / (df['possession'] + 1e-6)
                
            if 'defensive_pressure' in base_features and 'away_form' in base_features:
                df['away_defense_impact'] = df['defensive_pressure'] * df['away_form']
                
    except KeyError as e:
        logger.error(f"Interaction term creation failed - missing feature: {str(e)}")
        raise
    
    return df

# Example Usage:
if __name__ == "__main__":
    # Sample cricket data transformation
    df = pd.DataFrame({
        'overs': [10, 20, 30, 40],
        'runs': [50, 120, 200, 280],
        'boundaries': [8, 15, 22, 30]
    })
    
    # Cyclic encoding
    df = encode_cyclic_features(df, 'overs', max_val=50)
    
    # Momentum calculation
    df['run_momentum'] = calculate_momentum(df['runs'], window=3)
    
    # Derived metrics
    df = calculate_derived_metrics(df, sport_type='cricket')
    
    print(df.head())