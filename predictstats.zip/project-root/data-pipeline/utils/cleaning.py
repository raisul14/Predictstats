import pandas as pd
import numpy as np
import logging

logging.basicConfig(level=logging.INFO)

def clean_cricket_data(raw_df, outlier_thresholds=None):
    """
    Clean raw cricket match data with comprehensive quality checks
    
    Args:
        raw_df: Raw cricket DataFrame
        outlier_thresholds: Dict of {'col': (min, max)} for outlier detection
    
    Returns:
        Cleaned DataFrame with consistent schema
    """
    df = raw_df.copy()
    
    # 1. Handle Missing Values
    df['player_form'] = df.groupby('player_id')['player_form'] \
        .transform(lambda x: x.fillna(x.mean()))
    df['venue'].fillna('Unknown', inplace=True)
    
    # 2. Fix Data Types
    df['match_date'] = pd.to_datetime(df['match_date'], errors='coerce')
    
    # 3. Remove Impossible Values
    df = df[(df['runs'].between(0, 500)) & 
           (df['wickets'].between(0, 10)) &
           (df['overs'].between(5, 50))]
    
    # 4. Custom Outlier Detection
    default_thresholds = {
        'strike_rate': (30, 200),
        'economy_rate': (2, 12),
        'boundary_percent': (0, 80)
    }
    thresholds = outlier_thresholds or default_thresholds
    
    for col, (min_val, max_val) in thresholds.items():
        if col in df.columns:
            df = df[df[col].between(min_val, max_val)]
    
    # 5. Validate Match Outcomes
    valid_outcomes = df[['team1_score', 'team2_score']].notna().all(axis=1)
    df = df[valid_outcomes].dropna(subset=['match_result'])
    
    logging.info(f"Cricket data cleaned: {len(raw_df)} -> {len(df)} rows")
    return df.reset_index(drop=True)

def clean_football_data(raw_df, xg_impute_strategy='team_mean'):
    """
    Clean football match data with advanced xG handling
    
    Args:
        raw_df: Raw football DataFrame
        xg_impute_strategy: 'team_mean' or 'last3_avg'
    
    Returns:
        Cleaned football data with validated metrics
    """
    df = raw_df.copy()
    
    # 1. xG Imputation
    if xg_impute_strategy == 'team_mean':
        df['home_xg'] = df.groupby('home_team')['home_xg'] \
            .transform(lambda x: x.fillna(x.mean()))
        df['away_xg'] = df.groupby('away_team')['away_xg'] \
            .transform(lambda x: x.fillna(x.mean()))
    elif xg_impute_strategy == 'last3_avg':
        df['home_xg'] = df.groupby('home_team')['home_xg'] \
            .transform(lambda x: x.fillna(x.rolling(3, min_periods=1).mean()))
        df['away_xg'] = df.groupby('away_team')['away_xg'] \
            .transform(lambda x: x.fillna(x.rolling(3, min_periods=1).mean()))
    
    # 2. Validate Core Metrics
    df = df[(df['home_possession'].between(20, 80)) &
           (df['away_possession'].between(20, 80)) &
           (df['total_shots'] >= df['shots_on_target'])]
    
    # 3. Fix Percentage Columns
    pct_cols = ['conversion_rate', 'save_percent', 'aerial_duels_won']
    for col in pct_cols:
        if col in df.columns:
            df[col] = df[col].clip(0, 100)
    
    # 4. Temporal Features
    df['days_since_last_match'] = df.sort_values('match_date') \
        .groupby(['home_team', 'away_team'])['match_date'] \
        .diff().dt.days.fillna(30)
    
    # 5. Outcome Validation
    valid_results = df[['home_goals', 'away_goals']].notna().all(axis=1)
    df = df[valid_results].dropna(subset=['match_result'])
    
    logging.info(f"Football data cleaned: {len(raw_df)} -> {len(df)} rows")
    return df.reset_index(drop=True)

def clean_generic_data(df, date_cols=None, cat_cols=None):
    """
    Apply universal cleaning steps to any sports dataset
    
    1. Drop exact duplicates
    2. Strip whitespace from strings
    3. Fix numeric columns
    4. Handle date columns
    5. Categorical encoding
    """
    # 1. Deduplication
    df = df.drop_duplicates().reset_index(drop=True)
    
    # 2. String Cleaning
    str_cols = df.select_dtypes(include='object').columns
    df[str_cols] = df[str_cols].apply(lambda x: x.str.strip())
    
    # 3. Numeric Columns
    num_cols = df.select_dtypes(include=np.number).columns
    df[num_cols] = df[num_cols].apply(pd.to_numeric, errors='coerce')
    
    # 4. Date Handling
    if date_cols:
        for col in date_cols:
            df[col] = pd.to_datetime(df[col], errors='coerce')
    
    # 5. Categorical Encoding
    if cat_cols:
        df[cat_cols] = df[cat_cols].astype('category')
    
    # 6. Missing Value Tagging
    df['_missing_data'] = df.isnull().sum(axis=1) > 0
    
    logging.info(f"Generic cleaning completed: {len(df)} rows")
    return df

def handle_missing_values(df, strategy='auto', cols=None, group_col=None):
    """
    Advanced missing value handling with grouping support
    
    Strategies:
    - 'auto': Numeric->mean, Categorical->mode
    - 'drop': Remove rows
    - 'group': Impute within groups
    """
    if strategy == 'drop':
        return df.dropna(subset=cols)
        
    if strategy == 'group' and group_col:
        group = df.groupby(group_col)
        return df.fillna(group.transform(lambda x: x.mean() 
            if np.issubdtype(x.dtype, np.number) else x.mode().iloc[0]))
    
    # Auto strategy
    if cols is None:
        cols = df.columns
        
    for col in cols:
        if col in df.columns:
            if np.issubdtype(df[col].dtype, np.number):
                fill_val = df[col].mean()
            else:
                fill_val = df[col].mode()[0]
            df[col] = df[col].fillna(fill_val)
    
    return df