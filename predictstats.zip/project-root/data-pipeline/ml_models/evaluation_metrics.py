import numpy as np
from sklearn.metrics import log_loss, brier_score_loss, mean_absolute_error, mean_squared_error
from scipy.stats import binned_statistic

def weighted_log_loss(y_true, y_pred_probs, class_weights=None):
    """
    Calculate class-weighted logarithmic loss
    Args:
        y_true: True labels (array-like)
        y_pred_probs: Predicted probabilities (2D array)
        class_weights: Optional pre-calculated class weights
    Returns:
        Weighted log loss score
    """
    classes = np.unique(y_true)
    if class_weights is None:
        class_weights = [np.mean(y_true == c) for c in classes]
    
    loss = 0.0
    for i, c in enumerate(classes):
        loss += class_weights[i] * log_loss(y_true == c, y_pred_probs[:, i])
    return loss / sum(class_weights)

def probability_calibration(y_true, pred_probs, n_bins=10):
    """
    Calculate calibration curve data for probabilistic predictions
    Returns:
        (mean_predicted_probs, mean_actual_probs) tuple
    """
    bin_edges = np.linspace(0, 1, n_bins + 1)
    bin_indices = np.digitize(pred_probs, bin_edges, right=True) - 1
    
    mean_preds = binned_statistic(pred_probs, pred_probs, 
                                statistic='mean', bins=bin_edges).statistic
    mean_actual = binned_statistic(pred_probs, y_true, 
                                 statistic='mean', bins=bin_edges).statistic
    return mean_preds, mean_actual

def brier_multi(targets, probs):
    """
    Multi-class Brier score
    """
    return np.mean(np.sum((probs - targets) ** 2, axis=1))

def within_tolerance(y_true, y_pred, tolerance):
    """
    Calculate percentage of predictions within ±tolerance of actual values
    """
    diffs = np.abs(y_true - y_pred)
    return np.mean(diffs <= tolerance) * 100

def top_k_accuracy(y_true, y_pred_probs, k=3):
    """
    Calculate top-k classification accuracy
    """
    top_k_preds = np.argsort(y_pred_probs, axis=1)[:, -k:]
    return np.mean([1 if y in preds else 0 
                  for y, preds in zip(y_true, top_k_preds)])

def format_metrics(metrics_dict):
    """
    Format metrics dictionary for human-readable reporting
    """
    formatted = {}
    for key, value in metrics_dict.items():
        if isinstance(value, float):
            formatted[key] = f"{value:.3f}"
        elif isinstance(value, dict):
            formatted[key] = {k: f"{v:.3f}" for k, v in value.items()}
        else:
            formatted[key] = str(value)
    return formatted

# Football-specific metrics
def xg_r2_score(y_true, y_pred, baseline_xg):
    """
    R² score comparing predictions to xG baseline model
    """
    ss_res = np.sum((y_true - y_pred) ** 2)
    ss_tot = np.sum((y_true - baseline_xg) ** 2)
    return 1 - (ss_res / ss_tot)

# Cricket-specific metrics  
def partnership_break_prediction(y_true, y_pred, over_window=3):
    """
    Custom metric for predicting wicket likelihood in next N overs
    """
    y_true_window = np.convolve(y_true, np.ones(over_window), mode='valid')
    y_pred_window = np.convolve(y_pred, np.ones(over_window), mode='valid')
    return roc_auc_score(y_true_window > 0, y_pred_window)