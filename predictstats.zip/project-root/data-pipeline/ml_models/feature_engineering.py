import pandas as pd
import numpy as np
from sklearn.preprocessing import OneHotEncoder, StandardScaler, FunctionTransformer
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from ..utils.transformation import encode_cyclic_features, calculate_momentum, exponential_smoothing

def create_cricket_features(raw_data, target='match_outcome'):
    """Generate engineered features for cricket predictions"""
    df = raw_data.copy()
    
    # 1. Venue Effects
    venue_encoder = OneHotEncoder(handle_unknown='ignore')
    venue_features = venue_encoder.fit_transform(df[['venue']])
    
    # 2. Team Momentum
    df['team1_momentum'] = calculate_momentum(df['team1_win_streak'], window=5)
    df['team2_momentum'] = calculate_momentum(df['team2_win_streak'], window=5)
    
    # 3. Player Form (Exponential Smoothing)
    df['batsman_form'] = exponential_smoothing(df['batsman_avg'], alpha=0.3)
    df['bowler_form'] = exponential_smoothing(df['bowler_economy'], alpha=0.2)
    
    # 4. Time-based Features
    df = encode_cyclic_features(df, 'current_over', max_val=50)
    df['hours_since_last_match'] = (df['match_time'] - df['prev_match_time']).dt.total_seconds() / 3600
    
    # 5. Environmental Factors
    env_features = df[['pitch_type', 'dew_factor', 'temperature']]
    
    # 6. Target Encoding for Head-to-Head
    df['h2h_win_rate'] = df.groupby(['team1', 'team2'])['team1_win'].transform('mean')
    
    # Combine all features
    numeric_features = [
        'team1_momentum', 'team2_momentum', 'batsman_form',
        'bowler_form', 'h2h_win_rate', 'current_over_sin', 
        'current_over_cos', 'hours_since_last_match'
    ]
    
    preprocessor = ColumnTransformer([
        ('venue', venue_encoder, ['venue']),
        ('env', OneHotEncoder(), ['pitch_type']),
        ('numeric', StandardScaler(), numeric_features)
    ])
    
    X = preprocessor.fit_transform(df)
    y = df[target]
    
    return X, y

def create_football_features(raw_data, target='result'):
    """Generate engineered features for football predictions"""
    df = raw_data.copy()
    
    # 1. Team Strength Metrics
    df['home_strength'] = 0.4*df['home_team_rank'] + 0.6*df['home_form_last5']
    df['away_strength'] = 0.3*df['away_team_rank'] + 0.7*df['away_form_last5']
    
    # 2. Recent Performance
    df['home_xg_avg'] = calculate_momentum(df['home_xg'], window=5)
    df['away_xg_avg'] = calculate_momentum(df['away_xg'], window=5)
    
    # 3. Head-to-Head Features
    df['h2h_goal_diff'] = df['home_h2h_goals'] - df['away_h2h_goals']
    
    # 4. Temporal Features
    df['days_rest'] = (df['match_date'] - df['last_match_date']).dt.days
    df = encode_cyclic_features(df, 'kickoff_hour', max_val=24)
    
    # 5. Player Availability
    df['missing_key_players'] = (
        df['home_missing_players'] / df['home_team_size'] +
        df['away_missing_players'] / df['away_team_size']
    )
    
    # Feature Selection
    features = [
        'home_strength', 'away_strength', 'home_xg_avg', 'away_xg_avg',
        'h2h_goal_diff', 'days_rest', 'kickoff_hour_sin', 'kickoff_hour_cos',
        'missing_key_players', 'venue', 'referee'
    ]
    
    preprocessor = ColumnTransformer([
        ('categorical', OneHotEncoder(), ['venue', 'referee']),
        ('numeric', StandardScaler(), [
            'home_strength', 'away_strength', 'home_xg_avg',
            'away_xg_avg', 'h2h_goal_diff', 'days_rest',
            'missing_key_players'
        ])
    ])
    
    X = preprocessor.fit_transform(df[features])
    y = df[target]
    
    return X, y

def create_common_preprocessor():
    """Shared preprocessing pipeline for live data"""
    return Pipeline([
        ('imputer', SimpleImputer(strategy='median')),
        ('scaler', StandardScaler()),
        ('cyclic_encoder', FunctionTransformer(
            lambda df: encode_cyclic_features(df, 'minute', 90)))
    ])