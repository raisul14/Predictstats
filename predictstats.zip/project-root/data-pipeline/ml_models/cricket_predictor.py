import pandas as pd
import joblib
from xgboost import XGBClassifier, XGBRegressor
from lightgbm import LGBMClassifier
from sklearn.model_selection import TimeSeriesSplit
from sklearn.calibration import CalibratedClassifierCV
from sklearn.metrics import log_loss, mean_absolute_error
from .feature_engineering import create_cricket_features

class CricketModelTrainer:
    def __init__(self):
        self.models = {
            'match_winner': XGBClassifier(
                objective='multi:softprob',
                n_estimators=200,
                max_depth=5,
                learning_rate=0.05
            ),
            'top_batsman': LGBMClassifier(
                num_class=15,
                boosting_type='gbdt',
                n_estimators=150
            ),
            'score_range': XGBRegressor(
                objective='reg:squarederror',
                n_estimators=100
            )
        }
        self.feature_importances = {}

    def train_models(self, historical_data):
        """Orchestrate training of all cricket models"""
        self._train_match_winner_model(historical_data)
        self._train_top_batsman_model(historical_data)
        self._train_score_model(historical_data)

    def _train_match_winner_model(self, data):
        """Train 1X2 outcome predictor"""
        X, y = create_cricket_features(data, target='match_outcome')
        
        # Temporal validation split
        tscv = TimeSeriesSplit(n_splits=5)
        for train_idx, test_idx in tscv.split(X):
            X_train, X_test = X.iloc[train_idx], X.iloc[test_idx]
            y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]
            
            self.models['match_winner'].fit(
                X_train, y_train,
                eval_set=[(X_test, y_test)],
                early_stopping_rounds=15
            )
        
        # Calibrate probabilities
        self.models['match_winner'] = CalibratedClassifierCV(
            self.models['match_winner'], method='isotonic', cv='prefit'
        ).fit(X, y)
        
        self.feature_importances['match_winner'] = dict(
            zip(X.columns, self.models['match_winner'].feature_importances_))

    def _train_top_batsman_model(self, data):
        """Train classification model for top batter prediction"""
        X, y = create_cricket_features(data, target='top_batsman')
        
        self.models['top_batsman'].fit(X, y)
        self.feature_importances['top_batsman'] = dict(
            zip(X.columns, self.models['top_batsman'].feature_importances_))

    def _train_score_model(self, data):
        """Regression model for score range prediction"""
        X, y = create_cricket_features(data, target='total_runs')
        
        self.models['score_range'].fit(X, y)
        self.feature_importances['score_range'] = dict(
            zip(X.columns, self.models['score_range'].feature_importances_))

    def predict(self, match_features):
        """Generate all predictions for a match"""
        input_df = pd.DataFrame([match_features])
        X, _ = create_cricket_features(input_df)
        
        return {
            'winner_prob': self.models['match_winner'].predict_proba(X)[0],
            'top_batsman_prob': self.models['top_batsman'].predict_proba(X)[0],
            'score_pred': self.models['score_range'].predict(X)[0]
        }

    def evaluate_models(self, test_data):
        """Calculate evaluation metrics for all models"""
        metrics = {}
        X_winner, y_winner = create_cricket_features(test_data, 'match_outcome')
        X_batsman, y_batsman = create_cricket_features(test_data, 'top_batsman')
        X_score, y_score = create_cricket_features(test_data, 'total_runs')
        
        # Match winner metrics
        winner_probs = self.models['match_winner'].predict_proba(X_winner)
        metrics['match_winner'] = {
            'log_loss': log_loss(y_winner, winner_probs),
            'top_3_accuracy': self._top_k_accuracy(y_winner, winner_probs, k=3)
        }
        
        # Top batsman metrics
        batsman_probs = self.models['top_batsman'].predict_proba(X_batsman)
        metrics['top_batsman'] = {
            'log_loss': log_loss(y_batsman, batsman_probs),
            'top_1_accuracy': self._top_k_accuracy(y_batsman, batsman_probs, k=1)
        }
        
        # Score prediction metrics
        score_preds = self.models['score_range'].predict(X_score)
        metrics['score_range'] = {
            'mae': mean_absolute_error(y_score, score_preds),
            'within_20': (abs(y_score - score_preds) <= 20).mean()
        }
        
        return metrics

    def _top_k_accuracy(self, y_true, y_pred_probs, k=3):
        """Custom metric for top-k prediction accuracy"""
        top_k = np.argsort(y_pred_probs, axis=1)[:, -k:]
        return np.mean([1 if y in top else 0 for y, top in zip(y_true, top_k)])

    def save_models(self, path_prefix='models/cricket'):
        """Persist trained models to disk"""
        joblib.dump(self.models['match_winner'], f'{path_prefix}_winner.pkl')
        joblib.dump(self.models['top_batsman'], f'{path_prefix}_batsman.pkl') 
        joblib.dump(self.models['score_range'], f'{path_prefix}_score.pkl')

if __name__ == "__main__":
    # Example training pipeline
    trainer = CricketModelTrainer()
    
    # Load and prepare data
    raw_data = pd.read_csv('data/cricket_matches.csv')
    processed_data = clean_cricket_data(raw_data)
    
    # Train and evaluate
    trainer.train_models(processed_data)
    metrics = trainer.evaluate_models(processed_data.sample(frac=0.2))
    
    # Save models and metrics
    trainer.save_models()
    pd.DataFrame(metrics).to_csv('model_metrics/cricket_metrics.csv')