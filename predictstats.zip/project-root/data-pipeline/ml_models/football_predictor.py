import pandas as pd
from xgboost import XGBClassifier, XGBRegressor
from sklearn.model_selection import TimeSeriesSplit
from sklearn.calibration import CalibratedClassifierCV
from .feature_engineering import create_football_features

class FootballPredictionModels:
    def __init__(self):
        self.models = {
            '1x2': XGBClassifier(
                objective='multi:softprob',
                n_estimators=150,
                max_depth=4,
                learning_rate=0.1,
                num_class=3
            ),
            'over_under': XGBRegressor(
                objective='reg:squarederror',
                n_estimators=100,
                max_depth=3
            )
        }
        
        self.feature_importances = {}

    def train_1x2_model(self, historical_data):
        """Train match outcome classifier"""
        X, y = create_football_features(historical_data, target='result')
        
        # Temporal cross-validation
        tscv = TimeSeriesSplit(n_splits=5)
        for train_idx, test_idx in tscv.split(X):
            X_train, X_test = X.iloc[train_idx], X.iloc[test_idx]
            y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]
            
            self.models['1x2'].fit(
                X_train, y_train,
                eval_set=[(X_test, y_test)],
                early_stopping_rounds=10
            )
        
        # Calibrate probabilities
        calibrated = CalibratedClassifierCV(self.models['1x2'], method='isotonic', cv='prefit')
        calibrated.fit(X, y)
        self.models['1x2'] = calibrated
        
        self.feature_importances['1x2'] = dict(
            zip(X.columns, self.models['1x2'].feature_importances_)
        
    def train_over_under_model(self, historical_data):
        """Train total goals regression model"""
        X, y = create_football_features(historical_data, target='total_goals')
        
        self.models['over_under'].fit(X, y)
        self.feature_importances['over_under'] = dict(
            zip(X.columns, self.models['over_under'].feature_importances_))

    def predict(self, match_features, model_type='1x2'):
        """Generate predictions from features"""
        input_df = pd.DataFrame([match_features])
        X, _ = create_football_features(input_df)
        return self.models[model_type].predict_proba(X)[0] if model_type == '1x2' \
               else self.models[model_type].predict(X)[0]

    def calculate_metrics(self, X_test, y_test, model_type='1x2'):
        """Model performance evaluation"""
        if model_type == '1x2':
            preds = self.models[model_type].predict_proba(X_test)
            return {
                'log_loss': log_loss(y_test, preds),
                'brier_score': brier_score_loss(y_test, preds[:,1])
            }
        else:
            preds = self.models[model_type].predict(X_test)
            return {
                'mae': mean_absolute_error(y_test, preds),
                'rmse': mean_squared_error(y_test, preds, squared=False)
            }

# Example Usage:
if __name__ == "__main__":
    trainer = FootballPredictionModels()
    
    # Load historical data
    data = pd.read_csv('data/football_matches.csv')
    
    # Train models
    trainer.train_1x2_model(data)
    trainer.train_over_under_model(data)
    
    # Save models
    joblib.dump(trainer.models['1x2'], 'models/football_1x2_model.pkl')
    joblib.dump(trainer.models['over_under'], 'models/over_under_model.pkl')