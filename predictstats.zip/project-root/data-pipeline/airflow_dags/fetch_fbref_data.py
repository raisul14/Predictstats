from datetime import datetime
from airflow import DAG
from airflow.operators.python import PythonOperator
from apps.matches.football.fetch_fbref import FBrefFetcher
from utils.data_storage import save_to_s3

default_args = {
    'owner': 'data-team',
    'depends_on_past': False,
    'start_date': datetime(2024, 1, 1),
    'retries': 2,
    'retry_delay': 600,  # 10 minutes
    'max_active_runs': 1
}

def fetch_fbref_football_data():
    """ETL pipeline for FBref football match data"""
    fetcher = FBrefFetcher()
    
    try:
        # Extract live match data
        live_matches = fetcher.fetch_live_matches()
        processed = []
        
        # Process each match
        for match in live_matches:
            match_id = match['link'].split('/')[-1].split('-')[0]
            details = fetcher.parse_match_report(match['link'])
            
            # Transform data structure
            processed.append({
                'match_id': match_id,
                'competition': match.get('competition', 'Unknown'),
                'home_team': details['lineups'].get('home', {}),
                'away_team': details['lineups'].get('away', {}),
                'stats': {
                    'xg': details['stats'].get('expected_goals', {}),
                    'possession': details['stats'].get('possession', {}),
                    'shots': details['stats'].get('shots', {})
                },
                'events': details['events'],
                'timestamp': datetime.utcnow().isoformat()
            })
        
        # Load to S3
        save_to_s3(
            processed,
            's3://predictstats-data/fbref/football/',
            partition='hourly'
        )
        return f"Processed {len(processed)} football matches"
        
    except Exception as e:
        raise RuntimeError(f"FBref data fetch failed: {str(e)}")

dag = DAG(
    'fbref_football_pipeline',
    default_args=default_args,
    schedule_interval='0 * * * *',  # Hourly at :00
    catchup=False,
    tags=['football', 'fbref', 'statsbomb']
)

extract_task = PythonOperator(
    task_id='extract_fbref_football',
    python_callable=fetch_fbref_football_data,
    dag=dag
)

# Optional downstream tasks
# transform_task = PythonOperator(...)
# quality_check = PythonOperator(...)
# extract_task >> transform_task >> quality_check