from datetime import datetime
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.models import Variable
from mlflow.tracking import MlflowClient
from utils.model_ops import promote_model_to_prod

default_args = {
    'owner': 'ml-team',
    'depends_on_past': False,
    'start_date': datetime(2024, 1, 1),
    'retries': 1,
    'retry_delay': 3600,  # 1 hour
    'max_active_runs': 1
}

def validate_training_data():
    """Data quality checks before training"""
    from utils.data_validation import run_data_checks
    if not run_data_checks():
        raise ValueError("Training data validation failed")
    return "Data validation passed"

def hyperparameter_tuning():
    """Optimize model parameters using Optuna"""
    from ml_models.hparam_tuning import optimize_params
    return optimize_params(
        model_type='both',  # Football and cricket
        n_trials=100,
        timeout=7200  # 2 hours
    )

def retrain_football_model():
    """Retrain and version football prediction models"""
    from ml_models.football_predictor import FootballPredictionModels
    model = FootballPredictionModels()
    model.train_models(Variable.get("FOOTBALL_TRAINING_DATA"))
    
    # Log to MLflow
    client = MlflowClient()
    with mlflow.start_run():
        mlflow.log_params(model.get_best_params())
        mlflow.log_metrics(model.evaluate())
        mlflow.sklearn.log_model(model, "football-model")
    
    return client.list_artifacts(mlflow.active_run().info.run_id)

def retrain_cricket_model():
    """Retrain and version cricket prediction models""" 
    from ml_models.cricket_predictor import CricketModelTrainer
    trainer = CricketModelTrainer()
    trainer.train_models(Variable.get("CRICKET_TRAINING_DATA"))
    
    # MLflow tracking
    with mlflow.start_run():
        mlflow.log_params(trainer.model_params)
        mlflow.log_metrics(trainer.evaluate_models())
        mlflow.sklearn.log_model(trainer, "cricket-model")
    
    return "Cricket models updated"

def validate_and_deploy():
    """Model validation and production promotion"""
    from utils.model_validation import validate_against_prod
    football_pass = validate_against_prod('football', threshold=0.02)
    cricket_pass = validate_against_prod('cricket', threshold=0.03)
    
    if football_pass and cricket_pass:
        promote_model_to_prod('football')
        promote_model_to_prod('cricket')
        return "New models deployed to production"
    raise ValueError("Model validation failed")

dag = DAG(
    'model_retraining_pipeline',
    default_args=default_args,
    schedule_interval='0 0 * * 0',  # Weekly on Sundays
    catchup=False,
    tags=['retraining', 'mlops']
)

with dag:
    data_check = PythonOperator(
        task_id='validate_training_data',
        python_callable=validate_training_data
    )
    
    hparam_tuning = PythonOperator(
        task_id='hyperparameter_optimization',
        python_callable=hyperparameter_tuning
    )
    
    football_retrain = PythonOperator(
        task_id='retrain_football_models',
        python_callable=retrain_football_model
    )
    
    cricket_retrain = PythonOperator(
        task_id='retrain_cricket_models',
        python_callable=retrain_cricket_model
    )
    
    model_validation = PythonOperator(
        task_id='validate_and_deploy_models',
        python_callable=validate_and_deploy
    )
    
    data_check >> hparam_tuning >> [football_retrain, cricket_retrain] >> model_validation