from datetime import datetime
from airflow import DAG
from airflow.operators.python import PythonOperator
from apps.matches.cricket.fetch_espncricinfo import CricinfoFetcher
from utils.data_storage import save_to_s3

default_args = {
    'owner': 'data-team',
    'depends_on_past': False,
    'start_date': datetime(2024, 1, 1),
    'retries': 3,
    'retry_delay': 300  # 5 minutes
}

def fetch_and_process_cricket_data():
    """Main ETL function for ESPN cricket data"""
    fetcher = CricinfoFetcher()
    
    try:
        # Extract
        live_matches = fetcher.fetch_live_matches()
        
        # Transform
        processed_data = []
        for match in live_matches:
            details = fetcher.fetch_match_details(match['link'])
            processed_data.append({
                'match_id': match['link'].split('/')[-1],
                'teams': match['teams'],
                'status': match['status'],
                'scorecard': details['scorecard'],
                'timestamp': datetime.utcnow().isoformat()
            })
            
        # Load
        save_to_s3(processed_data, 's3://predictstats-data/espn_cricket/raw/')
        
        return f"Processed {len(processed_data)} matches"
        
    except Exception as e:
        raise RuntimeError(f"ESPN fetch failed: {str(e)}")

dag = DAG(
    'espn_cricket_pipeline',
    default_args=default_args,
    schedule_interval='*/15 * * * *',  # Every 15 minutes
    max_active_runs=1,
    catchup=False,
    tags=['cricket', 'espn']
)

fetch_task = PythonOperator(
    task_id='fetch_espn_cricket_data',
    python_callable=fetch_and_process_cricket_data,
    dag=dag
)

# Add additional tasks if needed
# process_task = PythonOperator(...)
# upload_task = PythonOperator(...)
# fetch_task >> process_task >> upload_task